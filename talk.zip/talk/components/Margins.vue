<script setup>
// Stability margins, drawn rather than defined.
//
// Trace the loop gain L(jw) as one point moving in the complex plane while the
// frequency rises. If that curve ever reaches -1, a signal fed once round the
// loop comes back exactly as itself, and the loop sustains motion with nothing
// driving it. Everything called a "margin" is a distance from that one point.
//
// The loop drawn here is the textbook one -- an integrator and two lags,
// L(s) = k / (s (1+s) (1+0.2s)) -- because it has BOTH margins visible at once
// at a sensible scale. The rig's own loop is section 1's, and its margin story
// is the same story with a delay in place of the second lag.
import { ref, computed } from 'vue'

const kdb = ref(0)
const k = computed(() => Math.pow(10, kdb.value / 20))

const CX = 312, CY = 88, S = 80, CLIP = 2.45
const px = (re, im) => [CX + re * S, CY - im * S]

function L(w, kk) {
  // 1/(jw) * 1/(1+jw) * 1/(1+0.2jw), all in one go
  const mag = kk / (w * Math.hypot(1, w) * Math.hypot(1, 0.2 * w))
  const ph = -Math.PI / 2 - Math.atan(w) - Math.atan(0.2 * w)
  return [mag * Math.cos(ph), mag * Math.sin(ph), mag, ph]
}

const path = computed(() => {
  const pts = []
  for (let i = 0; i <= 460; i++) {
    const w = 0.25 * Math.pow(1.016, i)
    const [re, im] = L(w, k.value)
    if (Math.hypot(re, im) <= CLIP) pts.push(px(re, im).map(v => v.toFixed(1)).join(','))
  }
  return pts.length ? 'M' + pts.join(' L') : ''
})

// gain crossover: where |L| = 1. Phase margin is measured there.
const pm = computed(() => {
  let lo = 0.05, hi = 60
  for (let i = 0; i < 60; i++) {
    const mid = Math.sqrt(lo * hi)
    if (L(mid, k.value)[2] > 1) lo = mid; else hi = mid
  }
  const w = Math.sqrt(lo * hi), [re, im, mag, ph] = L(w, k.value)
  return { w, re, im, deg: 180 + ph * 180 / Math.PI, exists: Math.abs(mag - 1) < 0.02 }
})

// phase crossover: where the curve cuts the negative real axis. w = sqrt(5).
const gm = computed(() => {
  const w = Math.sqrt(5), [re] = L(w, k.value)
  return { re, db: 20 * Math.log10(1 / Math.abs(re)), unstable: Math.abs(re) >= 1 }
})
</script>

<template>
<div class="cols-w" style="gap:1rem">
  <div>
    <svg viewBox="0 0 500 300" class="w-full">
      <line x1="150" :y1="CY" x2="470" :y2="CY" stroke="var(--line)"/>
      <line :x1="CX" y1="10" :x2="CX" y2="292" stroke="var(--line)"/>
      <text x="466" :y="CY - 7" font-size="9" fill="var(--faint)" text-anchor="end">real</text>
      <text :x="CX + 7" y="20" font-size="9" fill="var(--faint)">imaginary</text>

      <!-- The disc a full-state optimal design is guaranteed to keep the curve
           out of. The return-difference inequality is |1 + L| >= 1, so it is
           centred on -1 with radius ONE, not a half. Radius one is what gives
           a gain margin of (1/2, inf) and a phase margin of 60 degrees; a half
           would give 29 degrees and contradict section 4.
           Old geometry: centred on -1,
           radius 1/2. That is what "gain down to a half, phase off by 60 deg"
           means geometrically. -->
      <circle :cx="px(-1,0)[0]" :cy="CY" :r="S"
              fill="rgba(167,149,217,.10)" stroke="var(--cD)" stroke-dasharray="3 3"/>
      <!-- gain of exactly one -->
      <circle :cx="CX" :cy="CY" :r="S" fill="none" stroke="var(--line-2)" stroke-dasharray="2 4"/>

      <path :d="path" fill="none" stroke="var(--cA)" stroke-width="1.9"/>

      <circle :cx="px(-1,0)[0]" :cy="CY" r="4.2" fill="var(--bad)"/>
      <text :x="px(-1,0)[0]" :y="CY - 46" font-size="10" fill="var(--bad)"
            text-anchor="middle" font-weight="600">the point marked -1</text>

      <!-- gain margin: distance from the origin to where the curve cuts the axis -->
      <line :x1="px(gm.re,0)[0]" :y1="CY" :x2="CX" :y2="CY"
            stroke="var(--cC)" stroke-width="2.4"/>
      <circle :cx="px(gm.re,0)[0]" :cy="CY" r="3.2" fill="var(--cC)"/>
      <line x1="146" :y1="CY - 12" x2="176" :y2="CY - 12" stroke="var(--cC)" stroke-width="2.4"/>
      <text x="146" :y="CY - 20" font-size="10"
            fill="var(--cC)">gain margin {{ gm.db.toFixed(1) }} dB</text>

      <!-- phase margin: the angle back to the negative real axis at |L| = 1 -->
      <g v-if="pm.exists">
        <line :x1="CX" :y1="CY" :x2="px(pm.re, pm.im)[0]" :y2="px(pm.re, pm.im)[1]"
              stroke="var(--brass)" stroke-width="1.6"/>
        <circle :cx="px(pm.re, pm.im)[0]" :cy="px(pm.re, pm.im)[1]" r="3.4" fill="var(--brass)"/>
        <line x1="146" :y1="CY + 12" x2="176" :y2="CY + 12" stroke="var(--brass)" stroke-width="1.6"/>
        <text x="146" :y="CY + 26" font-size="10" fill="var(--brass)"
              >phase margin {{ pm.deg.toFixed(0) }}&deg;</text>
      </g>

      <text x="8" y="286" font-size="8.5" fill="var(--faint)">
        Dashed violet: a disc section 4 guarantees the curve stays out of. Dashed circle: gain one.</text>
    </svg>
  </div>

  <div class="stack-tight">
    <div class="readout">
      <span class="rl">loop gain</span>
      <span class="rv">{{ kdb >= 0 ? '+' : '' }}{{ kdb.toFixed(0) }} dB</span>
    </div>
    <input type="range" min="-12" max="24" step="1" v-model.number="kdb"
           aria-label="extra loop gain in decibels">
    <div class="panel" :class="gm.unstable ? 'bad' : 'good'">
      <span class="k">verdict</span>
      <p v-if="gm.unstable"><b class="bad">Unstable.</b> The curve encircles -1: a signal
      returns larger and in phase.</p>
      <p v-else><b class="good">Stable.</b> The curve passes to the right of -1. The two
      marked distances are the margins.</p>
    </div>
    <div class="def">
      <span class="term">gain margin</span> The factor by which the loop gain can be raised
      before the curve reaches -1.
    </div>
    <div class="def">
      <span class="term">phase margin</span> The additional phase lag tolerable at the frequency
      where the loop gain is one.
    </div>
  </div>
</div>
</template>
