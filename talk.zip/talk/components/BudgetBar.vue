<script setup>
// Two failures of a capped allocator, drawn.
//
// LEFT. Each term is inside its own budget and the sum is not, because the
// per-channel term is added after the allocator's cap rather than inside it.
// Nothing in either term's own check can see this.
//
// RIGHT. When the excess is removed by clipping each channel at its own limit,
// the vector that is actually applied points somewhere else -- and the
// direction was the entire output of the allocator. Scaling the whole vector
// shortens it without turning it.
const X0 = 56, XLIM = 330, BH = 20
const ROWS = [
  { y: 44,  modal: 110, deriv: 62 },
  { y: 76,  modal: 132, deriv: 70 },
  { y: 108, modal: 120, deriv: 56 },
  { y: 140, modal: 150, deriv: 150 },
]
const CAP = 168                       // the allocator's own cap
const LIMW = XLIM - X0                // the actuator window

const OX = 486, OY = 158
const V = {
  cmd:    [140, -92],
  clip:   [132, -34],
  scaled: [ 98, -64],
}
const tip = v => [OX + v[0], OY + v[1]]
</script>

<template>
<svg viewBox="0 0 728 214" class="w-full" role="img"
     aria-label="Left: per-channel command budgets, where each term is inside its own cap but the sum exceeds the actuator window on one channel. Right: clipping each channel turns the commanded vector, while scaling it does not.">

  <!-- ============================= THE BUDGETS ========================= -->
  <text x="20" y="18" font-size="9" fill="var(--c-act)" font-weight="600" letter-spacing=".06em">WHAT EACH CHANNEL IS ASKED FOR</text>

  <g v-for="(r, i) in ROWS" :key="i">
    <text x="46" :y="r.y + 14" font-size="8" fill="var(--faint)" text-anchor="end">{{ i }}</text>
    <rect :x="X0" :y="r.y" :width="LIMW" :height="BH" rx="2" fill="none" stroke="var(--line-2)"/>
    <rect :x="X0" :y="r.y" :width="r.modal" :height="BH" rx="2"
          fill="var(--c-act)" fill-opacity=".55"/>
    <rect :x="X0 + r.modal" :y="r.y" :width="Math.min(r.deriv, LIMW - r.modal)" :height="BH"
          fill="var(--c-act)" fill-opacity=".22" stroke="var(--c-act)" stroke-dasharray="2 2"/>
    <rect v-if="r.modal + r.deriv > LIMW" :x="XLIM" :y="r.y"
          :width="r.modal + r.deriv - LIMW" :height="BH"
          fill="var(--bad)" fill-opacity=".35" stroke="var(--bad)" stroke-dasharray="2 2"/>
  </g>

  <line :x1="X0 + CAP" y1="36" :x2="X0 + CAP" y2="172" stroke="var(--c-act)" stroke-dasharray="3 3"/>
  <text :x="X0 + CAP - 4" y="32" font-size="8" fill="var(--c-act)" text-anchor="end">allocator's own cap</text>
  <line :x1="XLIM" y1="36" :x2="XLIM" y2="172" stroke="var(--bad)"/>
  <text :x="XLIM + 4" y="32" font-size="8" fill="var(--bad)">actuator limit</text>

  <text x="56" y="192" font-size="8" fill="var(--c-act)">
    <tspan fill-opacity=".9">&#9646;</tspan> allocated per mode
    <tspan dx="10" fill-opacity=".5">&#9646;</tspan> per-channel term, added after the cap</text>
  <text x="56" y="204" font-size="8" fill="var(--bad)">&#9646; discarded, on the one channel where the sum does not fit</text>

  <!-- ============================ THE DIRECTION ======================== -->
  <line x1="416" y1="14" x2="416" y2="200" stroke="var(--line)"/>
  <text x="440" y="18" font-size="9" fill="var(--c-plant)" font-weight="600" letter-spacing=".06em">AND WHAT IS ACTUALLY APPLIED</text>

  <g stroke-width="1.6" fill="none">
    <path :d="`M${OX} ${OY} L${tip(V.cmd)[0]} ${tip(V.cmd)[1]}`" stroke="var(--c-act)" marker-end="url(#bb-a)"/>
    <path :d="`M${OX} ${OY} L${tip(V.clip)[0]} ${tip(V.clip)[1]}`" stroke="var(--bad)" marker-end="url(#bb-b)"/>
    <path :d="`M${OX} ${OY} L${tip(V.scaled)[0]} ${tip(V.scaled)[1]}`" stroke="var(--c-act)"
          stroke-dasharray="4 3" marker-end="url(#bb-a)"/>
  </g>
  <circle :cx="OX" :cy="OY" r="3" fill="var(--dim)"/>

  <text :x="tip(V.cmd)[0] + 6" :y="tip(V.cmd)[1] + 3" font-size="8.5" fill="var(--c-act)">commanded</text>
  <text :x="tip(V.clip)[0] + 6" :y="tip(V.clip)[1] + 3" font-size="8.5" fill="var(--bad)">clipped per channel</text>
  <text :x="tip(V.scaled)[0] - 6" :y="tip(V.scaled)[1] - 5" font-size="8.5" fill="var(--c-act)"
        text-anchor="end">vector scaled</text>

  <text x="440" y="192" font-size="8" fill="var(--faint)">Clipping turns the vector. Scaling shortens it</text>
  <text x="440" y="204" font-size="8" fill="var(--faint)">and leaves the direction alone.</text>

  <defs>
    <marker id="bb-a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-act)" stroke="none"/></marker>
    <marker id="bb-b" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--bad)" stroke="none"/></marker>
  </defs>
</svg>
</template>
