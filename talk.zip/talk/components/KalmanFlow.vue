<script setup>
import Tex from './Tex.vue'

// Nothing is hidden behind a click: the deck has to be readable on paper.
// Slides pass which steps to show, so no single slide is overloaded.
const props = defineProps({
  steps: { type: Array, default: () => [0, 1, 2, 3] },
  legend: { type: Boolean, default: false },
})

const STEPS = [
  {
    title: 'PREDICT', sub: 'advance the estimate',
    eq: '\\begin{aligned}\\hat x^- &= F\\,\\hat x\\\\ P^- &= F P F^{\\top} + Q\\end{aligned}',
    words: 'Advance the estimate through the model. No measurement enters, and the covariance grows.',
  },
  {
    title: 'COMPARE', sub: 'form the residual',
    eq: '\\begin{aligned}\\tilde y &= y - H\\hat x^-\\\\ S &= H P^- H^{\\top} + R\\end{aligned}',
    words: 'Predicted reading minus measured reading. S is the covariance that residual should have.',
  },
  {
    title: 'CORRECT', sub: 'weight the two',
    eq: '\\begin{aligned}K &= P^- H^{\\top} S^{-1}\\\\ \\hat x &= \\hat x^- + K\\,\\tilde y\\end{aligned}',
    words: 'Move partway toward the measurement. The distance is set by the ratio of the two uncertainties, and is computed rather than tuned.',
  },
  {
    title: 'CHECK', sub: 'available at no cost',
    eq: '\\chi^2 = \\tilde y^{\\top} S^{-1} \\tilde y',
    words: 'S is already computed, so the consistency test is free. Expected value: the number of measurements.',
  },
]

const SYMBOLS = [
  ['\\hat x', 'state estimate'],
  ['P', 'estimate covariance'],
  ['F', 'state transition'],
  ['Q', 'process noise covariance'],
  ['y', 'measurement'],
  ['H', 'measurement model'],
  ['R', 'measurement noise covariance'],
  ['K', 'Kalman gain'],
]
const shown = i => props.steps.includes(i)
</script>

<template>
<div>
  <!-- the cycle, always drawn in full so the reader can place the step -->
  <svg viewBox="0 0 700 74" class="w-full">
    <g v-for="(s, i) in STEPS" :key="s.title">
      <rect :x="4 + i * 174" y="6" width="160" height="38" rx="3"
            :fill="shown(i) ? 'rgba(224,166,58,.10)' : 'var(--panel)'"
            :stroke="shown(i) ? 'var(--brass)' : 'var(--line)'"/>
      <text :x="84 + i * 174" y="23" text-anchor="middle" font-size="10.5" font-weight="600"
            :fill="shown(i) ? 'var(--brass)' : 'var(--faint)'">{{ s.title }}</text>
      <text :x="84 + i * 174" y="36" text-anchor="middle" font-size="9"
            :fill="shown(i) ? 'var(--dim)' : 'var(--faint)'">{{ s.sub }}</text>
      <g v-if="i < 3" stroke="var(--line-2)" stroke-width="1.2">
        <line :x1="166 + i * 174" y1="25" :x2="172 + i * 174" y2="25"/>
        <polygon :points="`${178 + i * 174},25 ${171 + i * 174},21.5 ${171 + i * 174},28.5`"
                 fill="var(--line-2)" stroke="none"/>
      </g>
    </g>
    <path d="M 690 50 Q 350 74 14 50" fill="none" stroke="var(--line-2)" stroke-width="1" stroke-dasharray="4 3"/>
    <polygon points="8,50 16,47 16,53" fill="var(--line-2)"/>
    <text x="350" y="70" text-anchor="middle" font-size="9" fill="var(--faint)">
      every control step, forever</text>
  </svg>

  <div :class="steps.length > 2 ? 'cols-4' : 'cols-2'" class="mt2">
    <div v-for="i in steps" :key="i" class="panel brass">
      <span class="k">{{ STEPS[i].title }}</span>
      <div style="text-align:center; color:var(--brass); padding:.15rem 0">
        <Tex :e="STEPS[i].eq" />
      </div>
      <p><b style="color:var(--ink)">In words.</b> {{ STEPS[i].words }}</p>
    </div>
  </div>

  <div v-if="legend" class="panel mt2" style="padding:.45rem .8rem">
    <span class="k">symbols</span>
    <div class="cols-2" style="gap:.05rem 1.2rem">
      <div v-for="s in SYMBOLS" :key="s[0]" class="cap"
           style="display:flex; gap:.5rem; align-items:baseline">
        <span style="color:var(--brass); min-width:1.6rem"><Tex :e="s[0]" /></span>
        <span>{{ s[1] }}</span>
      </div>
    </div>
  </div>
</div>
</template>
