<script setup>
// What feedback actually DOES: it moves the poles. Turn the gain up and watch
// where they go, under three laws applied to the same plant.
//
//   feed back position   they climb. Stiffer, rings faster, dies no sooner.
//   feed back velocity   they go left. That, and only that, is damping.
//   position, with lag   they bend RIGHT and cross. Gain that would have been
//                        harmless is now the thing that kills you.
//
// The third case is why the rest of classical control exists: every real loop
// has lag in it somewhere, in a filter, a computation or a wire.
//
// Only the upper half plane is drawn. Poles of a real system come in mirror
// pairs, so the lower half carries no information the upper half does not.
import { ref, computed } from 'vue'

const LAWS = [
  { id: 'pos', t: 'position feedback', s: 'raises the frequency' },
  { id: 'vel', t: 'velocity feedback', s: 'moves the poles left' },
  { id: 'lag', t: 'position, plus a lag', s: 'crosses the axis' },
]
const law = ref('pos')
const k = ref(1.2)

const Z0 = 0.05, TAU = 0.3
const KMAX = { pos: 2.6, vel: 2.2, lag: 0.75 }

// Durand-Kerner. Every polynomial here is degree 2 or 3.
function roots (c) {
  const n = c.length - 1
  const a = c.map(v => v / c[n])
  const z = Array.from({ length: n }, (_, i) => [Math.cos(0.7 + 2.1 * i), Math.sin(0.7 + 2.1 * i)])
  const mul = (p, q) => [p[0] * q[0] - p[1] * q[1], p[0] * q[1] + p[1] * q[0]]
  const div = (p, q) => { const d = q[0] * q[0] + q[1] * q[1] || 1e-14
    return [(p[0] * q[0] + p[1] * q[1]) / d, (p[1] * q[0] - p[0] * q[1]) / d] }
  for (let it = 0; it < 80; it++) {
    for (let i = 0; i < n; i++) {
      let v = [a[n], 0]
      for (let d = n - 1; d >= 0; d--) v = [v[0] * z[i][0] - v[1] * z[i][1] + a[d], v[0] * z[i][1] + v[1] * z[i][0]]
      let den = [1, 0]
      for (let j = 0; j < n; j++) if (j !== i) den = mul(den, [z[i][0] - z[j][0], z[i][1] - z[j][1]])
      const dz = div(v, den)
      z[i] = [z[i][0] - dz[0], z[i][1] - dz[1]]
    }
  }
  return z
}

// closed-loop characteristic polynomial, coefficients ascending
function poly (kk, id) {
  if (id === 'pos') return [1 + kk, 2 * Z0, 1]                       // s^2 + 2 z0 s + (1+k)
  if (id === 'vel') return [1, 2 * Z0 + kk, 1]                       // s^2 + (2 z0 + k) s + 1
  return [1 + kk, 2 * Z0 + TAU, 1 + 2 * Z0 * TAU, TAU]               // (1 + tau s)(s^2 + 2 z0 s + 1) + k
}

const OX = 272, CY = 276, S = 136
const px = (re, im) => [OX + re * S, CY - im * S]
const inView = r => r[1] >= -0.02 && r[0] >= -1.92 && r[0] <= 0.56

const now = computed(() => roots(poly(k.value, law.value))
  .filter(inView).map(r => ({ re: r[0], p: px(r[0], r[1]) })))

const trail = computed(() => {
  const out = []
  for (let i = 0; i <= 130; i++) {
    const kk = (i / 130) * KMAX[law.value]
    for (const r of roots(poly(kk, law.value))) if (inView(r)) out.push(px(r[0], r[1]))
  }
  return out
})

const free = px(-Z0, Math.sqrt(1 - Z0 * Z0))
const unstable = computed(() => roots(poly(k.value, law.value)).some(r => r[0] > 0))
const worst = computed(() => Math.max(...roots(poly(k.value, law.value)).map(r => r[0])))
</script>

<template>
<div class="rl-wrap">
  <div class="stack-tight">
    <button v-for="l in LAWS" :key="l.id" class="btn" :class="{ on: law === l.id }"
            @click="law = l.id; k = KMAX[l.id] * 0.45">
      <span class="btn-t">{{ l.t }}</span>
      <span class="btn-s">{{ l.s }}</span>
    </button>

    <div class="readout mt4"><span class="rl">gain</span>
      <span class="rv">{{ k.toFixed(2) }}</span></div>
    <input type="range" min="0" :max="KMAX[law]" step="0.01" v-model.number="k"
           aria-label="feedback gain"/>

    <div class="panel mt4" :class="unstable ? 'bad' : (worst < -0.25 ? 'good' : '')">
      <span class="k">the rightmost pole</span>
      <p class="cap"><b :class="unstable ? 'bad' : 'good'">{{ worst.toFixed(3) }}</b><span
        v-if="unstable"> -- positive real part, so the response grows.</span><span
        v-else> -- negative real part; the response decays at this rate.</span></p>
    </div>
  </div>

  <svg viewBox="0 0 360 330" role="img" aria-label="Root locus: where the closed-loop poles travel as the gain rises.">
    <clipPath id="rl-clip"><rect x="12" y="8" width="336" height="292"/></clipPath>

    <rect :x="OX" y="8" :width="348 - OX" height="292" fill="var(--bad)" opacity=".06"/>
    <g stroke="var(--line)">
      <line x1="12" :y1="CY" x2="348" :y2="CY"/>
      <line :x1="OX" y1="8" :x2="OX" y2="300"/>
    </g>
    <text x="14" :y="CY - 7" font-size="8" fill="var(--good)">decaying</text>
    <text x="346" :y="CY - 7" font-size="8" fill="var(--bad)" text-anchor="end">growing</text>
    <text :x="OX + 4" :y="CY + 11" font-size="8" fill="var(--faint)">0</text>

    <g clip-path="url(#rl-clip)">
      <!-- where the gain takes them -->
      <circle v-for="(p, i) in trail" :key="i" :cx="p[0]" :cy="p[1]" r="1.5"
              fill="var(--beat)" opacity=".5"/>

      <!-- the plant left alone -->
      <g stroke="var(--faint)" stroke-width="1.2" fill="none">
        <path :d="`M${free[0]-4},${free[1]-4} l8,8 M${free[0]+4},${free[1]-4} l-8,8`"/>
      </g>

      <!-- where they are at this gain -->
      <circle v-for="(r, i) in now" :key="'n'+i" :cx="r.p[0]" :cy="r.p[1]" r="5"
              :fill="unstable ? 'var(--bad)' : 'var(--c-plant)'"/>
    </g>
    <text :x="free[0] + 10" :y="free[1] + 3" font-size="8" fill="var(--faint)">open loop</text>

    <text x="12" y="318" font-size="8" fill="var(--faint)">Upper half plane only; each pole has a
      conjugate below the axis.</text>
  </svg>
</div>
</template>

<style scoped>
.rl-wrap{ display:grid; grid-template-columns:1fr 386px; gap:var(--s5); align-items:start; }
.rl-wrap svg{ width:100%; height:auto; }
</style>
