<script setup>
// The symbols a slide introduces, named once, bottom right.
//
// Symbol and name only: this is a place to look, not a place to read.
//
// It FLOWS in the layout -- see the .vars block in style.css. Absolute would
// cost no height, which is tempting on a 552px canvas, but it also lets a full
// slide paint the legend over its own content invisibly. Flowing turns a clash
// into overflow, which the auditor measures on every build.
//
//   <Vars :v="[['\\omega_n','natural frequency'], ['\\zeta','damping ratio']]" />
//
// List only what is NEW on this slide. A symbol carried over from an earlier
// slide does not get relisted; a symbol reused for a different quantity does,
// because that is exactly when a reader needs telling.
import { computed } from 'vue'
import Tex from './Tex.vue'

const props = defineProps({
  v:    { type: Array, required: true },
  cols: { type: Number, default: 0 },     // 0 = one column up to five entries
})
// Cap the legend at three rows and add columns instead. Height is the scarce
// dimension on a 552px canvas; width is not.
const rows = computed(() => props.cols
  ? Math.ceil(props.v.length / props.cols)
  : Math.min(3, props.v.length))
const cols = computed(() => props.cols || Math.ceil(props.v.length / rows.value))
</script>

<template>
<div class="vars" :style="{ '--vc': cols, '--vr': rows }">
  <div v-for="(p, i) in v" :key="i" class="vrow">
    <span class="vs"><Tex :e="p[0]" /></span>
    <span class="vn">{{ p[1] }}</span>
  </div>
</div>
</template>
