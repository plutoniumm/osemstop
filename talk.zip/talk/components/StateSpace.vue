<script setup>
// One equation for a whole system, drawn as the loop it describes.
//
//     x-dot = A x + B u        y = C x
//
// The picture is an integrator with F wrapped round it, because that IS the
// content: the state feeds its own rate of change, which is what makes this a
// dynamical system rather than a lookup. The shapes on the right are the part
// that decides what is possible on this rig -- neither B nor C is square, and
// both of those facts are useful.
</script>

<template>
<svg viewBox="0 0 728 196" class="w-full" role="img"
     aria-label="State space block diagram: inputs through B into an integrator, the state fed back through A, and read out through C as sensor readings, with the shapes of the three matrices.">

  <!-- forward path -->
  <g fill="var(--panel)">
    <rect x="96"  y="50" width="58" height="38" rx="3" stroke="var(--c-act)"/>
    <rect x="216" y="50" width="66" height="38" rx="3" stroke="var(--line-2)"/>
    <rect x="344" y="50" width="58" height="38" rx="3" stroke="var(--c-meas)"/>
    <rect x="180" y="132" width="58" height="32" rx="3" stroke="var(--c-plant)"/>
  </g>
  <g font-size="13" fill="var(--ink)" text-anchor="middle" font-family="var(--mono)">
    <text x="125" y="74">B</text>
    <text x="249" y="75">&#8747;</text>
    <text x="373" y="74">C</text>
    <text x="209" y="153">A</text>
  </g>
  <g font-size="8" fill="var(--faint)" text-anchor="middle">
    <text x="125" y="100">input to rate</text>
    <text x="373" y="100">state to reading</text>
    <text x="209" y="175">unforced dynamics</text>
  </g>

  <g stroke="var(--c-plant)" stroke-width="1.4" fill="none" marker-end="url(#ss)">
    <line x1="26"  y1="69" x2="62"  y2="69"/>
    <line x1="90"  y1="69" x2="210" y2="69"/>
    <line x1="282" y1="69" x2="338" y2="69"/>
    <line x1="402" y1="69" x2="452" y2="69"/>
  </g>

  <!-- the loop that makes it a dynamical system -->
  <path d="M310 69 L310 148 L244 148" fill="none" stroke="var(--c-plant)" stroke-width="1.4"
        marker-end="url(#ssb)"/>
  <path d="M174 148 L76 148 L76 82" fill="none" stroke="var(--c-plant)" stroke-width="1.4"
        marker-end="url(#ssb)"/>
  <circle cx="76" cy="69" r="6" fill="var(--bg)" stroke="var(--c-plant)" stroke-width="1.4"/>
  <text x="76" y="72.5" font-size="9" fill="var(--c-plant)" text-anchor="middle">+</text>

  <g font-size="10" font-family="var(--mono)" fill="var(--ink)">
    <text x="4" y="66">u</text>
    <text x="316" y="60">x</text>
    <text x="456" y="66">y</text>
  </g>
  <g font-size="8" fill="var(--faint)">
    <text x="4" y="80">input</text>
    <text x="316" y="46">the state</text>
    <text x="456" y="80">reading</text>
  </g>

  <line x1="540" y1="10" x2="540" y2="186" stroke="var(--line)"/>

  <!-- the shapes, because on this rig the shapes are the argument -->
  <g transform="translate(562, 16)">
    <text x="0" y="8" font-size="9" fill="var(--faint)" font-weight="600">THE SHAPES HERE</text>

    <text x="0" y="32" font-size="10" font-family="var(--mono)" fill="var(--c-meas)">C</text>
    <g transform="translate(0, 38)">
      <rect v-for="i in 12" :key="'c' + i" :x="((i - 1) % 3) * 13" :y="Math.floor((i - 1) / 3) * 10"
            width="11" height="8" fill="var(--c-meas)" fill-opacity="0.35" stroke="var(--c-meas)" stroke-width="0.6"/>
    </g>
    <g font-size="8.5">
      <text x="52" y="48" fill="var(--dim)">sensors</text>
      <text x="52" y="60" fill="var(--dim)">states</text>
      <text x="52" y="74" fill="var(--good)">tall: a check</text>
    </g>

    <text x="0" y="104" font-size="10" font-family="var(--mono)" fill="var(--c-act)">B</text>
    <g transform="translate(0, 110)">
      <rect v-for="i in 12" :key="'b' + i" :x="((i - 1) % 4) * 13" :y="Math.floor((i - 1) / 4) * 10"
            width="11" height="8" fill="var(--c-act)" fill-opacity="0.35" stroke="var(--c-act)" stroke-width="0.6"/>
    </g>
    <g font-size="8.5">
      <text x="64" y="120" fill="var(--dim)">actuators</text>
      <text x="64" y="132" fill="var(--dim)">states</text>
      <text x="64" y="146" fill="var(--good)">wide: a choice</text>
    </g>
  </g>

  <defs>
    <marker id="ss" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--c-plant)"/></marker>
    <marker id="ssb" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--c-plant)"/></marker>
  </defs>
</svg>
</template>
