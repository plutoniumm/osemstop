<script setup>
// The dissipation condition, drawn rather than asserted.
//
// Power delivered to the mirror is force x velocity. The three panels are the
// only three things that relationship can be, and each one is a real failure
// mode of this rig:
//
//   anti-phase   the intended damper.            100 % of steps dissipating
//   quadrature   a quarter-period of delay.       50 %, no net work at all
//   in-phase     an inverted sign.                 0 %, a shaker
//
// The shaded area IS the power. Green below the line is energy leaving the
// mirror; red above it is energy going in. That is why the fraction of
// dissipating steps is a complete diagnostic: it reads the shading.

const W = 218, H = 74, MID = H / 2, CYC = 2, N = 96

// velocity is the reference in every panel; force is what changes.
const vel = (t) => Math.sin(t)
const PANELS = [
  { k: 'anti-phase', sub: '', pct: '100 %',
    verdict: 'DAMPS', col: 'var(--good)', f: (t) => -Math.sin(t) },
  { k: 'quarter period late', sub: 'delay, not a sign error', pct: '50 %',
    verdict: 'NEUTRAL', col: 'var(--brass)', f: (t) => -Math.cos(t) },
  { k: 'in phase', sub: 'the sign is inverted', pct: '0 %',
    verdict: 'PUMPS', col: 'var(--bad)', f: (t) => Math.sin(t) },
]

const xs = Array.from({ length: N + 1 }, (_, i) => (i / N) * CYC * 2 * Math.PI)
const px = (t) => (t / (CYC * 2 * Math.PI)) * W
const py = (v, amp) => MID - v * amp

const line = (fn, amp) => xs.map(t => `${px(t).toFixed(1)},${py(fn(t), amp).toFixed(1)}`).join(' ')

// the power curve, split into the part below zero (dissipating) and above
const power = (fn) => {
  const p = xs.map(t => fn(t) * vel(t))
  return p
}
const area = (fn, sign) => {
  const p = power(fn)
  let d = ''
  for (let i = 0; i <= N; i++) {
    const v = sign > 0 ? Math.max(0, p[i]) : Math.min(0, p[i])
    d += `${i ? 'L' : 'M'}${px(xs[i]).toFixed(1)},${(MID - v * 22).toFixed(1)}`
  }
  d += `L${W},${MID} L0,${MID} Z`
  return d
}
</script>

<template>
<svg viewBox="0 0 728 138" class="w-full" role="img"
     aria-label="Three phase relationships between force and velocity: anti-phase dissipates on every step, quarter-period delay does no net work, in-phase pumps.">
  <g v-for="(p, i) in PANELS" :key="p.k" :transform="`translate(${i * 250}, 16)`">

    <!-- the panel the two curves live in -->
    <rect x="0" y="0" :width="W" :height="H" rx="3" fill="var(--panel)" stroke="var(--line)"/>

    <!-- power: green below the axis is energy leaving, red above is energy in -->
    <path :d="area(p.f, -1)" fill="var(--good)" fill-opacity="0.28"/>
    <path :d="area(p.f, +1)" fill="var(--bad)" fill-opacity="0.30"/>
    <line x1="0" :y1="MID" :x2="W" :y2="MID" stroke="var(--line-2)"/>

    <!-- velocity: the same in all three panels, so it is the quiet one -->
    <polyline :points="line(vel, 24)" fill="none" stroke="var(--dim)"
              stroke-width="1.3" stroke-dasharray="3 2.5"/>
    <!-- force: the one thing that changes between panels -->
    <polyline :points="line(p.f, 24)" fill="none" :stroke="p.col" stroke-width="1.8"/>

    <text x="0" y="-5" font-size="9.5" :fill="p.col" font-weight="600">{{ p.k.toUpperCase() }}</text>
    <text x="0" :y="H + 15" font-size="8.5" fill="var(--faint)">{{ p.sub }}</text>
    <text :x="W" :y="H + 15" font-size="10" :fill="p.col" text-anchor="end"
          font-weight="600">{{ p.pct }} &middot; {{ p.verdict }}</text>
  </g>

  <!-- legend: three encodings repeat across all three panels, so it earns one -->
  <g transform="translate(0, 128)" font-size="8.5" fill="var(--faint)">
    <line x1="0" y1="-3" x2="18" y2="-3" stroke="var(--dim)" stroke-width="1.3" stroke-dasharray="3 2.5"/>
    <text x="23" y="0">velocity</text>
    <line x1="76" y1="-3" x2="94" y2="-3" stroke="var(--ink)" stroke-width="1.8"/>
    <text x="99" y="0">force the coil applies</text>
    <rect x="216" y="-8" width="11" height="7" fill="var(--good)" fill-opacity="0.28"/>
    <text x="232" y="0">energy leaving the mirror</text>
    <rect x="376" y="-8" width="11" height="7" fill="var(--bad)" fill-opacity="0.30"/>
    <text x="392" y="0">energy going in</text>
    <text x="728" y="0" fill="var(--dim)" text-anchor="end">per cent = steps shaded green</text>
  </g>
</svg>
</template>
