<script setup>
// The whole experiment as one picture. Nothing here is hidden behind a click:
// the deck is meant to be readable on paper.
const BOX = [
  { t: 'THE MIRROR',    s: 'Hangs on wires. Once nudged it keeps swinging for minutes.', out: 'it moves', col: 'var(--ink)' },
  { t: 'SHADOW SENSOR', s: 'A flag on the mirror cuts a light beam. Position becomes a number.', out: '0 to 1023 counts, 581 times a second', col: 'var(--cA)' },
  { t: 'THE COMPUTER',  s: 'Works out how fast the mirror is moving, multiplies by a gain, flips the sign.', out: 'a voltage, 100 times a second', col: 'var(--brass)' },
  { t: 'COIL',          s: 'Current through a coil pushes on a magnet glued to the mirror.', out: 'a force', col: 'var(--cC)' },
]
const W = 158, H = 56, GAP = 22, X0 = 8, Y0 = 20
const xOf = i => X0 + i * (W + GAP)
</script>

<template>
<svg viewBox="0 0 728 196" class="w-full">
  <g v-for="(b, i) in BOX" :key="b.t">
    <rect :x="xOf(i)" :y="Y0" :width="W" :height="H" rx="3"
          fill="var(--panel)" stroke="var(--line-2)" stroke-width="1.2"/>
    <text :x="xOf(i)+10" :y="Y0+19" font-size="10.5" font-weight="600" :fill="b.col">{{ b.t }}</text>
    <foreignObject :x="xOf(i)+8" :y="Y0+26" :width="W-16" :height="H-28">
      <div xmlns="http://www.w3.org/1999/xhtml"
           style="font-family:var(--sans); font-size:8.6px; line-height:1.35; color:var(--dim)">
        {{ b.s }}
      </div>
    </foreignObject>

    <!-- what leaves this box -->
    <text :x="xOf(i)+W/2" :y="Y0+H+16" text-anchor="middle" font-size="8.6" fill="var(--faint)">
      {{ b.out }}</text>

    <!-- arrow to the next box -->
    <g v-if="i < 3" stroke="var(--line-2)" stroke-width="1.3">
      <line :x1="xOf(i)+W+2" :y1="Y0+H/2" :x2="xOf(i)+W+GAP-8" :y2="Y0+H/2"/>
      <polygon :points="`${xOf(i)+W+GAP-2},${Y0+H/2} ${xOf(i)+W+GAP-9},${Y0+H/2-4} ${xOf(i)+W+GAP-9},${Y0+H/2+4}`"
               fill="var(--line-2)" stroke="none"/>
    </g>
  </g>

  <!-- the return path: this is the only line that makes it a loop -->
  <path :d="`M ${xOf(3)+W} ${Y0+H+30} L ${xOf(3)+W} 140 L ${xOf(0)+W/2} 140 L ${xOf(0)+W/2} ${Y0+H+6}`"
        fill="none" stroke="var(--brass)" stroke-width="1.4" stroke-dasharray="5 4"/>
  <polygon :points="`${xOf(0)+W/2},${Y0+H+2} ${xOf(0)+W/2-4},${Y0+H+10} ${xOf(0)+W/2+4},${Y0+H+10}`"
           fill="var(--brass)"/>
  <text x="364" y="134" text-anchor="middle" font-size="9.5" fill="var(--brass)">
    the force changes the position, which changes the reading. That is the loop.</text>

  <!-- the one detail that costs a whole slide later -->
  <g>
    <line x1="8" y1="156" x2="720" y2="156" stroke="var(--line)"/>
    <text x="8" y="174" font-size="9.5" fill="var(--dim)">
      Two different clocks live in this picture.</text>
    <text x="8" y="188" font-size="9" fill="var(--faint)">
      The computer averages whatever turned up in between. Getting that wrong is how a damper turns into a shaker.</text>
  </g>
</svg>
</template>
