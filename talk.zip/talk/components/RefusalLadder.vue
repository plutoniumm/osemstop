<script setup>
import { ref, computed } from 'vue'

// Before it energises a single coil the controller asks five questions about
// the measured tables it was handed. A "no" anywhere does not stop the run.
// It drops back to the cruder law that needs no tables, and says so out loud.
const CHECKS = [
  { q: 'Is the file of measured tables there at all?', fail: 'no file' },
  { q: 'Was it written by this version of the code?', fail: 'stale file' },
  { q: 'Can the coils actually reach all three motions?', fail: 'one direction unreachable' },
  { q: 'Do the sensor and coil tables agree about which coil moves which sensor?', fail: 'they disagree' },
  { q: 'Does the model explain what the sensors are reading right now?', fail: 'model does not fit' },
]
const state = ref(CHECKS.map(() => true))
const firstFail = computed(() => state.value.findIndex(v => !v))
const full = computed(() => firstFail.value < 0)
</script>

<template>
<div class="cols-w">
  <div class="stack-tight">
    <div v-for="(c, i) in CHECKS" :key="c.q"
         style="display:flex; align-items:center; gap:.6rem; padding:.42rem .6rem; border-radius:4px; border:1px solid"
         :style="{
           borderColor: firstFail >= 0 && i > firstFail ? 'var(--line)'
                      : state[i] ? 'var(--good)' : 'var(--bad)',
           opacity: firstFail >= 0 && i > firstFail ? 0.32 : 1 }">
      <button @click="state[i] = !state[i]"
        style="width:20px; height:20px; border-radius:3px; flex:none; border:1px solid; background:transparent; cursor:pointer; font-family:var(--mono); font-size:11px; line-height:1"
        :style="{ borderColor: state[i] ? 'var(--good)' : 'var(--bad)',
                  color: state[i] ? 'var(--good)' : 'var(--bad)' }">
        {{ state[i] ? '✓' : '✗' }}
      </button>
      <span style="font-size:var(--fs-sm); color:var(--dim); flex:1">{{ c.q }}</span>
      <span v-if="!state[i]" class="cap bad mono">{{ c.fail }}</span>
    </div>
    <div class="cap mt2">Click a tick to make it a cross.</div>
  </div>

  <div class="stack-tight">
    <div class="panel" style="text-align:center; padding:1rem .9rem"
         :style="{ borderLeft: '2px solid ' + (full ? 'var(--cA)' : 'var(--cB)') }">
      <span class="k">what the rig will actually run</span>
      <div class="stat" :style="{ color: full ? 'var(--cA)' : 'var(--cB)' }" style="font-size:1.05rem">
        {{ full ? 'ALL FOUR COILS TOGETHER' : 'FOUR SEPARATE LOOPS' }}
      </div>
      <div class="cap">
        measured decay <span class="num">{{ full ? '0.1093' : '0.0305' }}</span> per second
      </div>
    </div>
    <div class="cap">
      <b>The trap.</b> A refusal is invisible in the score. Three trials once looked
      exactly like the crude law -- because the ladder had quietly refused all three.
    </div>
  </div>
</div>
</template>
