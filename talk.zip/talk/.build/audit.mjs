// Overflow auditor.
//
// Slidev renders every slide into a fixed 980 x 552 canvas and then scales that
// canvas to the window. Anything taller than the canvas is clipped in the
// browser and cut off in the PDF -- it does not scroll, it just vanishes. So
// overflow here is a correctness bug, not a matter of taste, and eyeballing it
// at 60% scale does not find it.
//
// This drives chrome-headless-shell over the DevTools protocol against the
// BUILT dist/, sets the viewport to exactly the canvas size so no scaling is in
// play, and for every slide measures
//
//   scrollHeight vs clientHeight   on the slide root, and
//   the deepest descendant rect    against the slide's own rect
//
// The second check matters because an absolutely positioned or negative-margin
// child overflows without ever changing the parent's scrollHeight.
//
// Usage:  node .build/audit.mjs [--json out.json] [--slides 1,2,3]
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

const CANVAS_W = 980
const CANVAS_H = 552
// Derived from the pid, so concurrent runs do not fight over a socket.
const PORT_BASE = 4200 + (process.pid % 900) * 2
const PORT = PORT_BASE
const CDP_PORT = PORT_BASE + 1
const SHELL = path.join(os.homedir(),
  'Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell')

const argv = process.argv.slice(2)
const jsonOut = argv.includes('--json') ? argv[argv.indexOf('--json') + 1] : null
const onlySlides = argv.includes('--slides')
  ? argv[argv.indexOf('--slides') + 1].split(',').map(Number) : null

const sleep = ms => new Promise(r => setTimeout(r, ms))

function countSlides () {
  const md = fs.readFileSync(path.resolve('slides.md'), 'utf8')
  // frontmatter blocks and slide separators are both bare `---` at line start;
  // the deck's own rule is that a bare --- never appears inside a slide.
  const lines = md.split('\n')
  let n = 1
  let inFm = false
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim() !== '---') continue
    if (i === 0) { inFm = true; continue }
    if (inFm) { inFm = false; continue }
    // a `---` immediately followed by `key: value` opens per-slide frontmatter
    const next = (lines[i + 1] || '').trim()
    n++
    if (/^[a-zA-Z_][\w-]*\s*:/.test(next)) inFm = true
  }
  return n
}

// ---------------------------------------------------------------- CDP client
class CDP {
  constructor (ws) { this.ws = ws; this.id = 0; this.pending = new Map(); this.sessions = new Map()
    ws.addEventListener('message', e => {
      const m = JSON.parse(e.data)
      if (m.id && this.pending.has(m.id)) {
        const { resolve, reject } = this.pending.get(m.id); this.pending.delete(m.id)
        m.error ? reject(new Error(m.error.message)) : resolve(m.result)
      }
    })
  }
  static async connect (url) {
    const ws = new WebSocket(url)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    return new CDP(ws)
  }
  send (method, params = {}, sessionId) {
    const id = ++this.id
    this.ws.send(JSON.stringify({ id, method, params, sessionId }))
    return new Promise((resolve, reject) => this.pending.set(id, { resolve, reject }))
  }
}

// ------------------------------------------------------------ the measurement
const PROBE = `(() => {
  // every slide is in the DOM at once; only the routed one is display:block.
  const page = [...document.querySelectorAll('.slidev-page')]
    .find(p => p.getBoundingClientRect().height > 0)
  if (!page) return { error: 'no visible page' }
  const layout = page.querySelector('.slidev-layout') || page
  const idx = (page.className.match(/slidev-page-(\\d+)/) || [])[1]
  const box = layout.getBoundingClientRect()
  const limitB = box.top + ${CANVAS_H}
  const limitR = box.left + ${CANVAS_W}
  let worstB = 0, worstR = 0, whoB = '', whoR = ''
  const name = el => el.tagName.toLowerCase() +
    (el.className ? '.' + el.className.toString().split(/\\s+/).filter(Boolean).slice(0, 3).join('.') : '')
  for (const el of layout.querySelectorAll('*')) {
    // Children of an <svg> are clipped to the viewBox, and KaTeX's stretchy
    // glyphs are paths with enormous bboxes scaled down by a transform, so
    // their rects are meaningless. Measure the <svg> box itself instead.
    if (el.ownerSVGElement) continue
    const cs = getComputedStyle(el)
    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.position === 'fixed') continue
    if (cs.overflow === 'hidden' || cs.overflowY === 'hidden') { /* still measure the box itself */ }
    const r = el.getBoundingClientRect()
    if (r.width === 0 && r.height === 0) continue
    const ob = r.bottom - limitB
    const or = r.right - limitR
    if (ob > worstB) { worstB = ob; whoB = name(el) + ' | ' + (el.textContent || '').trim().slice(0, 40) }
    if (or > worstR) { worstR = or; whoR = name(el) + ' | ' + (el.textContent || '').trim().slice(0, 40) }
  }
  // ---- text spilling out of its own SVG --------------------------------
  // An <svg> clips to its viewBox, so a <text> placed past the right edge is
  // silently cut at EVERY size -- it does not show up as page overflow and it
  // does not show up at 60 % zoom. This is the second correctness bug in the
  // deck's figures, and it is only findable by measuring.
  const clipped = []
  for (const svg of layout.querySelectorAll('svg')) {
    const sb = svg.getBoundingClientRect()
    if (sb.width === 0) continue
    for (const t of svg.querySelectorAll('text')) {
      const tb = t.getBoundingClientRect()
      if (tb.width === 0) continue
      const over = Math.max(tb.right - sb.right, sb.left - tb.left,
                            tb.bottom - sb.bottom, sb.top - tb.top)
      if (over > 1) clipped.push({ over: Math.round(over), s: (t.textContent || '').trim().slice(0, 34) })
    }
  }

  // ---- prose vs visual -------------------------------------------------
  // running prose = sentence text the reader has to READ. Labels, headings,
  // pills, table cells, code and SVG text are excluded: they are read at a
  // glance, not as sentences.
  const PROSE_SEL = 'p, .lede, .figcap, .def, .bm, .cap, blockquote, li'
  const SCAFFOLD = '.lede, .figcap, .bridge, .sd'
  const isInside = (el, sel) => !!el.closest(sel)
  let words = 0, scaffold = 0
  const seen = new Set()
  for (const el of layout.querySelectorAll(PROSE_SEL)) {
    if (isInside(el, 'table, pre, svg, .rail')) continue
    let skip = false
    for (const a of seen) if (a.contains(el)) { skip = true; break }
    if (skip) continue
    seen.add(el)
    const t = (el.innerText || '').replace(/\\s+/g, ' ').trim()
    if (t) {
      const n = t.split(' ').filter(w => /[a-zA-Z]/.test(w)).length
      words += n
      if (el.matches(SCAFFOLD) || el.closest(SCAFFOLD)) scaffold += n
    }
  }
  // visual area: diagrams, charts, tables, code and images
  const area = el => { const r = el.getBoundingClientRect(); return Math.max(0, r.width) * Math.max(0, r.height) }
  let visArea = 0
  const vSeen = []
  for (const el of layout.querySelectorAll('svg, table, pre, canvas, img, .slidev-code-wrapper')) {
    if (vSeen.some(a => a.contains(el))) continue
    vSeen.push(el); visArea += area(el)
  }
  let proseArea = 0
  for (const el of seen) proseArea += area(el)

  return {
    routed: Number(idx),
    words,
    scaffold,
    clipped,
    visArea: Math.round(visArea),
    proseArea: Math.round(proseArea),
    scrollOver: Math.max(0, layout.scrollHeight - ${CANVAS_H}),
    contentH: Math.round(layout.scrollHeight),
    bottom: Math.round(worstB * 10) / 10,
    right: Math.round(worstR * 10) / 10,
    whoB, whoR,
    title: ((layout.querySelector('h1, h2') || {}).textContent || '').trim(),
  }
})()`

async function main () {
  const total = onlySlides ? Math.max(...onlySlides) : countSlides()
  const server = spawn(process.execPath, ['.build/serve.mjs', 'dist', String(PORT)], { stdio: 'ignore' })
  const chrome = spawn(SHELL, [
    `--remote-debugging-port=${CDP_PORT}`,
    '--headless=new', '--disable-gpu', '--hide-scrollbars',
    '--no-sandbox', '--disable-dev-shm-usage',
    `--window-size=${CANVAS_W},${CANVAS_H}`,
    'about:blank',
  ], { stdio: 'ignore' })
  const kill = () => { try { server.kill() } catch {} ; try { chrome.kill() } catch {} }
  process.on('exit', kill)

  let wsUrl = null
  for (let i = 0; i < 60 && !wsUrl; i++) {
    await sleep(250)
    try {
      const r = await fetch(`http://127.0.0.1:${CDP_PORT}/json/version`)
      wsUrl = (await r.json()).webSocketDebuggerUrl
    } catch {}
  }
  if (!wsUrl) { console.error('chrome did not come up'); kill(); process.exit(1) }

  const cdp = await CDP.connect(wsUrl)
  const { targetId } = await cdp.send('Target.createTarget', { url: 'about:blank' })
  const { sessionId } = await cdp.send('Target.attachToTarget', { targetId, flatten: true })
  const S = sessionId
  await cdp.send('Page.enable', {}, S)
  await cdp.send('Runtime.enable', {}, S)
  await cdp.send('Emulation.setDeviceMetricsOverride',
    { width: CANVAS_W, height: CANVAS_H, deviceScaleFactor: 1, mobile: false }, S)

  const rows = []
  const list = onlySlides || Array.from({ length: total }, (_, i) => i + 1)
  for (const n of list) {
    await cdp.send('Page.navigate', { url: `http://127.0.0.1:${PORT}/${n}` }, S)
    // wait for the slide to render and for fonts/components to settle
    let res = null
    for (let t = 0; t < 50; t++) {
      await sleep(100)
      const r = await cdp.send('Runtime.evaluate',
        { expression: PROBE, returnByValue: true }, S).catch(() => null)
      const v = r && r.result && r.result.value
      if (v && !v.error && v.routed === n && t >= 3) { res = v; break }
    }
    if (!res) { rows.push({ n, error: true, bottom: 0, right: 0, scrollOver: 0, title: '' }); continue }
    rows.push({ n, ...res })
  }

  const TOL = 1.0
  const bad = rows.filter(r => r.error || r.bottom > TOL || r.right > TOL || r.scrollOver > TOL)
  console.log(`\nslides measured: ${rows.length}   canvas ${CANVAS_W}x${CANVAS_H}`)
  console.log(`OVERFLOWING: ${bad.length}\n`)
  for (const r of bad) {
    if (r.error) { console.log(`  ${String(r.n).padStart(3)}  RENDER ERROR`); continue }
    console.log(`  ${String(r.n).padStart(3)}  +${String(r.bottom.toFixed(0)).padStart(4)}px down` +
      (r.right > TOL ? `  +${r.right.toFixed(0)}px right` : '          ') +
      `  h=${r.contentH}  ${r.whoB || r.whoR}  |  ${r.title.trim().slice(0, 46)}`)
  }
  const ok = rows.filter(r => !r.error)
  const totalWords = ok.reduce((a, r) => a + (r.words || 0), 0)
  const over60 = ok.filter(r => (r.words || 0) > 60)
  const visual = ok.filter(r => (r.visArea || 0) >= (r.proseArea || 0) && (r.visArea || 0) > 0)
  console.log(`\nrunning prose, deck-wide: ${totalWords} words   (median ${
    ok.map(r => r.words).sort((a, b) => a - b)[Math.floor(ok.length / 2)]}/slide, max ${
    Math.max(...ok.map(r => r.words))})`)
  const totalScaffold = ok.reduce((a, r) => a + (r.scaffold || 0), 0)
  console.log(`  of which lede + bridge + caption scaffolding: ${totalScaffold}` +
    `   body prose: ${totalWords - totalScaffold}`)
  console.log(`slides over the 60-word line: ${over60.length} / ${ok.length}` +
    `   over 60 on BODY prose alone: ${ok.filter(r => (r.words - r.scaffold) > 60).length}`)
  console.log(`visual-led slides (diagram/table/code area >= prose area): ${visual.length} / ${ok.length}`)
  if (argv.includes('--verbose')) {
    console.log('\nwordiest:')
    for (const r of [...ok].sort((a, b) => b.words - a.words).slice(0, 25))
      console.log(`  ${String(r.n).padStart(3)}  ${String(r.words).padStart(4)}w  vis=${
        String(r.visArea).padStart(6)} prose=${String(r.proseArea).padStart(6)}  ${r.title.slice(0, 50)}`)
  }
  const clippedRows = ok.filter(r => (r.clipped || []).length)
  console.log(`slides with text clipped by its own SVG viewBox: ${clippedRows.length}`)
  for (const r of clippedRows)
    for (const c of r.clipped)
      console.log(`  ${String(r.n).padStart(3)}  +${String(c.over).padStart(4)}px  "${c.s}"`)
  if (jsonOut) fs.writeFileSync(jsonOut, JSON.stringify(rows, null, 1))
  kill()
  process.exit(0)
}
main().catch(e => { console.error(e); process.exit(1) })
