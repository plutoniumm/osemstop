import { defineConfig } from 'vite'

// Served behind a reverse proxy at p3000.gojira.manav.ch, so two things that
// are fine on localhost have to be set explicitly:
//
//   host          bind 0.0.0.0 rather than [::1]. Slidev's default binds
//                 loopback only, which a proxy on another interface cannot
//                 reach -- the symptom is 502 Bad Gateway with the dev server
//                 apparently running fine.
//   allowedHosts  Vite checks the Host header and refuses anything it does not
//                 know, to stop DNS-rebinding attacks. Behind a proxy the Host
//                 is the public name, not localhost, so it must be listed or
//                 the page dies with "Blocked request ... not allowed".
export default defineConfig({
  server: {
    host: true,
    port: 3000,
    strictPort: true,
    allowedHosts: ['p3000.gojira.manav.ch', '.manav.ch', 'localhost'],
    hmr: { clientPort: 443, protocol: 'wss' },
  },
})
