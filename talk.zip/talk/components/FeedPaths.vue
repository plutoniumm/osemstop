<script setup>
// The two structures differ by one arrow. Feedforward acts on a prediction of
// the disturbance and never learns whether it worked; feedback acts on the
// measured output, which is what makes it insensitive to model error and also
// what makes it capable of instability.
</script>

<template>
<svg viewBox="0 0 726 218" class="w-full">
  <!-- ============================ FEEDFORWARD ========================= -->
  <text x="8" y="14" font-size="10" fill="var(--c-dist)" font-weight="600">FEEDFORWARD</text>
  <text x="112" y="14" font-size="9" fill="var(--faint)">acts on a prediction of the disturbance</text>

  <g fill="var(--panel)">
    <rect x="8"   y="26" width="118" height="44" rx="3" stroke="var(--c-dist)"/>
    <rect x="182" y="26" width="118" height="44" rx="3" stroke="var(--c-model)"/>
    <rect x="356" y="26" width="118" height="44" rx="3" stroke="var(--c-act)"/>
  </g>
  <g font-size="10" fill="var(--ink)" text-anchor="middle">
    <text x="67"  y="45">disturbance</text>
    <text x="241" y="45">model of it</text>
    <text x="415" y="45">actuator</text>
  </g>
  <g font-size="8" fill="var(--faint)" text-anchor="middle">
    <text x="67"  y="59">measured or predicted</text>
    <text x="241" y="59">its effect on the plant</text>
    <text x="415" y="59">the opposing input</text>
  </g>
  <g stroke="var(--c-dist)" stroke-width="1.4" fill="none" marker-end="url(#ff)">
    <line x1="126" y1="48" x2="176" y2="48"/>
    <line x1="300" y1="48" x2="350" y2="48"/>
    <line x1="474" y1="48" x2="536" y2="48"/>
  </g>
  <rect x="538" y="26" width="112" height="44" rx="3" fill="var(--panel-2)" stroke="var(--c-plant)"/>
  <text x="594" y="45" font-size="10" fill="var(--ink)" text-anchor="middle">the plant</text>
  <text x="594" y="59" font-size="8" fill="var(--faint)" text-anchor="middle">responds</text>
  <text x="718" y="80" font-size="8.5" fill="var(--faint)" text-anchor="end">no return path: the result is never measured</text>

  <line x1="8" y1="86" x2="718" y2="86" stroke="var(--line)"/>

  <!-- ============================= FEEDBACK =========================== -->
  <text x="8" y="112" font-size="10" fill="var(--c-plant)" font-weight="600">FEEDBACK</text>
  <text x="92" y="112" font-size="9" fill="var(--faint)">acts on the measured result</text>

  <g fill="var(--panel)">
    <rect x="8"   y="124" width="118" height="44" rx="3" stroke="var(--c-plant)"/>
    <rect x="182" y="124" width="118" height="44" rx="3" stroke="var(--c-meas)"/>
    <rect x="356" y="124" width="118" height="44" rx="3" stroke="var(--c-act)"/>
    <rect x="530" y="124" width="118" height="44" rx="3" stroke="var(--c-act)"/>
  </g>
  <g font-size="10" fill="var(--ink)" text-anchor="middle">
    <text x="67"  y="143">the plant</text>
    <text x="241" y="143">sensor</text>
    <text x="415" y="143">controller</text>
    <text x="589" y="143">actuator</text>
  </g>
  <g font-size="8" fill="var(--faint)" text-anchor="middle">
    <text x="67"  y="157">responds to everything</text>
    <text x="241" y="157">measures the output</text>
    <text x="415" y="157">acts on the error</text>
    <text x="589" y="157">a force</text>
  </g>
  <g stroke="var(--c-plant)" stroke-width="1.4" fill="none" marker-end="url(#fb)">
    <line x1="126" y1="146" x2="176" y2="146"/>
    <line x1="300" y1="146" x2="350" y2="146"/>
    <line x1="474" y1="146" x2="524" y2="146"/>
  </g>
  <path d="M648 146 L676 146 L676 196 L67 196 L67 174" fill="none"
        stroke="var(--c-meas)" stroke-width="1.4" stroke-dasharray="4 3" marker-end="url(#fbm)"/>
  <text x="372" y="210" font-size="9" fill="var(--c-meas)" text-anchor="middle" font-weight="600">
    feeding the error back</text>


  <defs>
    <marker id="ff" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--c-dist)"/></marker>
    <marker id="fb" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--c-plant)"/></marker>
    <marker id="fbm" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--c-meas)"/></marker>
  </defs>
</svg>
</template>
