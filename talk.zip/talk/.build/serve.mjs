// Minimal static server for dist/ with SPA fallback -- used by audit.mjs.
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = path.resolve(process.argv[2] || 'dist')
const PORT = Number(process.argv[3] || 4173)
const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2',
  '.woff': 'font/woff', '.ttf': 'font/ttf', '.ico': 'image/x-icon',
}

http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0])
  let file = path.join(ROOT, p)
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    const idx = path.join(file, 'index.html')
    file = fs.existsSync(idx) && fs.statSync(idx).isFile() ? idx : path.join(ROOT, 'index.html')
  }
  const body = fs.readFileSync(file)
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' })
  res.end(body)
}).listen(PORT, () => console.log('serving ' + ROOT + ' on ' + PORT))
