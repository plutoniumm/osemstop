<script setup>
// Learn the dynamics, not the policy -- as the one arrow that differs.
//
// A policy maps state straight to a command, so the plant and the controller are
// fused inside it and there is nothing left over to check. A dynamics model
// makes a claim about what happens next, and the world answers that claim every
// control step. The extra arrow is the comparison, and it is the whole argument.
//
// The event drawn on both rows is the same one: a coil starts pushing
// differently from the way it used to.
</script>

<template>
<svg viewBox="0 0 728 210" class="w-full" role="img"
     aria-label="A learned policy maps state to command with nothing to check; a learned dynamics model predicts the next state, which the world contradicts when the plant changes.">

  <!-- ================================ POLICY ============================= -->
  <text x="6" y="12" font-size="10" fill="var(--bad)" font-weight="600">A LEARNED POLICY</text>

  <g stroke="var(--line-2)" fill="var(--panel)">
    <rect x="6"   y="22" width="104" height="34" rx="3"/>
    <rect x="162" y="22" width="118" height="34" rx="3"/>
    <rect x="332" y="22" width="104" height="34" rx="3"/>
  </g>
  <g font-size="9.5" fill="var(--ink)" text-anchor="middle">
    <text x="58"  y="43">state</text>
    <text x="221" y="43">the network</text>
    <text x="384" y="43">actuator command</text>
  </g>
  <g stroke="var(--bad)" stroke-width="1.4" fill="none" marker-end="url(#pm-bad)">
    <line x1="110" y1="39" x2="156" y2="39"/>
    <line x1="280" y1="39" x2="326" y2="39"/>
  </g>
  <text x="221" y="66" font-size="8.5" fill="var(--faint)" text-anchor="middle">
    plant and controller fused together</text>

  <text x="470" y="30" font-size="9" fill="var(--bad)" font-weight="600">THE PLANT CHANGES</text>
  <text x="470" y="43" font-size="8.5" fill="var(--faint)">it now pushes with the opposite sign</text>
  <text x="470" y="58" font-size="9.5" fill="var(--bad)" font-weight="600">
    it keeps commanding, and reports no error</text>

  <line x1="6" y1="86" x2="722" y2="86" stroke="var(--line)"/>

  <!-- ============================ DYNAMICS MODEL ========================= -->
  <text x="6" y="108" font-size="10" fill="var(--good)" font-weight="600">A LEARNED DYNAMICS MODEL</text>

  <g stroke="var(--line-2)" fill="var(--panel)">
    <rect x="6"   y="118" width="104" height="34" rx="3"/>
    <rect x="162" y="118" width="118" height="34" rx="3"/>
    <rect x="332" y="118" width="112" height="34" rx="3"/>
    <rect x="496" y="118" width="112" height="34" rx="3"/>
  </g>
  <g font-size="9.5" fill="var(--ink)" text-anchor="middle">
    <text x="58"  y="139">state, action</text>
    <text x="221" y="139">the network</text>
    <text x="388" y="139">predicted next</text>
    <text x="552" y="139">what happened</text>
  </g>
  <g stroke="var(--good)" stroke-width="1.4" fill="none" marker-end="url(#pm-good)">
    <line x1="110" y1="135" x2="156" y2="135"/>
    <line x1="280" y1="135" x2="326" y2="135"/>
  </g>

  <!-- the arrow that does not exist on the policy row -->
  <path d="M496 135 L452 135" fill="none" stroke="var(--brass)" stroke-width="1.8"
        marker-end="url(#pm-brass)"/>
  <text x="474" y="168" font-size="9.5" fill="var(--brass)" text-anchor="middle" font-weight="600">
    compared</text>
  <path d="M388 152 L388 178 L640 178" fill="none" stroke="var(--brass)" stroke-width="1.4"
        stroke-dasharray="4 3" marker-end="url(#pm-brass)"/>
  <text x="644" y="182" font-size="9.5" fill="var(--brass)" font-weight="600">&#967;&#178; climbs</text>
  <text x="6" y="200" font-size="9" fill="var(--good)" font-weight="600">
    the same change contradicts a prediction, so it is detectable</text>

  <defs>
    <marker id="pm-bad" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--bad)"/></marker>
    <marker id="pm-good" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--good)"/></marker>
    <marker id="pm-brass" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--brass)"/></marker>
  </defs>
</svg>
</template>
