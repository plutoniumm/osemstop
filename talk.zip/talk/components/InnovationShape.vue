<script setup>
// chi-squared is one number. The innovation it is computed from is a VECTOR,
// and different faults put their disagreement in different places.
//
// Same chi-squared, three completely different causes. That is the whole
// argument for learning a classifier on the innovation instead of thresholding
// its length. The illustrative shapes below are the signatures each fault has
// by construction, not measured examples.
import { ref } from 'vue'

const CASES = [
  { id: 'coil',   name: 'the plant has changed',
    v: [0.958, 0.213, -0.160, 0.106],
    tell: 'One channel disagrees and stays disagreeing. Whatever it was paired with is behaving differently from yesterday.',
    col: 'var(--bad)' },
  { id: 'sensor', name: 'a sensor has glitched',
    v: [0.154, -0.103, 0.975, 0.123],
    tell: 'A large disagreement on one channel, in a shape no real motion can make. It lands in the null space.',
    col: 'var(--cD)' },
  { id: 'bump',   name: 'somebody knocked the table',
    v: [0.527, 0.493, -0.468, -0.510],
    tell: 'Every channel disagrees at once, in a pattern that IS a real motion. Nothing is broken; the model just did not expect a shove.',
    col: 'var(--cA)' },
]
const pick = ref(0)
const W = 300, H = 118, PL = 30, MID = 62, SC = 42
const bw = (W - PL - 14) / 4
</script>

<template>
<div class="cols-w" style="gap:1rem">
  <div>
    <svg :viewBox="`0 0 ${W} ${H}`" class="w-full">
      <line :x1="PL - 6" :y1="MID" :x2="W - 8" :y2="MID" stroke="var(--line-2)"/>
      <text x="6" :y="MID + 3" font-size="8" fill="var(--faint)">0</text>
      <text x="6" y="14" font-size="8" fill="var(--faint)">disagreement</text>

      <g v-for="(x, i) in CASES[pick].v" :key="i">
        <rect :x="PL + i * bw + 4"
              :y="x >= 0 ? MID - x * SC : MID"
              :width="bw - 8" :height="Math.abs(x) * SC"
              :fill="CASES[pick].col" opacity="0.85"/>
        <text :x="PL + i * bw + bw / 2" :y="H - 6" text-anchor="middle"
              font-size="8.5" fill="var(--faint)">a{{ i }}</text>
      </g>
    </svg>
    <div class="cap" style="margin-top:.2rem">
      Each bar is one sensor's share of <span class="mono">y &minus; H x&#770;&#8315;</span>.
      <b style="color:var(--ink)">All three have the same length</b>, so the same
      chi-squared. Only the shape tells them apart.
    </div>
  </div>

  <div class="stack-tight">
    <button v-for="(c, i) in CASES" :key="c.id" class="btn"
            :class="{ on: pick === i }" @click="pick = i">
      <span class="btn-t">{{ c.name }}</span>
      <span class="btn-s">{{ c.tell }}</span>
    </button>
  </div>
</div>
</template>
