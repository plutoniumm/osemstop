<script setup>
// Where the confidence number comes from, and what it is allowed to do.
//
// Train N copies of the same network on the same logged data, differing only
// in initialisation and in which bootstrap sample they see. Inside the region
// the data covers they are forced to agree, because the data pins them down.
// Outside it nothing pins them down, so they fan out -- and the SPREAD of
// their means is a measure of "no evidence here" that costs nothing extra to
// compute.
//
// The band around the middle is a different quantity: the variance each member
// predicts for itself. It is the noise in the process, it does not grow
// outside the data, and it is NOT a safety signal.
//
// The strip underneath is the only thing that touches an actuator: a factor
// that multiplies the correction, near one where the members agree and near
// zero where they do not.
import { computed } from 'vue'

const XMIN = -3, XMAX = 3, DATA = 1.3
const A = [-1.0, -0.5, 0, 0.5, 1.0]            // one per ensemble member
const VAR_A = A.reduce((s, a) => s + a * a, 0) / A.length
const SIG = 0.15                               // the noise each member predicts
const TAU = 0.55

const f = x => 0.55 * Math.sin(1.5 * x)
const h = x => Math.pow(Math.max(0, Math.abs(x) - DATA), 1.7) * 0.75
const epi = x => VAR_A * h(x) * h(x)
const gate = x => Math.exp(-epi(x) / TAU)

// ---- top panel
const X0 = 62, X1 = 700, Y0 = 22, Y1 = 132
const YR = 2.6
const px = x => X0 + ((x - XMIN) / (XMAX - XMIN)) * (X1 - X0)
const py = v => (Y0 + Y1) / 2 - (v / YR) * ((Y1 - Y0) / 2)

const N = 240
const xs = Array.from({ length: N + 1 }, (_, i) => XMIN + (i / N) * (XMAX - XMIN))
const line = fn => 'M' + xs.map(x => px(x).toFixed(1) + ',' + py(fn(x)).toFixed(1)).join(' L')

const members = computed(() => A.map(a => line(x => f(x) + a * h(x))))
const band = computed(() =>
  'M' + xs.map(x => px(x).toFixed(1) + ',' + py(f(x) + SIG).toFixed(1)).join(' L') +
  ' L' + xs.slice().reverse().map(x => px(x).toFixed(1) + ',' + py(f(x) - SIG).toFixed(1)).join(' L') + ' Z')

// ---- gate strip
const G0 = 162, G1 = 208
const gy = g => G1 - g * (G1 - G0)
const gpath = computed(() =>
  'M' + xs.map(x => px(x).toFixed(1) + ',' + gy(gate(x)).toFixed(1)).join(' L') +
  ` L${px(XMAX).toFixed(1)},${G1} L${px(XMIN).toFixed(1)},${G1} Z`)

// the rug: where the training data actually is
const RUG = Array.from({ length: 34 }, (_, i) => -DATA + (i / 33) * 2 * DATA)
</script>

<template>
<svg viewBox="0 0 728 230" class="w-full" role="img"
     aria-label="Ensemble members agree where training data exists and fan out where it does not; the strip beneath shows the gate factor, near one inside the data and near zero outside it.">

  <!-- the region the training data covers -->
  <rect :x="px(-DATA)" :y="Y0" :width="px(DATA) - px(-DATA)" :height="G1 - Y0"
        fill="var(--c-model)" opacity=".05"/>
  <g stroke="var(--c-model)" stroke-opacity=".8">
    <line v-for="(x, i) in RUG" :key="i" :x1="px(x)" :y1="Y1 + 3" :x2="px(x)" :y2="Y1 + 9"/>
  </g>
  <text :x="px(0)" :y="Y1 + 20" font-size="8" fill="var(--c-model)" text-anchor="middle">every logged control step</text>

  <!-- what each member predicts for its own noise: does not grow outside the data -->
  <path :d="band" fill="var(--c-meas)" opacity=".30"/>

  <!-- the members themselves -->
  <path v-for="(d, i) in members" :key="i" :d="d" fill="none"
        stroke="var(--c-model)" stroke-width="1.4" :opacity="i === 2 ? .95 : .6"/>

  <g stroke="var(--line)">
    <line :x1="X0" :y1="Y1" :x2="X1" :y2="Y1"/>
    <line :x1="X0" :y1="Y0" :x2="X0" :y2="Y1"/>
  </g>
  <text x="18" :y="py(0) + 3" font-size="8" fill="var(--faint)">&#916;</text>
  <text x="18" :y="Y0 + 8" font-size="8" fill="var(--faint)">the</text>
  <text x="18" :y="Y0 + 18" font-size="8" fill="var(--faint)">residual</text>

  <text :x="px(0)" :y="Y0 + 12" font-size="8.5" fill="var(--c-model)" text-anchor="middle">members agree</text>
  <text :x="px(2.4)" :y="Y0 + 12" font-size="8.5" fill="var(--bad)" text-anchor="middle">and here they do not</text>
  <text :x="px(-2.9)" :y="Y1 - 6" font-size="8" fill="var(--c-meas)">shaded band: the noise each member
    predicts for itself, which does not grow outside the data</text>

  <!-- ============================== THE GATE =========================== -->
  <path :d="gpath" fill="var(--c-act)" opacity=".22"/>
  <path :d="gpath.slice(0, gpath.lastIndexOf(' L'))" fill="none" stroke="var(--c-act)" stroke-width="1.6"/>
  <g stroke="var(--line)">
    <line :x1="X0" :y1="G1" :x2="X1" :y2="G1"/>
    <line :x1="X0" :y1="G0" :x2="X0" :y2="G1"/>
  </g>
  <text x="18" :y="G0 + 6" font-size="8" fill="var(--c-act)">1</text>
  <text x="18" :y="G1" font-size="8" fill="var(--c-act)">0</text>
  <text :x="px(0)" :y="G0 + 16" font-size="8.5" fill="var(--c-act)" text-anchor="middle">correction allowed</text>
  <text :x="px(2.55)" :y="G0 - 6" font-size="8.5" fill="var(--faint)" text-anchor="middle">suppressed</text>
  <text :x="X0" :y="G1 + 15" font-size="8" fill="var(--faint)">a coordinate of the state, out to where nothing was ever recorded</text>
</svg>
</template>
