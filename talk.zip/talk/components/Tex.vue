<script setup>
// Markdown only renders $...$ when it sits in a markdown paragraph. Inside a
// raw <div> block (which is most of this deck) markdown never looks at the
// inline content, so the dollars come out as literal text. This component
// renders KaTeX directly, so maths looks identical wherever it appears.
//
//   <Tex e="\omega_n" />           inline
//   <Tex block e="J = \int ..." />   centred display
//
// SUBSTITUTIONS. Where a symbol in the final equation is standing in for
// something derived earlier, do NOT show the chain of equations. Show the
// final one, and hang the substitution under it in a brace:
//
//   <Tex block e="\gamma = \ub{\zeta\omega_n}{free plant} + \ub{\tfrac12 K_p}{the loop}" />
//
// \ub{maths}{label} -- brace under `maths`, label greyed and set small. The
// label is a class, not a hardcoded colour, so it follows the theme.
//
// THE LABEL IS TEXT MODE. It goes through \textsf, so a maths command inside
// it is a parse error -- `\ub{...}{\dot V}` fails where `\ub{...}{rate V
// changes}` is fine. With throwOnError false that failure renders the source
// in red on the slide rather than stopping the build, so run
// `node .build/tex.mjs` after touching any formula.
import katex from 'katex'
import 'katex/dist/katex.min.css'
import { computed } from 'vue'

const props = defineProps({
  e: { type: String, required: true },
  block: { type: Boolean, default: false },
})

const MACROS = {
  '\\ub': '\\underbrace{#1}_{\\htmlClass{ub-note}{\\scriptsize\\textsf{#2}}}',
}

const html = computed(() => katex.renderToString(props.e, {
  displayMode: props.block,
  throwOnError: false,
  strict: false,
  trust: ctx => ctx.command === '\\htmlClass',
  macros: MACROS,
  output: 'html',
}))
</script>

<template>
  <span v-if="!block" class="tex" v-html="html"></span>
  <div v-else class="tex tex-block" v-html="html"></div>
</template>

<style scoped>
.tex { white-space: nowrap; }
.tex-block { white-space: normal; margin: var(--s3) 0; }
</style>
