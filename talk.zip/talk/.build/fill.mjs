// How much of the 552px canvas each slide actually uses. Overflow is a bug and
// the auditor already finds it; the opposite failure -- a slide sitting in the
// top half with a dead lower third -- is invisible to it.
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
const PORT_BASE = 4200 + (process.pid % 900) * 2
const W = 980, H = 552, PORT = PORT_BASE, CDP_PORT = PORT_BASE + 1
const SHELL = path.join(os.homedir(),
  'Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell')
const sleep = ms => new Promise(r => setTimeout(r, ms))
class CDP {
  constructor (ws) { this.ws = ws; this.id = 0; this.pending = new Map()
    ws.addEventListener('message', e => { const m = JSON.parse(e.data)
      if (m.id && this.pending.has(m.id)) { const { resolve, reject } = this.pending.get(m.id)
        this.pending.delete(m.id); m.error ? reject(new Error(m.error.message)) : resolve(m.result) } }) }
  static async connect (u) { const ws = new WebSocket(u)
    await new Promise((r, j) => { ws.addEventListener('open', r); ws.addEventListener('error', j) })
    return new CDP(ws) }
  send (method, params = {}, sessionId) { const id = ++this.id
    this.ws.send(JSON.stringify({ id, method, params, sessionId }))
    return new Promise((res, rej) => this.pending.set(id, { resolve: res, reject: rej })) }
}
const PROBE = `(() => {
  const page = [...document.querySelectorAll('.slidev-page')].find(p => p.getBoundingClientRect().height > 0)
  if (!page) return { error: 1 }
  const L = page.querySelector('.slidev-layout') || page
  const box = L.getBoundingClientRect()
  let bot = box.top
  for (const el of L.children) {
    for (const n of [el, ...el.querySelectorAll('*')]) {
      if (n.ownerSVGElement) continue
      const cs = getComputedStyle(n); if (cs.display === 'none' || cs.visibility === 'hidden') continue
      const r = n.getBoundingClientRect(); if (!r.height) continue
      if (r.bottom > bot) bot = r.bottom
    }
  }
  return { routed: Number((page.className.match(/slidev-page-(\\d+)/) || [])[1]),
           used: Math.round(bot - box.top),
           title: ((L.querySelector('h1,h2') || {}).textContent || '').trim().slice(0, 48) }
})()`
const md = fs.readFileSync('slides.md', 'utf8').split('\n')
let total = 1, inFm = false
for (let i = 0; i < md.length; i++) { if (md[i].trim() !== '---') continue
  if (i === 0) { inFm = true; continue }
  if (inFm) { inFm = false; continue }
  total++; if (/^[a-zA-Z_][\w-]*\s*:/.test((md[i + 1] || '').trim())) inFm = true }
const server = spawn(process.execPath, ['.build/serve.mjs', 'dist', String(PORT)], { stdio: 'ignore' })
const chrome = spawn(SHELL, [`--remote-debugging-port=${CDP_PORT}`, '--headless=new', '--disable-gpu',
  '--hide-scrollbars', '--no-sandbox', `--window-size=${W},${H}`, 'about:blank'], { stdio: 'ignore' })
const kill = () => { try { server.kill() } catch {}; try { chrome.kill() } catch {} }
process.on('exit', kill)
let wsUrl = null
for (let i = 0; i < 60 && !wsUrl; i++) { await sleep(250)
  try { wsUrl = (await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/version`)).json()).webSocketDebuggerUrl } catch {} }
const cdp = await CDP.connect(wsUrl)
const { targetId } = await cdp.send('Target.createTarget', { url: 'about:blank' })
const { sessionId: S } = await cdp.send('Target.attachToTarget', { targetId, flatten: true })
await cdp.send('Page.enable', {}, S); await cdp.send('Runtime.enable', {}, S)
await cdp.send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 1, mobile: false }, S)
const rows = []
for (let n = 1; n <= total; n++) {
  await cdp.send('Page.navigate', { url: `http://127.0.0.1:${PORT}/${n}` }, S)
  let v = null
  for (let t = 0; t < 40; t++) { await sleep(100)
    const r = await cdp.send('Runtime.evaluate', { expression: PROBE, returnByValue: true }, S).catch(() => null)
    const x = r && r.result && r.result.value
    if (x && !x.error && x.routed === n && t >= 3) { v = x; break } }
  rows.push(v || { routed: n, used: 0, title: '?' })
}
rows.sort((a, b) => a.used - b.used)
console.log('canvas is 552px tall. Least-filled slides:\n')
for (const r of rows) console.log(`  ${String(r.routed).padStart(3)}  ${String(r.used).padStart(3)}px  ${
  String(Math.round(r.used / 552 * 100)).padStart(3)}%   ${r.title}`)
kill(); process.exit(0)
