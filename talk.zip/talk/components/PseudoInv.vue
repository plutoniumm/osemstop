<script setup>
// The pseudo-inverse, as geometry rather than algebra.
//
// Both halves of the modal law are a pseudo-inverse, and they solve OPPOSITE
// problems. Drawing them side by side is the fastest way to see that the
// superscript plus does two different jobs depending on the shape it is
// applied to.
//
//   TALL  Phi is 4x3.  Four readings, three motions. No exact answer, so take
//         the nearest point in the plane the motions span. What is left over is
//         the warp -- the check.
//   WIDE  A is 3x4.    Four coils, three motions. Infinitely many answers, so
//         take the shortest. The rest of the line is current spent for nothing.
</script>

<template>
<svg viewBox="0 0 728 250" class="w-full" role="img"
     aria-label="Left: more readings than motions, projected onto what the system can do, with the leftover as a free check. Right: more actuators than motions, so a whole line of inputs gives the same push and the shortest is chosen.">

  <!-- ================================ TALL =============================== -->
  <g fill="var(--c-meas)" fill-opacity=".3" stroke="var(--c-meas)" stroke-width=".8">
    <rect x="4" y="4" width="7" height="5"/><rect x="13" y="4" width="7" height="5"/>
    <rect x="4" y="11" width="7" height="5"/><rect x="13" y="11" width="7" height="5"/>
    <rect x="4" y="18" width="7" height="5"/><rect x="13" y="18" width="7" height="5"/>
    <rect x="4" y="25" width="7" height="5"/><rect x="13" y="25" width="7" height="5"/>
  </g>
  <text x="30" y="12" font-size="10" fill="var(--c-meas)" font-weight="600">TALL &middot; MORE EQUATIONS THAN UNKNOWNS</text>
  <text x="30" y="26" font-size="8.5" fill="var(--faint)">four readings, three things that could have caused them</text>

  <g transform="translate(0, 40)">
    <!-- the plane every rigid motion of the plate lives in -->
    <path d="M20,118 L150,72 L318,96 L188,146 Z" fill="var(--c-meas)" fill-opacity="0.10"
          stroke="var(--c-meas)" stroke-width="1.1"/>

    <!-- the reading sits off the plane; the drop to it is the residual -->
    <line x1="176" y1="34" x2="176" y2="106" stroke="var(--bad)" stroke-width="1.6"
          stroke-dasharray="3 2.5"/>
    <circle cx="176" cy="34" r="4.5" fill="var(--ink)"/>
    <circle cx="176" cy="106" r="4" fill="var(--c-meas)"/>

    <text x="172" y="26" font-size="9" fill="var(--ink)" text-anchor="end">what the sensors said</text>
    <text x="186" y="66" font-size="9" fill="var(--bad)" font-weight="600">the leftover</text>
    <text x="186" y="118" font-size="9" fill="var(--c-meas)">the nearest explanation</text>
    <text x="24" y="160" font-size="8.5" fill="var(--c-meas)">the reachable subspace</text>
  </g>

  <g transform="translate(4, 218)" font-size="9" fill="var(--dim)">
    <text x="0" y="0"><tspan font-family="var(--mono)" fill="var(--ink)">&#934;&#8314;</tspan>
      takes the nearest point in the plane.</text>
    <text x="0" y="14">The distance to it is <tspan fill="var(--bad)">a consistency check</tspan>, not an error.</text>
  </g>

  <line x1="364" y1="4" x2="364" y2="246" stroke="var(--line)"/>

  <!-- ================================ WIDE =============================== -->
  <g fill="var(--c-act)" fill-opacity=".3" stroke="var(--c-act)" stroke-width=".8">
    <rect x="384" y="8" width="7" height="5"/><rect x="393" y="8" width="7" height="5"/>
    <rect x="402" y="8" width="7" height="5"/><rect x="411" y="8" width="7" height="5"/>
    <rect x="384" y="15" width="7" height="5"/><rect x="393" y="15" width="7" height="5"/>
    <rect x="402" y="15" width="7" height="5"/><rect x="411" y="15" width="7" height="5"/>
    <rect x="384" y="22" width="7" height="5"/><rect x="393" y="22" width="7" height="5"/>
    <rect x="402" y="22" width="7" height="5"/><rect x="411" y="22" width="7" height="5"/>
  </g>
  <text x="422" y="12" font-size="10" fill="var(--c-act)" font-weight="600">WIDE &middot; FEWER EQUATIONS THAN UNKNOWNS</text>
  <text x="422" y="26" font-size="8.5" fill="var(--faint)">four commands, three forces they have to produce</text>

  <g transform="translate(384, 40)">
    <!-- every coil vector on this line produces the same push -->
    <line x1="16" y1="126" x2="300" y2="44" stroke="var(--c-act)" stroke-width="1.6"/>
    <text x="300" y="34" font-size="8.5" fill="var(--c-act)" text-anchor="end">
      every point on this line produces the required force</text>

    <circle cx="70" cy="110" r="3" fill="var(--faint)"/>
    <circle cx="250" cy="58" r="3" fill="var(--faint)"/>
    <g stroke="var(--faint)" stroke-width="1" stroke-dasharray="2 2">
      <line x1="22" y1="124" x2="70" y2="110"/>
      <line x1="22" y1="124" x2="250" y2="58"/>
    </g>

    <!-- the shortest one: the perpendicular from the origin -->
    <line x1="22" y1="124" x2="128" y2="93" stroke="var(--c-act)" stroke-width="2.4"
          marker-end="url(#pi-arrow)"/>
    <circle cx="22" cy="124" r="3.5" fill="var(--ink)"/>
    <text x="16" y="142" font-size="8.5" fill="var(--faint)">no effort at all</text>
    <text x="94" y="76" font-size="9" fill="var(--c-act)" font-weight="600">the shortest one</text>
  </g>

  <g transform="translate(384, 218)" font-size="9" fill="var(--dim)">
    <text x="0" y="0"><tspan font-family="var(--mono)" fill="var(--ink)">B&#8314;</tspan>
      takes the smallest input that does the job.</text>
    <text x="0" y="14">Every other point on the line spends
      <tspan fill="var(--c-act)">effort for nothing</tspan>.</text>
  </g>

  <defs>
    <marker id="pi-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--c-act)"/></marker>
  </defs>
</svg>
</template>
