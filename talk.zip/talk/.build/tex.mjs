// Render every KaTeX expression in the deck and report the ones that fail.
//
// Tex.vue runs with throwOnError:false, which is the right call for a live
// deck -- a bad expression shows up as red source on the slide instead of
// killing the build. The cost is that it only shows up if somebody looks at
// that slide. This checks all of them at once.
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
const require = createRequire(import.meta.url)
const katex = require(path.resolve('node_modules/katex/dist/katex.js'))

const MACROS = { '\\ub': '\\underbrace{#1}_{\\htmlClass{ub-note}{\\scriptsize\\textsf{#2}}}' }

const files = ['slides.md', ...fs.readdirSync('components').map(f => 'components/' + f)]
  .filter(f => /\.(md|vue)$/.test(f))

const found = []
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8')
  const line = i => src.slice(0, i).split('\n').length
  // <Tex e="..." /> and <Tex block e="..." />
  for (const m of src.matchAll(/<Tex\b[^>]*?\se="([^"]*)"/g)) found.push({ f, l: line(m.index), e: m[1] })
  // eq: '...' inside a component's data table
  for (const m of src.matchAll(/\beq:\s*'((?:[^'\\]|\\.)*)'/g))
    found.push({ f, l: line(m.index), e: m[1].replace(/\\\\/g, '\\') })
  // the first element of every [symbol, name] pair, which Vars and KalmanFlow render
  for (const m of src.matchAll(/\[\s*'((?:[^'\\]|\\.)*)'\s*,\s*'(?:[^'\\]|\\.)*'\s*\]/g))
    found.push({ f, l: line(m.index), e: m[1].replace(/\\\\/g, '\\') })
}

const bad = []
for (const t of found) {
  try {
    katex.renderToString(t.e, { displayMode: true, throwOnError: true, strict: false,
      trust: c => c.command === '\\htmlClass', macros: MACROS, output: 'html' })
  } catch (err) { bad.push({ ...t, why: err.message.replace(/\s+/g, ' ').slice(0, 120) }) }
}

console.log(`\nKaTeX expressions checked: ${found.length}`)
console.log(`FAILING: ${bad.length}\n`)
for (const b of bad) console.log(`  ${b.f}:${b.l}\n    ${b.e.slice(0, 90)}\n    ${b.why}\n`)
process.exit(bad.length ? 1 : 0)
