import { defineConfig } from 'unocss'

// UnoCSS runs in attributify mode, which means a plain SVG presentation
// attribute like font-size="12" is read as a utility class and rewritten to
// 3rem. That silently blew up every label in every diagram in this deck.
// Block the attribute names that SVG uses so the attributes mean what SVG
// says they mean.
//
// The list is deliberately wider than the attributes currently in use: a new
// diagram must not be able to reintroduce the bug by reaching for a presentation
// attribute nobody had needed yet. Blocking one is free -- SVG applies these
// natively, so there is never anything for UnoCSS to add.
const SVG_ATTRS = [
  'font-size', 'font-weight', 'font-family', 'font-style', 'font-variant',
  'text-anchor', 'dominant-baseline', 'alignment-baseline', 'letter-spacing',
  'word-spacing', 'baseline-shift', 'writing-mode', 'text-decoration',
  'stroke', 'stroke-width', 'stroke-opacity', 'stroke-dasharray',
  'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit',
  'fill', 'fill-opacity', 'fill-rule', 'opacity', 'color', 'visibility',
  'width', 'height', 'x', 'y', 'r', 'rx', 'ry', 'cx', 'cy',
  'x1', 'y1', 'x2', 'y2', 'dx', 'dy', 'd', 'points', 'transform',
  'offset', 'gradientUnits', 'gradientTransform', 'patternUnits',
  'marker-start', 'marker-mid', 'marker-end', 'clip-path', 'clip-rule', 'mask',
  'shape-rendering', 'paint-order', 'vector-effect', 'overflow', 'filter',
]

export default defineConfig({
  blocklist: [new RegExp(`^\\[(${SVG_ATTRS.join('|')})~=`)],
})
