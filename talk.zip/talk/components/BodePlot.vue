<script setup>
// The same system again, asked a different question: not "what does it do after
// a kick" but "what does it do to a steady wobble at each frequency".
//
// Two curves, because a linear system does exactly two things to a sine wave:
// it changes the SIZE and it shifts the TIMING. Everything in classical control
// is read off these two.
//
// The 90-degree crossing at resonance is not a detail. It is why feeding back
// velocity works: on resonance the response already lags the drive by a quarter
// cycle, so a push proportional to velocity arrives exactly out of phase with
// the motion, which is the definition of friction.
import { ref, computed } from 'vue'

const zeta = ref(0.12)

const X0 = 66, X1 = 704
const M0 = 22, M1 = 116          // magnitude panel, dB
const P0 = 148, P1 = 216         // phase panel, degrees
const DB_HI = 26, DB_LO = -34

const lx = w => X0 + ((Math.log10(w) + 1) / 2) * (X1 - X0)     // 0.1 .. 10
const my = db => M1 - ((Math.max(DB_LO, Math.min(DB_HI, db)) - DB_LO) / (DB_HI - DB_LO)) * (M1 - M0)
const py = ph => P0 + (-ph / 180) * (P1 - P0)

function G (w, z) {
  const re = 1 - w * w, im = 2 * z * w
  return [1 / Math.hypot(re, im), -Math.atan2(im, re)]
}

const mag = computed(() => {
  const p = []
  for (let i = 0; i <= 300; i++) {
    const w = Math.pow(10, -1 + (i / 300) * 2)
    p.push(lx(w).toFixed(1) + ',' + my(20 * Math.log10(G(w, zeta.value)[0])).toFixed(1))
  }
  return 'M' + p.join(' L')
})
const pha = computed(() => {
  const p = []
  for (let i = 0; i <= 300; i++) {
    const w = Math.pow(10, -1 + (i / 300) * 2)
    p.push(lx(w).toFixed(1) + ',' + py(G(w, zeta.value)[1] * 180 / Math.PI).toFixed(1))
  }
  return 'M' + p.join(' L')
})

const Q = computed(() => 1 / (2 * zeta.value))
const peakDb = computed(() => 20 * Math.log10(G(1, zeta.value)[0]))
const DEC = [0.1, 1, 10]
</script>

<template>
<div>
<svg viewBox="0 0 728 236" class="w-full" role="img"
     aria-label="Bode magnitude and phase of a lightly damped second-order system, with the resonance peak and the ninety degree phase crossing marked.">

  <!-- ============================= MAGNITUDE =========================== -->
  <text x="6" y="16" font-size="9" fill="var(--faint)" font-weight="600" letter-spacing=".06em">MAGNITUDE</text>
  <g stroke="var(--line)">
    <line :x1="X0" :y1="my(0)" :x2="X1" :y2="my(0)" stroke-dasharray="3 3"/>
    <line :x1="X0" :y1="M0" :x2="X0" :y2="M1"/>
    <line :x1="X0" :y1="M1" :x2="X1" :y2="M1"/>
  </g>
  <text :x="X0 - 5" :y="my(0) + 3" font-size="8" fill="var(--faint)" text-anchor="end">unity</text>
  <text :x="X0 - 5" :y="M0 + 8" font-size="8" fill="var(--faint)" text-anchor="end">gain</text>
  <text :x="X0 - 5" :y="M1" font-size="8" fill="var(--faint)" text-anchor="end">attenuation</text>

  <line :x1="lx(1)" :y1="M0" :x2="lx(1)" :y2="P1" stroke="var(--beat)" stroke-dasharray="2 3" opacity=".55"/>
  <path :d="mag" fill="none" stroke="var(--c-plant)" stroke-width="1.7"/>

  <circle :cx="lx(1)" :cy="my(peakDb)" r="3.5" fill="var(--beat)"/>
  <text :x="lx(1) + 8" :y="my(peakDb) + 3" font-size="8.5" fill="var(--beat)">
    resonance: gain equal to the quality factor</text>

  <!-- =============================== PHASE ============================= -->
  <text x="6" y="142" font-size="9" fill="var(--faint)" font-weight="600" letter-spacing=".06em">PHASE</text>
  <g stroke="var(--line)">
    <line :x1="X0" :y1="P0" :x2="X1" :y2="P0"/>
    <line :x1="X0" :y1="py(-90)" :x2="X1" :y2="py(-90)" stroke-dasharray="3 3"/>
    <line :x1="X0" :y1="P0" :x2="X0" :y2="P1"/>
  </g>
  <text :x="X0 - 5" :y="P0 + 4" font-size="8" fill="var(--faint)" text-anchor="end">0&#176;</text>
  <text :x="X0 - 5" :y="py(-90) + 3" font-size="8" fill="var(--faint)" text-anchor="end">-90&#176;</text>
  <text :x="X0 - 5" :y="P1" font-size="8" fill="var(--faint)" text-anchor="end">-180&#176;</text>

  <path :d="pha" fill="none" stroke="var(--c-plant)" stroke-width="1.7"/>
  <circle :cx="lx(1)" :cy="py(-90)" r="3.5" fill="var(--beat)"/>

  <!-- frequency axis -->
  <g font-size="8" fill="var(--faint)">
    <text :x="X0" :y="P1 + 14">0.1 &omega;<tspan dy="2" font-size="6">n</tspan></text>
    <text :x="lx(1)" :y="P1 + 14" text-anchor="middle">&omega;<tspan dy="2" font-size="6">n</tspan></text>
    <text :x="X1" :y="P1 + 14" text-anchor="end">10 &omega;<tspan dy="2" font-size="6">n</tspan></text>
  </g>
</svg>

<div class="ctlrow" style="grid-template-columns:1.1fr .9fr 1.6fr">
  <div>
    <div class="readout"><span class="rl">damping ratio</span>
      <span class="rv">{{ zeta.toFixed(2) }}</span></div>
    <input type="range" min="0.05" max="0.90" step="0.01" v-model.number="zeta"
           aria-label="damping ratio zeta" class="mt2"/>
  </div>
  <div class="stat"><span class="rl">peak gain</span>
    <span class="rv">{{ Q.toFixed(1) }}</span></div>
  <p class="cap">Phase is exactly -90&#176; at resonance for every damping ratio. An input
  proportional to velocity is therefore in antiphase with the motion there.</p>
</div>
</div>
</template>

