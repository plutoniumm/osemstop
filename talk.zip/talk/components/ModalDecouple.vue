<script setup>
// Why one scalar oscillator is enough for a body that has several degrees of
// freedom.
//
// Write the small-oscillation equations of the whole body and you get three
// matrices, and the coupling between coordinates is exactly their off-diagonal
// entries. Solve the generalised eigenproblem K phi = omega^2 M phi and change
// to those coordinates, and M and K come out diagonal -- so each row of the
// system is, on its own, the scalar equation of section 1.
//
// D is the honest one. It is diagonal in the same basis only if the damping is
// proportional; otherwise a small off-diagonal residue is left, which is drawn
// here rather than assumed away.
const N = 3
const CELL = 17, GAP = 2
const g = i => i * (CELL + GAP)
const SIZE = N * CELL + (N - 1) * GAP

// a full matrix, and the same matrix after the change of basis
const full = (r, c) => (r === c ? 0.72 : 0.30)
const diag = (r, c) => (r === c ? 0.72 : 0)
const damp = (r, c) => (r === c ? 0.72 : 0.08)

const LEFT = [
  { t: 'M', x: 40,  f: full }, { t: 'D', x: 132, f: full }, { t: 'K', x: 224, f: full },
]
const RIGHT = [
  { t: 'M', x: 430, f: diag }, { t: 'D', x: 522, f: damp }, { t: 'K', x: 614, f: diag },
]
</script>

<template>
<svg viewBox="0 0 728 172" class="w-full" role="img"
     aria-label="Three coupled matrices become diagonal in the modal basis, so each degree of freedom reduces to one scalar second-order equation.">

  <text x="40" y="18" font-size="9" fill="var(--c-plant)" font-weight="600" letter-spacing=".06em">IN THE MEASURED COORDINATES</text>
  <text x="430" y="18" font-size="9" fill="var(--c-model)" font-weight="600" letter-spacing=".06em">IN THE MODAL COORDINATES</text>

  <g v-for="m in LEFT" :key="'l' + m.t">
    <text :x="m.x + SIZE / 2" y="40" font-size="11" fill="var(--ink)" text-anchor="middle"
          font-family="var(--mono)">{{ m.t }}</text>
    <g v-for="r in N" :key="'r' + r">
      <rect v-for="c in N" :key="'c' + c"
            :x="m.x + g(c - 1)" :y="48 + g(r - 1)" :width="CELL" :height="CELL" rx="1"
            fill="var(--c-plant)" :fill-opacity="m.f(r - 1, c - 1)"
            stroke="var(--c-plant)" stroke-opacity=".35"/>
    </g>
  </g>
  <text x="40" y="128" font-size="8.5" fill="var(--c-plant)">every off-diagonal entry is one coordinate</text>
  <text x="40" y="140" font-size="8.5" fill="var(--c-plant)">pulling on another</text>

  <!-- the change of basis -->
  <g fill="none" marker-end="url(#md-a)">
    <path d="M330 66 H 412" stroke="var(--c-model)" stroke-width="1.4"/>
  </g>
  <text x="371" y="58" font-size="9" fill="var(--c-model)" text-anchor="middle" font-family="var(--mono)">&#934;</text>
  <text x="371" y="82" font-size="8" fill="var(--faint)" text-anchor="middle">from</text>
  <text x="371" y="94" font-size="8" fill="var(--faint)" text-anchor="middle">K&#966; = &#969;&#178;M&#966;</text>

  <g v-for="m in RIGHT" :key="'r' + m.t">
    <text :x="m.x + SIZE / 2" y="40" font-size="11" fill="var(--ink)" text-anchor="middle"
          font-family="var(--mono)">{{ m.t }}</text>
    <g v-for="r in N" :key="'rr' + r">
      <rect v-for="c in N" :key="'rc' + c"
            :x="m.x + g(c - 1)" :y="48 + g(r - 1)" :width="CELL" :height="CELL" rx="1"
            fill="var(--c-model)" :fill-opacity="m.f(r - 1, c - 1)"
            stroke="var(--c-model)" stroke-opacity=".35"/>
    </g>
  </g>
  <text x="430" y="128" font-size="8.5" fill="var(--c-model)">M and K are exactly diagonal. Each row is now</text>
  <text x="430" y="140" font-size="8.5" fill="var(--c-model)">an independent scalar oscillator.</text>
  <text x="430" y="158" font-size="8.5" fill="var(--bad)">D is diagonal only if the damping is proportional.</text>

  <defs>
    <marker id="md-a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-model)" stroke="none"/></marker>
  </defs>
</svg>
</template>
