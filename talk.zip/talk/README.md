# Control Theory -- the talk

A Slidev deck. `slides.md` is the only source; there is no `.build/*.md` fragment
set and there must not be one again. An earlier version generated `slides.md` by
concatenating fragments, and every direct edit to `slides.md` was silently
overwritten the next time that ran.

    npm run dev      # localhost:3000
    npm run build    # -> dist/
    npm run audit    # build, then measure every slide for overflow

## What this deck is

Control theory, in five sections: classical, modern, stochastic, optimal,
learning-based. Each section runs three beats, and the rail on every slide says
which one you are on:

| beat | what is on the slide |
|---|---|
| **1 math** | the general result, for any plant |
| **2 theory** | what it implies, and what it costs |
| **3 applied** | how it appears on the instrument this work is about |

The applied beat is where the project's own controllers live -- the per-channel
velocity loop, four of them at once, the modal law, the estimator, the actuator
budget and the staged learning plan. **It carries structure, not session data.**
Matrix shapes, sign conditions and what a term means here are on a slide;
measured runs, per-channel numbers and the history of which configuration was in
place when are not. They belong in the report.

The unused rig components are still in `components/` -- `RigMap`,
`ShadowSensor`, `LoopMap`, `SignFlip`, `ModeShapes`, `RefusalLadder`,
`AllocBox`, `BreakerBeat`, `PowerPhase`, `PoleMap` -- kept for when more of that
material is added.

## Rules the deck is written to

**Register is reportive.** Statements of fact, plain noun-phrase titles, no
rhetorical build-up and no second person in a rendered label. "The second-order
system", not "nearly everything is a mass on a spring".

**Prose is the last resort.** A diagram, a table or an equation carries the point
where one can. Running prose exists only where none of the three can. `npm run
audit` counts it: at the time of writing, 1606 words over 37 slides, median 36 a
slide.

**Colour is an index, not decoration.** Five roles, defined once in `style.css`
and used on every diagram, panel edge and chip in the deck:

| token | role |
|---|---|
| `--c-plant` | the system itself |
| `--c-meas` | anything measured: sensors, readings, outputs |
| `--c-act` | anything commanded: inputs, actuators, gains |
| `--c-dist` | disturbance, noise, everything unmodelled |
| `--c-model` | the model or the estimate |

Slide 2 shows the key. Utility classes `.t-plant` / `.p-plant` / `.key .kx.plant`
and their four siblings apply it outside SVG.

The applied beat is deliberately a **pale neutral**, not a sixth hue: an applied
slide is full of role-coloured diagram elements, and a coloured beat on top of
them would read as another role.

`--good` and `--bad` are a **separate** axis (stable / unstable, suppressed /
amplified) and are close enough in hue to `--c-act` and `--c-meas` to be confused
with them. Do not use both systems in one figure. Where a figure needs the
semantic five, express any verdict through the number and the label instead.

**Name a symbol before using it.** Every slide that introduces new symbols
carries a `<Vars>` legend bottom right: symbol and name, nothing else. List only
what is new on that slide -- except when a symbol is reused for a *different*
quantity, which is exactly when it must be relisted. `K` is a feedback gain, a
stiffness matrix, and the Kalman gain in three different sections, and the
legend is what keeps that survivable.

The legend **flows in the layout**; it is not absolutely positioned. Absolute
would cost no height, which is tempting on a 552px canvas, but it also lets a
full slide paint the legend over its own content invisibly. Flowing turns a
clash into overflow, which `npm run audit` measures on every build.

Two symbol collisions were resolved rather than legended around: the damping
matrix is `D` (M, D, K), not `C`, which is the controller and the output matrix;
and the modal input matrix is `B`, not `A`, which is the state matrix three
slides earlier.

**No pole plane, anywhere.** The root-locus and s-plane machinery was cut on
purpose: none of the controllers this work is about are designed that way, and
the same facts read better in the units the audience already has. Feedback is
explained by *which coefficient a term lands in* (`DecayCompare`), stability by
*whether the response decays*, and `K` by what it does to the closed-loop
dynamics rather than to a diagram. `RootLocus.vue` and `PoleMap.vue` are still on
disk and unused.

**Derive, do not assert.** Where a result has terms a reader will wonder about,
show where they come from: the LQR gain is three steps -- guess a quadratic
cost-to-go, minimise spend-now-plus-change-in-what-is-left over `u`, require the
result for every `x` -- laid out as rows via `.steps`, not columns. Columns read
as alternatives; a derivation is a sequence.

**Say what a plot is a plot of.** Every figure in the classical section is a
curve computed from a specific transfer function. `.src` under the figure states
that function and the axes, in the mono voice, so the reader can check the curve
rather than take it. A plot with no stated source is a decoration.

**No em dashes**; use ` -- `.

## Overflow is a correctness bug

Slidev renders each slide into a fixed **980x552** canvas and clips anything
taller. It does not scroll, and it is not visible at 60 % zoom in the browser.

- `node .build/audit.mjs` drives headless Chromium at exactly that size and
  reports per-slide overflow, text clipped by its own SVG `viewBox`, running word
  count and the visual-to-prose area ratio. It must report **0 overflowing**.
- `node .build/fill.mjs` reports the opposite failure: how much of the canvas each
  slide actually uses. The type scale in `style.css` is set from this, not from
  the most crowded slide.
- `node .build/shot.mjs 6,9,11 [outdir]` screenshots slides at canvas size. Label
  collisions inside an SVG are invisible to the auditor and only show up here.
- `node .build/tex.mjs` renders **every** KaTeX expression in the deck and lists
  the ones that fail. `Tex.vue` runs with `throwOnError: false`, which is right
  for a live deck -- a bad formula shows as red source on the slide instead of
  killing the build -- but that only helps if somebody looks at that slide. Two
  traps it catches: the `\ub` label is **text mode**, so `\ub{...}{\dot V}` is a
  parse error; and in a `.md` file a macro needs a **double** backslash, because
  the attribute is a JS string literal and `'\hat x'` silently becomes `hat x`.

All three drive headless Chromium and derive their ports from the process id, so
a subagent and the main session can run them at the same time.

## Components

New in the applied and learning material: `FourLoops`, `ModalChain`,
`ModalDecouple` (why one scalar oscillator covers a body with several degrees of
freedom), `EstimatorState`, `BudgetBar`, `Separation`, and `EnsembleGate` (where
the confidence number comes from and what it is permitted to do).

`Tex.vue` renders KaTeX anywhere, including inside raw `<div>` blocks where
markdown never looks at `$...$`. It defines one macro:

    \ub{maths}{label}

which puts `label` in grey under a brace. Where a symbol stands in for something
derived earlier, show the final equation once with the substitution braced under
it, not the chain of equations that produced it.

Interactive figures share one control strip, `.ctlrow` in `style.css`. `.readout`
puts a label and value on one line for a full-width slider; `.stat` stacks them,
which is what a bare statistic needs.
