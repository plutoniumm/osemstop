<script setup>
// The modal law, as the three changes of variable it actually is.
//
//   readings  ->  modal rates  ->  modal forces  ->  actuator commands
//
// Only the middle step is a control law, and it is section 1's law applied
// once per mode. The two outer steps are coordinate changes, and both are
// pseudo-inverses of non-square matrices -- which is where the check on the
// left and the choice on the right come from.
import Tex from './Tex.vue'
</script>

<template>
<div>
<svg viewBox="0 0 728 176" class="w-full" role="img"
     aria-label="Readings are projected onto modal rates, damped per mode, and allocated back onto actuator commands, with the unexplained residual branching off as a consistency check.">

  <!-- signals -->
  <g font-family="var(--mono)" font-size="12" text-anchor="middle">
    <text x="36"  y="60" fill="var(--c-meas)">y&#775;</text>
    <text x="290" y="60" fill="var(--c-plant)">q&#775;</text>
    <text x="470" y="60" fill="var(--c-plant)">f</text>
    <text x="700" y="60" fill="var(--c-act)">u</text>
  </g>
  <g font-size="8" text-anchor="middle" fill="var(--faint)">
    <text x="36"  y="74">4 readings</text>
    <text x="290" y="74">3 modal rates</text>
    <text x="470" y="74">3 modal forces</text>
    <text x="700" y="74">4 commands</text>
  </g>

  <!-- the three operations -->
  <g fill="var(--panel)">
    <rect x="106" y="34" width="126" height="34" rx="3" stroke="var(--c-model)"/>
    <rect x="348" y="34" width="76"  height="34" rx="3" stroke="var(--c-act)"/>
    <rect x="530" y="34" width="126" height="34" rx="3" stroke="var(--c-model)"/>
  </g>
  <g font-size="11" fill="var(--ink)" text-anchor="middle" font-family="var(--mono)">
    <text x="169" y="55">&#934;&#8314;</text>
    <text x="386" y="55">&#8722;K</text>
    <text x="593" y="55">B&#8314;</text>
  </g>
  <g font-size="8" fill="var(--faint)" text-anchor="middle">
    <text x="150" y="80">into modal coordinates</text>
    <text x="386" y="80">section 1, per mode</text>
    <text x="593" y="80">back onto actuators</text>
  </g>

  <g fill="none">
    <path d="M52 51 H 102"  stroke="var(--c-meas)"  marker-end="url(#mc-m)"/>
    <path d="M232 51 H 274" stroke="var(--c-plant)" marker-end="url(#mc-p)"/>
    <path d="M306 51 H 344" stroke="var(--c-plant)" marker-end="url(#mc-p)"/>
    <path d="M424 51 H 456" stroke="var(--c-plant)" marker-end="url(#mc-p)"/>
    <path d="M486 51 H 526" stroke="var(--c-plant)" marker-end="url(#mc-p)"/>
    <path d="M656 51 H 684" stroke="var(--c-act)"   marker-end="url(#mc-c)"/>
  </g>

  <!-- the part of the reading no rigid motion can explain -->
  <path d="M226 68 V 108" stroke="var(--c-meas)" stroke-dasharray="3 2" fill="none"
        marker-end="url(#mc-m)"/>
  <rect x="163" y="114" width="126" height="30" rx="3" stroke="var(--c-meas)" fill="var(--panel)"/>
  <text x="226" y="133" font-size="9.5" fill="var(--ink)" text-anchor="middle">the residual</text>
  <text x="302" y="126" font-size="8.5" fill="var(--c-meas)">4 readings, 3 modes: one combination left over,</text>
  <text x="302" y="138" font-size="8.5" fill="var(--c-meas)">which no rigid motion can produce. A free check.</text>

  <defs>
    <marker id="mc-p" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-plant)" stroke="none"/></marker>
    <marker id="mc-c" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-act)" stroke="none"/></marker>
    <marker id="mc-m" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-meas)" stroke="none"/></marker>
  </defs>

  <text x="12" y="166" font-size="8.5" fill="var(--faint)">
    Both outer boxes are pseudo-inverses of non-square matrices: the left one leaves a
    residual, the right one leaves a choice.</text>
</svg>

<div class="cols-w mt3" style="grid-template-columns:1.25fr 1fr">
<div class="panel p-model">
<span class="k">the three steps are one matrix</span>
<Tex block e="u = -\,B^{+}\,K\,\Phi^{+}\;\dot y" />
</div>
<div class="def">
<span class="term">what it costs</span> <Tex e="\Phi" /> and <Tex e="B" /> must both be known.
The law of section 1 needed neither.
</div>
</div>
</div>
</template>
