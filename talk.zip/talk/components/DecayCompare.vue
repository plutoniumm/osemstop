<script setup>
// What feeding a signal back actually changes, without drawing a single pole.
//
// Both laws add one term to the same equation. Velocity feedback lands in the
// FIRST-ORDER coefficient, which is the one that sets how fast the motion
// dies. Position feedback lands in the LAST coefficient, which sets how fast it
// oscillates -- and leaves the decay exactly as it was.
//
//   free       x.. + 2 zeta w x.  +      w^2  x = 0
//   velocity   x.. + (2 zeta w + K) x.  + w^2 x = 0     decay rises
//   position   x.. + 2 zeta w x.  + (w^2 + K) x = 0     decay unchanged
import { ref, computed } from 'vue'

const K = ref(0.45)
const Z0 = 0.05, W0 = 1
const TMAX = 40

const gFree = Z0 * W0
const gVel = computed(() => gFree + K.value / 2)
const wPos = computed(() => Math.sqrt(W0 * W0 + K.value))

const X0 = 58, X1 = 700, Y0 = 20, Y1 = 168
const tx = t => X0 + (t / TMAX) * (X1 - X0)
const ty = v => (Y0 + Y1) / 2 - v * ((Y1 - Y0) / 2) * 0.94

function trace (g, w) {
  const wd = Math.sqrt(Math.max(1e-9, w * w - g * g))
  const p = []
  for (let i = 0; i <= 700; i++) {
    const t = (i / 700) * TMAX
    p.push(tx(t).toFixed(1) + ',' + ty(Math.exp(-g * t) * Math.cos(wd * t)).toFixed(1))
  }
  return 'M' + p.join(' L')
}
function envelope (g) {
  const up = [], dn = []
  for (let i = 0; i <= 140; i++) {
    const t = (i / 140) * TMAX, e = Math.exp(-g * t)
    up.push(tx(t).toFixed(1) + ',' + ty(e).toFixed(1))
    dn.push(tx(t).toFixed(1) + ',' + ty(-e).toFixed(1))
  }
  return 'M' + up.join(' L') + ' M' + dn.join(' L')
}

const free = trace(gFree, W0)
const vel = computed(() => trace(gVel.value, W0))
const pos = computed(() => trace(gFree, wPos.value))
const envFree = envelope(gFree)
const envVel = computed(() => envelope(gVel.value))

// how long to fall to a tenth: the number the two laws disagree about
const tenth = g => Math.log(10) / g
</script>

<template>
<div>
<svg viewBox="0 0 728 200" class="w-full" role="img"
     aria-label="Three free responses: no feedback, velocity feedback which decays faster, and position feedback which oscillates faster but decays at the same rate.">

  <g stroke="var(--line)">
    <line :x1="X0" :y1="ty(0)" :x2="X1" :y2="ty(0)"/>
    <line :x1="X0" :y1="Y0" :x2="X0" :y2="Y1"/>
  </g>

  <path :d="envFree" fill="none" stroke="var(--faint)" stroke-width="1" stroke-dasharray="2 3" opacity=".55"/>
  <path :d="envVel" fill="none" stroke="var(--c-act)" stroke-width="1" stroke-dasharray="2 3" opacity=".65"/>

  <path :d="free" fill="none" stroke="var(--faint)" stroke-width="1.3" opacity=".75"/>
  <path :d="pos" fill="none" stroke="var(--c-meas)" stroke-width="1.5"/>
  <path :d="vel" fill="none" stroke="var(--c-act)" stroke-width="1.8"/>

  <text :x="X1" :y="Y1 + 14" font-size="8" fill="var(--faint)" text-anchor="end">time</text>
</svg>

<div class="dc-row">
  <div>
    <div class="readout"><span class="rl">feedback gain</span>
      <span class="rv">{{ K.toFixed(2) }}</span></div>
    <input type="range" min="0" max="0.8" step="0.01" v-model.number="K" class="mt2"
           aria-label="feedback gain"/>
  </div>
  <div class="dc-key">
    <span class="dk free">no feedback</span>
    <span class="dk act">velocity fed back</span>
    <span class="dk meas">position fed back</span>
  </div>
  <div class="stat"><span class="rl">time to a tenth, velocity</span>
    <span class="rv act">{{ tenth(gVel).toFixed(0) }}</span></div>
  <div class="stat"><span class="rl">time to a tenth, position</span>
    <span class="rv meas">{{ tenth(gFree).toFixed(0) }}</span></div>
</div>
</div>
</template>

<style scoped>
.dc-row{ display:grid; grid-template-columns:1.2fr 1fr .8fr .8fr; gap:var(--s5);
  align-items:end; margin-top:var(--s3); }
.dc-key{ display:flex; flex-direction:column; gap:.15rem; }
.dk{ font-family:var(--mono); font-size:var(--fs-micro); color:var(--faint);
  display:flex; align-items:center; gap:.4rem; }
.dk::before{ content:''; width:12px; height:2px; background:currentColor; }
.dk.free{ color:var(--faint); } .dk.act{ color:var(--c-act); } .dk.meas{ color:var(--c-meas); }
.stat{ display:flex; flex-direction:column; gap:.15rem; }
.stat .rl{ font-family:var(--mono); font-size:var(--fs-micro); letter-spacing:.08em;
  text-transform:uppercase; color:var(--faint); }
.stat .rv{ font-family:var(--mono); font-size:var(--fs-num); font-weight:600;
  font-variant-numeric:tabular-nums; }
.stat .rv.act{ color:var(--c-act); } .stat .rv.meas{ color:var(--c-meas); }
</style>
