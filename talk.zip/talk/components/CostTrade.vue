<script setup>
// What changes when you stop choosing gains.
//
// Every stabilising controller sits somewhere on a trade-off between how much
// motion is left and how much effort you spend. You cannot get to the bottom left
// corner. R slides you along the curve, and that is a thing you have an opinion
// about; a gain is not.
//
// The curve is illustrative. What is not illustrative is the shape: it is a
// hyperbola, so the bottom-left corner does not exist at any price.

const X0 = 92, X1 = 400, Y0 = 30, Y1 = 148
const N = 60
// a plain hyperbola: effort x motion = const, the shape of every such trade
const pts = Array.from({ length: N + 1 }, (_, i) => {
  const f = 0.09 + (i / N) * 0.86
  return { x: X0 + f * (X1 - X0), y: Y1 - (0.075 / f) * (Y1 - Y0) * 1.02 }
})
const path = pts.map((p, i) => `${i ? 'L' : 'M'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')
const KNOBS = [
  { f: 0.16, t: 'R large', at: 'start' },
  { f: 0.44, t: 'R balanced', at: 'start' },
  { f: 0.86, t: 'R small', at: 'end' },
]
const px = (f) => X0 + f * (X1 - X0)
const py = (f) => Y1 - (0.075 / f) * (Y1 - Y0) * 1.02
</script>

<template>
<svg viewBox="0 0 728 186" class="w-full" role="img"
     aria-label="Trade-off curve between residual motion and control effort. R slides the design along the curve; nothing reaches the bottom-left corner.">

  <!-- axes -->
  <line :x1="X0" :y1="Y1" :x2="X1 + 24" :y2="Y1" stroke="var(--line-2)" marker-end="url(#ct)"/>
  <line :x1="X0" :y1="Y1" :x2="X0" :y2="Y0 - 14" stroke="var(--line-2)" marker-end="url(#ct)"/>
  <text :x="(X0 + X1) / 2" :y="Y1 + 22" font-size="9" fill="var(--c-plant)" text-anchor="middle">
    RESIDUAL DEVIATION</text>
  <text x="0" y="0" font-size="9" fill="var(--c-act)" text-anchor="middle"
        :transform="`translate(${X0 - 20}, ${(Y0 + Y1) / 2}) rotate(-90)`">ACTUATOR EFFORT</text>

  <!-- unreachable corner: the thing the curve exists to say -->
  <text :x="X0 + 10" :y="Y1 - 8" font-size="8.5" fill="var(--faint)">no design reaches this corner</text>

  <path :d="path" fill="none" stroke="var(--c-model)" stroke-width="2"/>

  <g v-for="k in KNOBS" :key="k.t">
    <circle :cx="px(k.f)" :cy="py(k.f)" r="4.5" fill="var(--c-model)" stroke="var(--bg)" stroke-width="1.5"/>
    <text :x="k.at === 'end' ? px(k.f) - 9 : px(k.f) + 9" :y="py(k.f) - 3" font-size="9"
          font-family="var(--mono)" fill="var(--ink)" :text-anchor="k.at">{{ k.t }}</text>
  </g>

  <line x1="452" y1="16" x2="452" y2="170" stroke="var(--line)"/>

  <g transform="translate(474, 28)">
    <text x="0" y="0" font-size="9.5" fill="var(--faint)" font-weight="600">WHAT IS SPECIFIED</text>
    <text x="0" y="22" font-size="10.5" fill="var(--c-act)">state feedback: a gain</text>
    <text x="0" y="46" font-size="10.5" fill="var(--c-model)">LQR: a cost, Q against R</text>
    
    <text x="0" y="84" font-size="9" fill="var(--faint)" font-weight="600">WHY THAT IS PREFERABLE</text>
    <text x="0" y="102" font-size="8.5" fill="var(--faint)">A gain is an answer; a cost is a</text>
    <text x="0" y="114" font-size="8.5" fill="var(--faint)">specification, and the specification</text>
    <text x="0" y="126" font-size="8.5" fill="var(--faint)">is what is actually known.</text>
  </g>

  <defs>
    <marker id="ct" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--line-2)"/></marker>
  </defs>
</svg>
</template>
