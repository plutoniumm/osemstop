<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'

// A runaway detector, and the ripple that stops it firing.
//
// The motion is a sum of resonances, so its envelope BEATS: two tones a beat
// apart make the sum dip once per beat period even while the whole thing is
// growing. Here the beat is |0.98 - 0.70| = 0.28 Hz, a 3.6 s cycle -- longer
// than the 2.0 s window the detector averages over -- so every ripple trough
// looks like the motion receding. That is the defect the machine below fixes.
//
// The frequencies, amplitudes and growth rates are illustrative.
const F = [0.70, 0.98, 1.65]
const AMP = [1.0, 0.62, 0.38]
const DT = 0.02, SPAN = 60, WIN = 2.0, SUSTAIN = 5.0, DECAY_FRAC = 0.98, HIGH = 1.8

const g = ref(0.08)       // growth rate, 1/s
const cv = ref(null)

const PRESETS = [
  { g:0.05, name:'a slow runaway',   note:'the loop misbehaving gently' },
  { g:0.08, name:'a clear runaway',  note:'what the breaker exists to catch' },
  { g:0.35, name:'somebody shoves the table', note:'growth far faster than the ripple' },
]

const sim = computed(() => {
  const n = Math.round(SPAN/DT)
  const raw = new Float64Array(n), env = new Float64Array(n)
  for (let i=0;i<n;i++){
    const t = i*DT
    let s = 0
    for (let k=0;k<3;k++) s += AMP[k]*Math.sin(2*Math.PI*F[k]*t + k*1.7)
    raw[i] = s * Math.exp(g.value*t)
  }
  // 2 s sliding RMS: this is what the breaker actually sees
  const w = Math.round(WIN/DT)
  let acc = 0
  for (let i=0;i<n;i++){
    acc += raw[i]*raw[i]
    if (i>=w) acc -= raw[i-w]*raw[i-w]
    env[i] = Math.sqrt(acc/Math.min(i+1,w))
  }
  const base = env[Math.round(6/DT)]
  const peak = new Float64Array(n), ratio = new Float64Array(n)
  const rec = new Uint8Array(n), hi = new Uint8Array(n), grow = new Uint8Array(n)
  let pk = 0
  for (let i=0;i<n;i++){
    pk = Math.max(pk, env[i]); peak[i] = pk
    ratio[i] = env[i]/pk
    rec[i]  = env[i] < pk*DECAY_FRAC ? 1 : 0
    hi[i]   = env[i] > HIGH*base ? 1 : 0
    grow[i] = i > w ? (env[i] > env[i-w] ? 1 : 0) : 0
  }
  // OLD rule: a recession RESETS the sustain clock
  // NEW rule: the latch ignores recession; recession only VETOES at the trip
  const oldL = new Float64Array(n), newL = new Float64Array(n)
  let a=0,b=0, oldTrip=-1, newTrip=-1
  for (let i=0;i<n;i++){
    a = (hi[i] && grow[i] && !rec[i]) ? a+DT : 0
    b = (hi[i] && grow[i])            ? b+DT : 0
    oldL[i]=a; newL[i]=b
    if (oldTrip<0 && a>=SUSTAIN) oldTrip = i*DT
    if (newTrip<0 && b>=SUSTAIN && !rec[i]) newTrip = i*DT
  }
  const recFrac = rec.reduce((s,v,i)=> s + (hi[i]&&grow[i] ? v : 0), 0) /
                  Math.max(1, hi.reduce((s,v,i)=> s + (v&&grow[i] ? 1:0), 0))
  return { n, env, peak, ratio, rec, oldL, newL, oldTrip, newTrip, recFrac }
})

function draw(){
  const c = cv.value; if(!c) return
  const dpr = window.devicePixelRatio||1
  const w=c.clientWidth, h=c.clientHeight
  if(c.width!==w*dpr||c.height!==h*dpr){c.width=w*dpr;c.height=h*dpr}
  const x=c.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); x.clearRect(0,0,w,h)
  const S = sim.value
  const PL=40,PR=10,PT=10,PB=22
  const gw=w-PL-PR, gh=h-PT-PB
  const topH = gh*0.56, botY = PT+topH+14, botH = gh-topH-14
  const X = t => PL + t/SPAN*gw

  // --- top panel: env/peak against the 0.98 line ---
  const Y1 = v => PT + topH - (v-0.6)/(1.05-0.6)*topH
  x.strokeStyle='#22303e'; x.lineWidth=1
  x.font='10px "IBM Plex Mono", ui-monospace, monospace'; x.fillStyle='#66747f'
  for(const v of [0.6,0.7,0.8,0.9,1.0]){
    const yy=Math.round(Y1(v))+0.5
    x.beginPath();x.moveTo(PL,yy);x.lineTo(w-PR,yy);x.stroke()
    x.textAlign='right';x.textBaseline='middle';x.fillText(v.toFixed(2),PL-5,yy)
  }
  // the threshold
  x.strokeStyle='#e8756a'; x.lineWidth=1.4; x.setLineDash([5,3])
  x.beginPath(); x.moveTo(PL,Y1(DECAY_FRAC)); x.lineTo(w-PR,Y1(DECAY_FRAC)); x.stroke()
  x.setLineDash([])
  x.fillStyle='#e8756a'; x.textAlign='left'; x.textBaseline='bottom'
  x.fillText('below this line counts as a dip', PL+5, Y1(DECAY_FRAC)-3)
  // ratio trace, red where receded fires
  for(let i=1;i<S.n;i++){
    x.strokeStyle = S.rec[i] ? '#e8756a' : '#5fbf8c'
    x.lineWidth = S.rec[i] ? 2 : 1.4
    x.beginPath(); x.moveTo(X((i-1)*DT), Y1(S.ratio[i-1])); x.lineTo(X(i*DT), Y1(S.ratio[i])); x.stroke()
  }
  x.fillStyle='#66747f'; x.textAlign='right'; x.textBaseline='bottom'
  x.fillText('size now, over the biggest size so far', w-PR-4, PT+topH-3)

  // --- bottom panel: the two latch clocks ---
  const Y2 = v => botY + botH - v/8*botH
  x.strokeStyle='#22303e'
  for(const v of [0,2,4,6,8]){
    const yy=Math.round(Y2(v))+0.5
    x.beginPath();x.moveTo(PL,yy);x.lineTo(w-PR,yy);x.stroke()
    x.fillStyle='#66747f';x.textAlign='right';x.textBaseline='middle';x.fillText(v+'s',PL-5,yy)
  }
  x.strokeStyle='#e0a63a'; x.setLineDash([4,3]); x.lineWidth=1
  x.beginPath();x.moveTo(PL,Y2(SUSTAIN));x.lineTo(w-PR,Y2(SUSTAIN));x.stroke(); x.setLineDash([])
  x.fillStyle='#e0a63a';x.textAlign='left';x.textBaseline='bottom'
  x.fillText('trip once it has grown for 5 s straight', PL+5, Y2(SUSTAIN)-3)

  const trace = (arr,col,wd)=>{ x.strokeStyle=col;x.lineWidth=wd;x.beginPath()
    for(let i=0;i<S.n;i++){ const xx=X(i*DT), yy=Y2(Math.min(8,arr[i])); i?x.lineTo(xx,yy):x.moveTo(xx,yy) } x.stroke() }
  trace(S.oldL,'#e8756a',1.6)
  trace(S.newL,'#57a9d6',2)

  for (const [tt,col] of [[S.oldTrip,'#e8756a'],[S.newTrip,'#57a9d6']]){
    if (tt>=0){ x.strokeStyle=col;x.lineWidth=1.5
      x.beginPath();x.moveTo(X(tt),botY);x.lineTo(X(tt),botY+botH);x.stroke()
      x.fillStyle=col;x.beginPath();x.arc(X(tt),Y2(SUSTAIN),4,0,7);x.fill() }
  }
  x.fillStyle='#66747f';x.textAlign='center';x.textBaseline='top'
  for(let t=0;t<=SPAN;t+=10) x.fillText(t+'s', X(t), h-PB+4)
}
onMounted(()=>{ draw(); window.addEventListener('resize',draw) })
onUnmounted(()=> window.removeEventListener('resize',draw))
watch(g, draw)
</script>

<template>
<div>
  <canvas ref="cv" class="w-full" style="height:162px"></canvas>

  <div style="display:flex; align-items:center; gap:.5rem; padding-top:.5rem">
    <button v-for="p in PRESETS" :key="p.g" class="btn" style="flex:1"
            :class="{ on: Math.abs(g-p.g) < 1e-9 }" @click="g = p.g">
      <span class="btn-t">{{ p.g.toFixed(2) }} /s</span>
      <span class="btn-s">{{ p.name }}</span>
    </button>
    <input type="range" min="0.01" max="0.35" step="0.005" v-model.number="g"
           style="flex:1.1; margin-left:.4rem">
  </div>

  <div class="cols-3 mt3">
    <div class="panel">
      <span class="k">how often it momentarily dips while genuinely growing</span>
      <div class="stat bad">{{ (sim.recFrac*100).toFixed(0) }} %</div>
      <div class="cap">three ringing frequencies beating against each other</div>
    </div>
    <div class="panel bad">
      <span class="k">old rule: every dip resets the clock</span>
      <div class="stat" :class="sim.oldTrip>=0 ? 'good':'bad'" style="font-size:1.05rem">
        {{ sim.oldTrip>=0 ? 'fires after ' + sim.oldTrip.toFixed(1) + ' s' : 'does not fire' }}</div>
    </div>
    <div class="panel good">
      <span class="k">new rule: a dip only blocks the trip while it lasts</span>
      <div class="stat" :class="sim.newTrip>=0 ? 'good':'bad'" style="font-size:1.05rem">
        {{ sim.newTrip>=0 ? 'fires after ' + sim.newTrip.toFixed(1) + ' s' : 'does not fire' }}</div>
    </div>
  </div>
</div>
</template>
