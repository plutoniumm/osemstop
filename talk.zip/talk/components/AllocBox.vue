<script setup>
import { ref, computed } from 'vue'

// The controller asks for a push. Four coils, each with a voltage limit, can
// only produce pushes inside a certain shape. The shape is drawn here in two
// dimensions so you can see it; on the rig it is three.
// The one property that matters: the shape contains the "no push at all" point.
const VERT = [[-1.0, -0.55], [0.35, -1.0], [1.0, 0.5], [0.15, 1.0], [-0.75, 0.62]]
const CX = 208, CY = 128, S = 88
const px = p => [CX + p[0] * S, CY - p[1] * S]

const fx = ref(1.62), fy = ref(1.38)
const dragging = ref(false)

function inside(p) {
  for (let i = 0; i < VERT.length; i++) {
    const a = VERT[i], b = VERT[(i + 1) % VERT.length]
    if ((b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) < 0) return false
  }
  return true
}
function projectSeg(p, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1]
  let t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy)
  t = Math.max(0, Math.min(1, t))
  return [a[0] + t * dx, a[1] + t * dy]
}
const f = computed(() => [fx.value, fy.value])

// the nearest push the coils can actually produce
const near = computed(() => {
  const p = f.value
  if (inside(p)) return p
  let best = null, bd = Infinity
  for (let i = 0; i < VERT.length; i++) {
    const q = projectSeg(p, VERT[i], VERT[(i + 1) % VERT.length])
    const d = (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2
    if (d < bd) { bd = d; best = q }
  }
  return best
})
// the old approach: shrink the whole request until it fits
const shrunk = computed(() => {
  const p = f.value
  if (inside(p)) return p
  let lo = 0, hi = 1
  for (let k = 0; k < 40; k++) { const m = (lo + hi) / 2; inside([p[0] * m, p[1] * m]) ? lo = m : hi = m }
  return [p[0] * lo, p[1] * lo]
})
const mag = p => Math.hypot(p[0], p[1])
const gain = computed(() => mag(near.value) / Math.max(1e-9, mag(shrunk.value)))
const dotN = computed(() => f.value[0] * near.value[0] + f.value[1] * near.value[1])
const dotS = computed(() => f.value[0] * shrunk.value[0] + f.value[1] * shrunk.value[1])
const outside = computed(() => !inside(f.value))

function move(e) {
  if (!dragging.value) return
  const r = e.currentTarget.getBoundingClientRect()
  const sx = 420 / r.width
  fx.value = Math.max(-2.2, Math.min(2.2, ((e.clientX - r.left) * sx - CX) / S))
  fy.value = Math.max(-2.2, Math.min(2.2, (CY - (e.clientY - r.top) * sx) / S))
}
</script>

<template>
<div class="cols-w">
  <svg viewBox="0 0 420 252" class="w-full select-none" style="cursor:crosshair"
       @pointerdown="dragging = true; move($event)" @pointermove="move"
       @pointerup="dragging = false" @pointerleave="dragging = false">
    <line :x1="CX-190" :y1="CY" :x2="CX+190" :y2="CY" stroke="var(--line)"/>
    <line :x1="CX" :y1="CY-116" :x2="CX" :y2="CY+116" stroke="var(--line)"/>

    <polygon :points="VERT.map(v => px(v).join(',')).join(' ')"
             fill="var(--cA)" fill-opacity=".10" stroke="var(--cA)" stroke-width="1.6"/>
    <circle :cx="CX" :cy="CY" r="4" fill="var(--brass)"/>
    <text :x="CX-8" :y="CY+16" text-anchor="end" font-size="9.5" fill="var(--brass)">no push at all</text>

    <line :x1="CX" :y1="CY" :x2="px(f)[0]" :y2="px(f)[1]" stroke="var(--dim)" stroke-width="1.3" stroke-dasharray="4 3"/>
    <line :x1="px(f)[0]" :y1="px(f)[1]" :x2="px(near)[0]" :y2="px(near)[1]"
          stroke="var(--cC)" stroke-width="1.3" stroke-dasharray="3 3"/>

    <circle :cx="px(shrunk)[0]" :cy="px(shrunk)[1]" r="6" fill="var(--cB)"/>
    <text :x="px(shrunk)[0]-10" :y="px(shrunk)[1]+16" font-size="9.5" text-anchor="end"
          fill="var(--cB)">shrunk</text>

    <circle :cx="px(near)[0]" :cy="px(near)[1]" r="6" fill="var(--cC)"/>
    <text :x="px(near)[0]+4" :y="px(near)[1]+20" font-size="9.5" fill="var(--cC)">nearest</text>

    <circle :cx="px(f)[0]" :cy="px(f)[1]" r="6" fill="none" stroke="var(--ink)" stroke-width="1.6"/>
    <text :x="px(f)[0]-10" :y="px(f)[1]+4" text-anchor="end" font-size="10" fill="var(--ink)">asked for</text>

    <text x="8" y="247" font-size="9" fill="var(--faint)">
      Drag the open circle.</text>
  </svg>

  <div class="stack-tight">
    <div class="cap"><span style="color:var(--cA)">&#9646;</span> what the coils can make</div>
    <div class="panel" :class="outside ? 'brass' : ''">
      <span class="k">how much push you get, nearest against shrinking</span>
      <div class="stat" style="color:var(--cC)">{{ gain.toFixed(3) }}x</div>
      <div class="cap">
        {{ outside ? 'The request does not fit, so the two answers differ.'
                   : 'The request fits, so there is nothing to choose between.' }}
      </div>
    </div>

    <div class="panel">
      <span class="k">is energy still leaving the mirror</span>
      <div class="num" :style="{ color: dotN > 0 ? 'var(--cC)' : 'var(--bad)' }">
        nearest &nbsp; {{ dotN.toFixed(3) }}
      </div>
      <div class="num" :style="{ color: dotS > 0 ? 'var(--cB)' : 'var(--bad)' }">
        shrunk &nbsp; {{ dotS.toFixed(3) }}
      </div>
      <div class="cap">Both stay positive wherever you drag it: a theorem, not luck.</div>
    </div>

  </div>
</div>
</template>
