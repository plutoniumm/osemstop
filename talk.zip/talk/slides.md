---
theme: default
title: Control Theory
info: |
  A crash introduction to control theory in five branches: classical, modern,
  stochastic, optimal, and learning-based.
colorSchema: dark
highlighter: shiki
lineNumbers: false
transition: slide-left
class: text-left
fonts:
  provider: none
---

<div class="rail rail-none">
  <span class="rail-part"></span>
  <span class="rail-fill"></span>
</div>

# Control Theory

<div class="lede" style="max-width:58ch">
A crash introduction
</div>

<div class="cols-5 mt4" style="max-width:none">
<div class="panel" style="border-left:2px solid var(--brass)">
<span class="k" style="color:var(--brass)">1 &middot; classical</span>
<p>One loop. Feedback, PID, and what it costs.</p>
</div>
<div class="panel" style="border-left:2px solid var(--brass)">
<span class="k" style="color:var(--brass)">2 &middot; modern</span>
<p>Many loops at once. State vectors, and two rank tests.</p>
</div>
<div class="panel" style="border-left:2px solid var(--brass)">
<span class="k" style="color:var(--brass)">3 &middot; stochastic</span>
<p>Estimating the state under noise.</p>
</div>
<div class="panel" style="border-left:2px solid var(--brass)">
<span class="k" style="color:var(--brass)">4 &middot; optimal</span>
<p>State the cost, solve for the gain.</p>
</div>
<div class="panel" style="border-left:2px solid var(--brass)">
<span class="k" style="color:var(--brass)">5 &middot; learning-based</span>
<p>Machine learning.</p>
</div>
</div>

---

<Rail part="0" name="the problem" />

# The four elements, and the colours used for them

<div class="cols-2 mt4" style="gap:var(--s5) var(--s6)">
<div class="panel p-plant">
<span class="k">plant</span>
<p class="cap">The system being controlled. Fixed: not a design variable.</p>
</div>
<div class="panel p-meas">
<span class="k">sensor</span>
<p class="cap">Produces a number related to the state. Noisy, and rarely the quantity of
interest.</p>
</div>
<div class="panel p-act">
<span class="k">actuator</span>
<p class="cap">The only input. Bounded in amplitude and in rate.</p>
</div>
<div class="panel p-dist">
<span class="k">disturbance</span>
<p class="cap">Unmodelled forcing. Not measured, not controlled.</p>
</div>
</div>

<div class="cols-2 mt5">
<div class="def">
<span class="term">the problem</span> Choose the actuator command as a function of the sensor
reading.
</div>
<div class="def">
<span class="term">the constraint</span> Every such function embodies an assumption about the
plant, and the assumption is approximate.
</div>
</div>

<div class="key mt5">
<span class="kx plant"><b>plant</b></span>
<span class="kx meas"><b>measured</b></span>
<span class="kx act"><b>commanded</b></span>
<span class="kx dist"><b>unmodelled</b></span>
<span class="kx model"><b>model or estimate</b></span>
<span class="cap" style="margin-left:auto">These colours mean the same thing on every
diagram in the deck.</span>
</div>

---

<Rail part="0" name="the problem" />

# Open loop vs closed loop

<BlockLoop />


<Vars :v="[['r','target'], ['e','error'], ['\\delta','model error'], ['L','loop gain']]" />
---

<Rail part="0" name="the problem" />

# Feedforward and feedback

<FeedPaths />

<div class="scroll-x mt5">

| | needs a model | needs a sensor | adds lag | can be destabilised |
|---|---|---|---|---|
| **feedforward** | yes | no | no | no |
| **feedback** | no | yes | yes | yes |

</div>

---
layout: section
class: section
---

<Rail part="1" name="classical" />

# Single input, Single output

What feedback changes, and what it costs

<div class="beatmap">
<div class="bm"><b>1 &middot; math</b>Second-order systems, and the one line of algebra that
closes a loop.</div>
<div class="bm"><b>2 &middot; theory</b>What a fed-back term changes, PID, and the
sensitivity integral.</div>
<div class="bm"><b>3 &middot; applied</b>One velocity loop, then four of them at once.</div>
</div>

---

<Rail part="1" name="classical" beat="math" />

# The second-order system

<Tex block e="\ddot x + 2\zeta\omega_n\,\dot x + \omega_n^2\, x = 0" />

<div class="figbox fw64"><SecondOrder /></div>

<p class="src"><b>plotted</b> The output of <Tex e="\ddot x + 2\zeta\dot x + x = u" /> when
<Tex e="u" /> steps from 0 to 1, with time in units of <Tex e="1/\omega_n" />.</p>


<Vars :cols="3" :v="[['x','displacement'], ['\\omega_n','natural frequency'], ['\\zeta','damping ratio']]" />
---

<Rail part="1" name="classical" beat="math" />

# Closing the loop

<div class="cols-2">
<div>

Pick one frequency. A linear system does exactly two things to a sine at that frequency: it
changes the size and it shifts the timing, which together are one complex number. The plant
contributes <Tex e="P(j\omega)" />, the controller <Tex e="C(j\omega)" />, and going once
round the loop multiplies by both:

<Tex block e="L = P(j\omega)\,C(j\omega)" />

The controller acts on <Tex e="r - y" /> and the plant acts on that, so
<Tex e="y = L\,(r-y)" />, and therefore

<Tex block e="y = \frac{L}{1+L}\; r" />
</div>

<div class="stack-tight">
<div class="def">
<span class="term t-dist">S = 1/(1+L)</span> The fraction of a disturbance that reaches the
output.
</div>
<div class="def">
<span class="term t-meas">T = L/(1+L)</span> The fraction of the reference tracked, and of
the sensor noise transmitted.
</div>
<div class="panel p-plant">
<span class="k">the algebraic constraint</span>
<Tex block e="S + T = 1" />
<p class="cap">At every frequency, identically. Reducing one raises the other, and every
design decision after this slide is choosing where to spend that one.</p>
</div>
</div>
</div>

<Vars :cols="3" :v="[['\\omega','frequency'], ['j','imaginary unit'], ['P','plant'], ['C','controller'], ['L','loop gain'], ['y','output'], ['S','sensitivity'], ['T','complementary sensitivity']]" />

---

<Rail part="1" name="classical" beat="theory" />

# What feeding a signal back changes

<div class="cols-w">
<div>
<Tex block e="\ddot x + \big(2\zeta\omega_n + \ub{K_v}{velocity fed back}\big)\dot x + \big(\omega_n^2 + \ub{K_x}{position fed back}\big) x = 0" />
</div>
<div class="def">
<span class="term">two places to land</span> Each law adds one term, and which
<em>coefficient</em> it lands in is the whole difference.
</div>
</div>

<div class="figbox fw64"><DecayCompare /></div>

<p class="src"><b>the difference</b> The middle coefficient sets how fast the motion dies; the
last one sets how fast it oscillates. Only the first of those dissipates energy.</p>

<Vars :cols="2" :v="[['K_v','velocity gain'], ['K_x','position gain']]" />

---

<Rail part="1" name="classical" beat="theory" />

# PID

<div class="cols-2">
<div>
<Tex block e="u = \ub{K_p e}{now} + \ub{K_i\!\int\! e\,\mathrm{d}t}{so far} + \ub{K_d\,\dot e}{trend}" />
</div>
<div class="panel p-act">
<span class="k">why it remains the default</span>
<p class="cap">Three scalars, no model of the plant, and a tuning procedure that needs no
model either.</p>
</div>
</div>

<div class="scroll-x mt4">

| | acts on | corrects | costs |
|---|---|---|---|
| **P** | the present error | rise time | steady-state offset remains; overshoot at high gain |
| **I** | the accumulated error | the offset, exactly | stability margin; winds up against actuator limits |
| **D** | the error trend | overshoot and ringing | amplifies sensor noise |

</div>


<Vars :v="[['u','control input'], ['K_p','proportional gain'], ['K_i','integral gain'], ['K_d','derivative gain']]" />
---

<Rail part="1" name="classical" beat="theory" />

# The Bode sensitivity integral

<Tex block e="\int_0^{\infty} \ln\big|S(j\omega)\big|\;\mathrm{d}\omega \;=\; 0" />

<div class="figbox fw80"><Waterbed /></div>

<p class="src"><b>plotted</b> <Tex e="\ln|S(j\omega)|" /> for
<Tex e="L = K/\big(j\omega(1+2.5j\omega)\big)" />, on a
<b style="text-transform:none; letter-spacing:0">linear</b> frequency axis, which is what
makes the two regions comparable as areas. Suppression is deep and narrow, amplification
shallow and wide: equal areas, unequal visibility.</p>

---

<Rail part="1" name="classical" beat="applied" />

# A single loop on this instrument

<div class="cols-2">
<div>

The reference is zero, and the quantity fed back is the **rate**, not the position. Every PID
term therefore means something other than what it means on a position error.

<div class="scroll-x mt3">

| | on a position error | here, on a velocity |
|---|---|---|
| **P** | stiffness | **damping** |
| **I** | removes steady offset | a spring: dissipates nothing |
| **D** | damping | added inertia |

</div>
</div>

<div class="stack-tight">
<div class="panel p-act">
<span class="k">the dissipation condition</span>
<Tex block e="P_{\text{delivered}} = \ub{\sigma\,(u - u_0)}{force on its own axis}\;\;\;\ub{v}{velocity} = -\,\sigma K\,v^{2}" />
<p class="cap">Since <Tex e="v^2 \ge 0" />, energy leaves the plant if and only if
<Tex e="\sigma K > 0" />, where <Tex e="\sigma" /> is the actuator's measured effect on its
own sensor.</p>
</div>
<div class="def">
<span class="term">why this needs no model</span> Sensor and actuator share a coordinate, so
the sign condition is the whole requirement. It holds at any positive gain, for any plant.
</div>
</div>
</div>


<Vars :v="[['\\sigma','actuator gain on its own sensor'], ['K','velocity gain'], ['v','velocity'], ['u_0','resting command']]" />
---

<Rail part="1" name="classical" beat="applied" />

# Four such loops, closed at the same time

<FourLoops />

<div class="cols-w mt4">
<div class="kv wide">
<span class="k">measured on this instrument, four loops against one</span>
<div><i>together</i><b>settles in about 17 s</b></div>
<div><i>one at a time</i><b>about 70 s</b></div>
</div>
<div class="def">
<span class="term">and it is still four SISO loops</span> The improvement comes from covering
the shared modes in parallel, not from any controller knowing about any other.
</div>
</div>

---
layout: section
class: section
---

<Rail part="2" name="modern" />

# Many inputs, many outputs

State variables, two rank conditions, and estimating what is not measured

<div class="beatmap">
<div class="bm"><b>1 &middot; math</b>State space, controllability and observability, and
non-square inverses.</div>
<div class="bm"><b>2 &middot; theory</b>State feedback and the observer, which are the same
problem transposed.</div>
<div class="bm"><b>3 &middot; applied</b>The modal law: two coordinate changes around one
gain.</div>
</div>

---

<Rail part="2" name="modern" beat="math" />

# A body with several degrees of freedom is several of those

<div class="cols-w">
<div>
<Tex block e="\ub{M}{inertia}\,\ddot q + \ub{D}{damping}\,\dot q + \ub{K}{stiffness}\,q = 0" />
</div>
<div class="def">
<span class="term">the claim</span> Section 1's scalar equation is not an approximation to
this. It is one <em>row</em> of it, written in the right coordinates.
</div>
</div>

<div class="figbox fw64"><ModalDecouple /></div>

<div class="cols-3 mt4">
<div class="panel p-plant">
<span class="k">exact when</span>
<p class="cap">The system is linear and M is positive definite. Then M and K are
simultaneously diagonalisable, always.</p>
</div>
<div class="panel p-dist">
<span class="k">approximate when</span>
<p class="cap">Oscillations are small, so the restoring force is linear, and D is
near-diagonal in the same basis.</p>
</div>
<div class="panel p-meas">
<span class="k">fails when</span>
<p class="cap">Amplitudes reach the nonlinear part, or internal elastic modes fall inside the
control band.</p>
</div>
</div>


<Vars :cols="3" :v="[['M','inertia matrix'], ['D','damping matrix'], ['K','stiffness matrix'], ['q','coordinates'], ['\\varphi','mode shape']]" />
---

<Rail part="2" name="modern" beat="math" />

# State space

<div class="figbox fw64"><StateSpace /></div>

<div class="cols-w mt4">
<div>
<Tex block e="\dot x = \ub{A}{plant}\,x + \ub{B}{actuators}\,u, \qquad y = \ub{C}{sensors}\,x" />
</div>
<div class="stack-tight">
<div class="def">
<span class="term">state</span> The smallest set of variables from which the future is
determined, given the inputs.
</div>
<div class="def">
<span class="term">why not one loop at a time</span> Section 1's algebra describes one
input-output pair, so cross-coupling appears in none of them.
</div>
</div>
</div>


<Vars :v="[['x','state'], ['A','state matrix'], ['B','input matrix'], ['C','output matrix']]" />
---

<Rail part="2" name="modern" beat="math" />

# Controllability and observability

<div class="cols-2">
<div class="panel p-act">
<span class="k">controllability</span>
<Tex block e="\operatorname{rank}\begin{bmatrix} B & AB & \cdots & A^{n-1}B\end{bmatrix} = n" />
<p class="cap">If this fails, some direction of the state is unreachable by any input, at any
gain, under any control law.</p>
</div>
<div class="panel p-meas">
<span class="k">observability</span>
<Tex block e="\operatorname{rank}\begin{bmatrix} C \\ CA \\ \vdots \\ CA^{n-1}\end{bmatrix} = n" />
<p class="cap">If this fails, some direction of the state never appears in the output. An
estimator will assign it a value and report confidence in it.</p>
</div>
</div>

<div class="panel p-plant mt4">
<span class="k">duality</span>
<p class="cap"><Tex e="(A,B)" /> is controllable if and only if
<Tex e="(A^{\top}\!, B^{\top})" /> is observable. Each result about steering a system is a
result about estimating one, transposed, so one algorithm serves both.</p>
</div>


<Vars :v="[['n','number of states']]" />
---

<Rail part="2" name="modern" beat="math" />

# Neither matrix is square, and both ways are useful

<div class="figbox fw73"><PseudoInv /></div>

<div class="cols-2 mt3">
<div class="panel p-meas">
<span class="k">tall &middot; no exact solution, so take the closest</span>
<Tex block e="\Phi^{+} = (\Phi^{\top}\Phi)^{-1}\Phi^{\top} \quad\text{minimises}\quad \big\|\Phi\,\dot q - \dot y\big\|" />
<p class="cap">The part of the reading no state can account for is what is left, and nothing
else in the loop produces it. <b>It is a check.</b></p>
</div>
<div class="panel p-act">
<span class="k">wide &middot; many exact solutions, so take the shortest</span>
<Tex block e="B^{+} = B^{\top}(BB^{\top})^{-1} \quad\text{minimises}\quad \|u\| \;\text{ subject to }\; Bu = f" />
<p class="cap">Every other solution produces the same force and spends more doing it.
<b>It is spare capacity.</b></p>
</div>
</div>

<Vars :cols="3" :v="[['\\Phi','sensor matrix, tall'], ['B','input matrix, wide'], ['(\\cdot)^{+}','pseudo-inverse']]" />

---

<Rail part="2" name="modern" beat="theory" />

# State feedback

<div class="cols-2">
<div>
<Tex block e="u = -Kx \;\Longrightarrow\; \dot x = \ub{(A - BK)}{the plant it becomes}\,x" />

<p class="cap mt3">Feeding the whole state back through one matrix replaces the plant with a
different plant. If <Tex e="(A,B)" /> is controllable, <Tex e="K" /> can give that new plant
<b>any dynamics at all</b>.</p>
</div>

<div class="stack-tight">
<div class="panel p-act">
<span class="k">what the method does not supply</span>
<p class="cap">Which dynamics to ask for. Faster means larger gains and earlier actuator
saturation, and nothing here says where to stop. Section 4 supplies the criterion.</p>
</div>
<div class="panel p-meas">
<span class="k">and what it assumes</span>
<p class="cap"><Tex e="u = -Kx" /> requires <Tex e="x" />. The available signal is
<Tex e="y" />.</p>
</div>
</div>
</div>

<Vars :v="[['K','feedback gain matrix']]" />

---

<Rail part="2" name="modern" beat="theory" />

# The observer

<div class="figbox fw73"><Observer /></div>

<div class="cols-w mt4">
<div>
<Tex block e="\dot e = (A - LC)\,e" />
</div>
<div class="def">
<span class="term">the same problem transposed</span> Observability lets the error decay at
any rate you specify, exactly as controllability did for the state.
</div>
</div>


<Vars :v="[['L','observer gain'], ['e','estimate error'], ['\\hat x','state estimate']]" />
---

<Rail part="2" name="modern" beat="applied" />

# The modal law

<ModalChain />


<Vars :v="[['\\dot q','modal rates'], ['f','modal force']]" />
---
layout: section
class: section
---

<Rail part="3" name="stochastic" />

# Estimation under noise

Weighting a model against an instrument, and checking the result

<div class="beatmap">
<div class="bm"><b>1 &middot; math</b>The two noise covariances, differentiation, and the
filter recursion.</div>
<div class="bm"><b>2 &middot; theory</b>What sets the gain, divergence, and the consistency
test.</div>
<div class="bm"><b>3 &middot; applied</b>The state, the measurement model, and a test that is
logged rather than acted on.</div>
</div>

---

<Rail part="3" name="stochastic" beat="math" />

# Two noises, and why a rate cannot just be differenced

<div class="cols-2">
<div class="panel p-dist">
<span class="k">process noise &middot; Q</span>
<p class="cap">Forcing absent from the model, entering every step. Sets how fast an unaided
prediction degrades.</p>
</div>
<div class="panel p-meas">
<span class="k">measurement noise &middot; R</span>
<p class="cap">Error in a single reading, present even with the system at rest.</p>
</div>
</div>

<div class="cols-3 mt5">
<div class="panel p-meas">
<span class="k">the obvious way to get a rate</span>
<Tex block e="\dot y \approx \frac{y_k - y_{k-1}}{\Delta t}" />
<p class="cap">Differentiation multiplies amplitude by <Tex e="\omega" />. The signal is
low-frequency and the noise is broadband, so this scales up precisely the part you did not
want.</p>
</div>
<div class="panel p-dist">
<span class="k">low-pass afterwards</span>
<p class="cap">Removes the amplified noise and adds lag. A correction that arrives late is no
longer opposing the motion it was computed from, and past a quarter cycle of lag it adds
energy rather than removing it.</p>
</div>
<div class="panel p-model">
<span class="k">state estimation instead</span>
<p class="cap">The rate is a coordinate of the state, so the model supplies it directly --
weighted by Q against R, and never differenced between two readings.</p>
</div>
</div>

<Vars :cols="4" :v="[['Q','process noise covariance'], ['R','measurement noise covariance'], ['y_k','reading at step k'], ['\\Delta t','sample interval']]" />

---

<Rail part="3" name="stochastic" beat="math" />

# Predict, then compare

<div class="lede">
The model advances the estimate on its own, and then the measurement is compared against what
that estimate says it should be.
</div>

<KalmanFlow :steps="[0,1]" />

<Vars :cols="3" :v="[['\\hat x','state estimate'], ['P','estimate covariance'], ['F','state transition'], ['H','measurement model'], ['\\tilde y','residual'], ['S','residual covariance']]" />

---

<Rail part="3" name="stochastic" beat="theory" />

# The Kalman gain

<div class="cols-2">
<div>

The residual says the estimate was wrong. The gain decides how far to move toward the
measurement, and it is the ratio of the two uncertainties in the same units:

<Tex block e="K = \ub{P^{-}H^{\top}}{model uncertainty}\Big(\ub{HP^{-}H^{\top}}{the same, in sensor units} + \ub{R}{sensor noise}\Big)^{-1}" />
<Tex block e="\hat x = \hat x^{-} + K\,\tilde y" />
</div>

<div class="stack-tight">
<div class="kv wide">
<div><i>K large</i><b>the model is the weaker of the two; follow the reading</b></div>
<div><i>K small</i><b>the sensor is the weaker; keep the prediction</b></div>
</div>

<div class="panel p-model mt3">
<span class="k">difference from a fixed filter</span>
<p class="cap">A low-pass has a cutoff chosen by the designer. This gain follows from Q and R,
and is the minimum-variance weighting for them.</p>
</div>
<div class="panel p-plant">
<span class="k">the requirement it introduces</span>
<p class="cap">A model the plant obeys. A wrong parameter is now inside the estimator, and the
estimate stays confident while it is wrong.</p>
</div>
</div>
</div>

<Vars :cols="2" :v="[['K','Kalman gain'], ['P^{-}','covariance before the update']]" />

---

<Rail part="3" name="stochastic" beat="theory" />

# The check that comes free with it

<div class="cols-2">
<div>
<div class="panel p-meas">
<span class="k">S was already computed for the gain</span>
<p class="cap">It is the covariance the residual <em>should</em> have, if the model is right.
So the residual can be measured against its own prediction at no extra cost.</p>
</div>

<div class="panel p-model mt3">
<span class="k">the residual, in units of its own expected spread</span>
<Tex block e="\chi^2 = \tilde y^{\top} S^{-1} \tilde y" />
<p class="cap">Expected value equal to the number of measurements. The null distribution is
known before deployment, so no threshold is fitted.</p>
</div>
</div>

<div class="panel p-plant">
<span class="k">what it detects</span>
<div class="kv narrow">
<div><i>catches</i><b>a drifted parameter</b></div>
<div><i>catches</i><b>a sensor whose calibration has changed</b></div>
<div><i>catches</i><b>a model that no longer describes the plant</b></div>
</div>
<p class="cap mt3">In each case no individual reading is out of range, so a limit check does
not fire. Only the pattern across readings, against what the model predicted, disagrees.</p>
</div>
</div>

<Vars :v="[['\\chi^2','normalised residual']]" />

---

<Rail part="3" name="stochastic" beat="theory" />

# When the model is wrong

<div class="lede">
The gain is optimal given Q, R and the dynamics. Nothing in the recursion checks whether those
are right.
</div>

<div class="cols-3 mt4">
<div class="panel p-model">
<span class="k">the failure mode</span>
<p class="cap">P shrinks as measurements accumulate, so K falls. A filter that has convinced
itself the estimate is good stops weighting the sensor, and a bias it acquired is never
corrected.</p>
</div>
<div class="panel p-dist">
<span class="k">why it is quiet</span>
<p class="cap">The estimate does not oscillate or blow up. It is smooth, confident and wrong,
and downstream the controller acts on it as if it were the state.</p>
</div>
<div class="panel p-act">
<span class="k">the two standard remedies</span>
<p class="cap">Inflate Q, or discount old measurements, so P has a floor and K cannot reach
zero. Both trade accuracy for the ability to react to a change.</p>
</div>
</div>

<div class="panel p-meas mt4">
<span class="k">and this is what the consistency test is for</span>
<p class="cap">Divergence is invisible in the state estimate and visible in the residual: the
filter predicts small residuals and keeps observing large ones. Monitoring the residual is the
only part of the recursion that can detect the recursion being wrong.</p>
</div>

---

<Rail part="3" name="stochastic" beat="applied" />

# The estimator on this instrument

<EstimatorState />

<div class="cols-2 mt4">
<div class="panel p-plant">
<span class="k">the consistency test runs every step and is acted on by nothing</span>
<p class="cap">Its null distribution is known for a correct model. Its distribution
<em>on this instrument</em> has not been measured, so no threshold has been set.</p>
</div>
<div class="def">
<span class="term">which is the right order</span> A trigger with a guessed threshold is a new
way to fail, added to a loop whose existing failure mode is spurious faults.
</div>
</div>

---
layout: section
class: section
---

<Rail part="4" name="optimal" />

# Optimal control

Specifying a cost instead of choosing gains, and what that does not buy

<div class="beatmap">
<div class="bm"><b>1 &middot; math</b>The quadratic cost, the Riccati equation, and the
separation theorem.</div>
<div class="bm"><b>2 &middot; theory</b>The robustness result, and the effect of actuator
limits.</div>
<div class="bm"><b>3 &middot; applied</b>The actuator budget, and a reallocation that has not
been run.</div>
</div>

---

<Rail part="4" name="optimal" beat="math" />

# The cost function

<Tex block e="J = \int_0^{\infty}\Big( \ub{x^{\top} Q\, x}{deviation}+ \ub{u^{\top} R\, u}{effort} \Big)\,\mathrm{d}t" />

<div class="cols-3 mt2">
<div class="panel p-plant">
<span class="k">why quadratic and not something else</span>
<p class="cap">A penalty must be zero at zero and indifferent to the sign of the deviation.
Quadratic is the lowest order that is both, and the one that leaves the optimal law
<b>linear in the state</b>.</p>
</div>
<div class="panel p-act">
<span class="k">what Q and R are</span>
<p class="cap">Weight matrices, with <Tex e="Q \succeq 0" /> and <Tex e="R \succ 0" />.
<b>R must be invertible</b>, which is what makes the next slide solvable.</p>
</div>
<div class="panel p-model">
<span class="k">only their ratio matters</span>
<p class="cap">Scaling <Tex e="J" /> does not move its minimum, so fix one and tune the
other. A standard start sets each diagonal entry to
<Tex e="1/(\text{largest acceptable value})^2" />.</p>
</div>
</div>

<div class="figbox fw55 mt2"><CostTrade /></div>

<Vars :cols="3" :v="[['J','cost'], ['Q','state weight'], ['R','input weight']]" />

---

<Rail part="4" name="optimal" beat="math" />

# Where the gain comes from

<div class="steps">

<div class="panel p-model">
<span class="k">1 &middot; guess the shape of what is still to be paid</span>
<div class="sx">
<Tex block e="V(x) = x^{\top} P x" />
<p class="cap">The cost still to come, starting from <Tex e="x" />. For linear dynamics and a
quadratic cost it really is quadratic, so the guess turns out exact.</p>
</div>
</div>

<div class="panel p-act">
<span class="k">2 &middot; spent now, plus the change in what is left</span>
<div class="sx">
<Tex block e="0 = \min_u\Big[\;\ub{x^{\top}Qx + u^{\top}Ru}{spent now} \;+\; \ub{2x^{\top}P(Ax + Bu)}{rate the rest changes}\;\Big]" />
<p class="cap">Differentiate the bracket in <Tex e="u" />:
<Tex e="2Ru + 2B^{\top}Px = 0" />, so <Tex e="u = -Kx" /> with
<Tex e="K = R^{-1}B^{\top}P" />. <b>That is the gain, and it came from here.</b></p>
</div>
</div>

<div class="panel p-plant">
<span class="k">3 &middot; put that back, and require it for every x</span>
<div class="sx">
<Tex block e="A^{\top}P + PA - PBR^{-1}B^{\top}P + Q = 0" />
<p class="cap">What is left is <Tex e="x^{\top}[\,\cdot\,]x = 0" /> for all <Tex e="x" />, so
the bracket vanishes. <b>That is the condition P must satisfy</b> for step 1 to have been
consistent.</p>
</div>
</div>

</div>

<Vars :cols="3" :v="[['V','cost still to come'], ['P','Riccati solution'], ['K','optimal gain']]" />

---

<Rail part="4" name="optimal" beat="math" />

# The same equation, twice

<div class="cols-2">
<div class="panel p-act">
<span class="k">regulator</span>
<Tex block e="A^{\top}P + PA - PBR^{-1}B^{\top}P + Q = 0" />
<Tex block e="K = R^{-1}B^{\top}P" />
</div>
<div class="panel p-meas">
<span class="k">estimator</span>
<Tex block e="AP + PA^{\top} - PC^{\top}R^{-1}CP + Q = 0" />
<Tex block e="L = PC^{\top}R^{-1}" />
</div>
</div>

<div class="panel p-plant mt4">
<span class="k">duality, at the level of the solution</span>
<p class="cap">The second is the first under <Tex e="A \to A^{\top}" />,
<Tex e="B \to C^{\top}" />. Section 2 showed the two <em>rank conditions</em> were the same
test transposed; the two <em>optimal designs</em> are the same equation transposed. One
Riccati solver produces both, and Q and R change meaning from chosen weights to
measured covariances.</p>
</div>

---

<Rail part="4" name="optimal" beat="math" />

# LQG and the separation theorem

<Separation />

<div class="cols-w mt4">
<div>
<Tex block e="u = -K\,\hat x" />
</div>
<div class="stack-tight">
<div class="def">
<span class="term">LQG</span> <b>L</b>inear dynamics, <b>Q</b>uadratic cost, <b>G</b>aussian
noise.
</div>
<div class="panel p-act">
<span class="k">full-state LQR guarantee</span>
<div class="kv narrow">
<div><i>gain margin</i><b>the factor the loop gain can be multiplied by before the loop
sustains motion on its own</b></div>
<div><i>phase margin</i><b>the extra lag tolerable where the loop gain is one</b></div>
</div>
<p class="cap mt2">Full-state optimal feedback guarantees <b>one half to infinity</b> and
<b>at least sixty degrees</b>, for every plant and every <Tex e="Q" />, <Tex e="R" />.</p>
</div>
</div>
</div>

---
layout: center
class: text-center
---

<div class="lede" style="max-width:46em; margin:0 auto; text-align:left">
The corresponding question for LQG is what margins the combination retains.
</div>

<div class="pt-6 text-lg" style="color:var(--dim); font-family:var(--serif)">
Doyle, 1978 &middot; <em>Guaranteed Margins for LQG Regulators</em>
</div>

<blockquote class="pt-4" style="display:inline-block; text-align:left; font-size:2.1rem">
There are none.
</blockquote>

<div class="pt-6" style="max-width:44em; margin:0 auto; font-size:var(--fs-sm); color:var(--dim); line-height:1.5; text-align:left">
The abstract in full. No general lower bound exists: LQG designs can be constructed whose
margins are arbitrarily small. Optimality separates; robustness does not.
</div>

---

<Rail part="4" name="optimal" beat="theory" />

# Actuator saturation

<div class="cols-3">
<div class="panel p-act">
<span class="k">the loop opens</span>
<p class="cap">Demand beyond the limit is discarded. The error grows and the applied input
does not change: the feedback path is inactive while the signal path still appears
connected.</p>
</div>
<div class="panel p-act">
<span class="k">integrator windup</span>
<p class="cap">The integral term accumulates an error it cannot act on. On return to range
the command is large and of the wrong sign.</p>
</div>
<div class="panel p-act">
<span class="k">several actuators</span>
<p class="cap">Clipping each channel at its own limit changes the direction of the commanded
vector. Scaling the vector preserves it.</p>
</div>
</div>

<div class="panel p-plant mt5">
<span class="k">the general point</span>
<p class="cap">Every result in sections 1 to 4 is a theorem about a linear system. The
guarantees hold inside the linear region and say nothing outside it, so the design task
includes knowing where that boundary is and detecting when it is crossed.</p>
</div>

---

<Rail part="4" name="optimal" beat="applied" />

# The actuator budget

<BudgetBar />

<div class="cols-w mt4">
<div class="def">
<span class="term">why it matters</span> Once a channel clips, the realised force is not the
vector the allocator computed, and the direction was its entire output.
</div>
<div class="panel p-model">
<span class="k">proposed, and not yet run</span>
<p class="cap">Hold one budget and reallocate it between the modal and per-channel terms as
the disturbance changes. <b>A time-varying blend of two dissipative laws is not known to be
dissipative</b>, and no offline test detects a law that adds energy.</p>
</div>
</div>

---
layout: section
class: section
---

<Rail part="5" name="learning-based" />

# Learning-based control

Where a model is unavailable, and how to add a learned component without discarding sections 1 to 4

<div class="beatmap bm-swap">
<div class="bm"><b>theory, first here</b>The case against learning, the two conditions that
reverse it, and where a learned part can attach.</div>
<div class="bm"><b>then math</b>Learning the model error, and measuring when the learned part
is outside what it was trained on.</div>
<div class="bm"><b>then applied</b>A two-stage plan, read-only first.</div>
</div>

<p class="src mt3"><b>note</b> This is the one section that argues before it derives: whether
to reach for a learned component at all is decided by the first two slides, and the
mathematics is only worth writing down once that answer is yes.</p>

---

<Rail part="5" name="learning-based" beat="theory" />

# When to reach for a learned component, and when not to

<div class="cols-w">
<div class="scroll-x">

| classical wins when | because |
|---|---|
| the plant is **linear** | the optimal controller is a matrix, and superposition holds |
| the model is **known** | Riccati returns that matrix directly |
| the plant is **fully actuated** | every required force is directly achievable |
| the plant is **stable** | there is no failure to avoid, so no pressure to explore |

</div>
<div class="panel p-model">
<span class="k">and the samples are not free</span>
<p class="cap">Training would search for the same matrix the closed form already returns,
without the guarantee. Exploring means applying known-wrong inputs to a plant that runs in
real time and can be damaged.</p>
</div>
</div>

<div class="cols-2 mt5">
<div class="panel p-plant">
<span class="k">1 &middot; but no closed-form model exists</span>
<p class="cap">Contact, friction, backlash, turbulence, human interaction. Not difficult to
linearise: unavailable in closed form. A learned model is then the only model there is.</p>
</div>
<div class="panel p-dist">
<span class="k">2 &middot; or the model was identified once</span>
<p class="cap">Parameters drift, components age, hardware is serviced. Every guarantee in
sections 1 to 4 is conditional on a model that is still current.</p>
</div>
</div>

---

<Rail part="5" name="learning-based" beat="theory" />

# Learn a policy, or learn the dynamics

<PolicyModel />

<div class="cols-3 mt4">
<div class="def">
<span class="term">adaptive control</span> Fixed structure, parameters estimated online. The
oldest of the three, and the one with proofs.
</div>
<div class="def">
<span class="term">a learned dynamics model</span> Predicts the next state, so the world
answers it every step. Sections 1 to 4 then run on top of it.
</div>
<div class="def">
<span class="term">a learned policy</span> State to command directly. Plant and controller
are fused inside it, so nothing it produces can be checked against anything.
</div>
</div>

---

<Rail part="5" name="learning-based" beat="math" />

# Training the residual model

<div class="cols-2">
<div>
<div class="panel p-model">
<span class="k">the target: what the linear model got wrong</span>
<Tex block e="\Delta_k = \ub{x_{k+1}}{what happened} - \ub{(A x_k + B u_k)}{what the model said}" />
</div>

<div class="panel p-meas mt3">
<span class="k">the data: already on disk</span>
<p class="cap">Every control step of every run is one example
<Tex e="(x_k, u_k) \rightarrow \Delta_k" />. No experiment is run to collect it, and the set
grows every time the loop is used.</p>
</div>
</div>

<div class="stack-tight">
<div class="panel p-act">
<span class="k">the loss: predict a spread, not a number</span>
<Tex block e="\mathcal L = \tfrac{1}{2}\Big[\frac{(\Delta-\mu_\theta)^2}{\sigma^2_\theta} \;+\; \ub{\log \sigma^2_\theta}{price of claimed certainty}\Big]" />
<p class="cap">Minimising this makes <Tex e="\sigma^2_\theta" /> the model's own error, because
a member that declares a small variance and then misses is penalised by the first term.</p>
</div>
<div class="def">
<span class="term">the ensemble</span> <Tex e="N" /> members, identical in architecture,
differing only in initialisation and in which bootstrap of the data they see.
</div>
</div>
</div>


<Vars :v="[['\\Delta','model residual'], ['\\theta','network parameters'], ['\\mu_\\theta','predicted mean'], ['\\sigma^2_\\theta','predicted variance'], ['\\mathcal L','training loss']]" />
---

<Rail part="5" name="learning-based" beat="math" />

# Confidence, and what it is allowed to do

<div class="figbox fw64"><EnsembleGate /></div>

<div class="cols-3 mt2">
<div class="panel p-meas">
<span class="k">aleatoric &middot; the noise</span>
<Tex block e="\sigma^2_a = \tfrac{1}{N}\textstyle\sum_i \sigma^2_i" />
<p class="cap">Flat across the plot, so <b>not</b> a safety signal.</p>
</div>
<div class="panel p-dist">
<span class="k">epistemic &middot; the ignorance</span>
<Tex block e="\sigma^2_e = \tfrac{1}{N}\textstyle\sum_i (\mu_i - \bar\mu)^2" />
<p class="cap">Near zero where the data pinned the members together. <b>This one gates.</b></p>
</div>
<div class="panel p-act">
<span class="k">what reaches the actuator</span>
<Tex block e="\Delta u = \operatorname{clip}\!\big(\ub{e^{-\sigma^2_e/\tau}}{the gate}\;\bar\mu,\;\pm u_{\max}\big)" />
<p class="cap">No evidence, no authority; a bound everywhere else.</p>
</div>
</div>


<Vars :cols="4" :v="[['N','ensemble size'], ['\\bar\\mu','ensemble mean'], ['\\sigma^2_a','aleatoric variance'], ['\\sigma^2_e','epistemic variance'], ['\\tau','gate scale'], ['\\Delta u','applied correction'], ['u_{\\max}','authority bound']]" />
---

<Rail part="5" name="learning-based" beat="math" />

# The innovation as a feature vector

<div class="cols-2">
<div class="panel p-meas">
<span class="k">already computed each step</span>
<Tex block e="\tilde y = y - H\hat x^{-}" />
<p class="cap">Zero-mean and serially uncorrelated under a correct model, so any structure in
it corresponds to a fault.</p>
</div>
<div class="panel p-model">
<span class="k">what the scalar discards</span>
<p class="cap"><Tex e="\chi^2" /> is its squared length. Which channels disagreed, and in
what pattern, is discarded with the direction. Different faults produce the same length and
different directions.</p>
</div>
</div>

<InnovationShape />

---

<Rail part="5" name="learning-based" beat="applied" />

# The plan for this instrument

<div class="lede">
Neither stage is built. The ordering is the point: the first is useful on its own and cannot
make anything worse, because it commands nothing.
</div>

<Shield />

---
layout: center
class: text-center
---

# Summary

<div class="pt-4" style="color:var(--dim); font-size:1.0rem; line-height:1.9; max-width:46em; margin:0 auto; text-align:left">

<span class="hi">Classical.</span> One loop in the frequency domain. Which coefficient a
feedback term lands in decides what it does, and the sensitivity integral bounds the total.

<span class="hi">Modern.</span> Coupled loops in the time domain. Two rank conditions
determine solvability before any gain is selected.

<span class="hi">Stochastic.</span> The state is not measured. It is estimated by weighting
the model against the instrument, which also yields a consistency test.

<span class="hi">Optimal.</span> A cost replaces the gains. Optimality separates from
estimation; robustness does not.

<span class="hi">Learning-based.</span> Applicable where no closed-form model exists, and
where an identified model has drifted.

</div>

<div class="pt-6 cap" style="max-width:44em; margin:0 auto; text-align:left">
Sections 1 to 4 are conditional on a model. Section 5 addresses that condition, and is the
least settled of the five.
</div>
