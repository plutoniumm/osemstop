<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'

// Four sensors on one flat plate, each reading motion along the same axis.
// Four readings can be re-combined into four independent patterns. Three of
// them are ways a solid object can move. The fourth is not.
//
// The sign patterns are geometry and are exact. The frequencies are round
// illustrative labels for the three resonances, not measurements.
const MODES = [
  { id: 'T2', label: 'T2', hz: '0.70 Hz',
    plain: 'it tips about the upright axis: the left edge comes toward you, the right edge goes away',
    s: [1, -1, 1, -1], col: 'var(--cA)', rigid: true },
  { id: 'Z', label: 'Z', hz: '0.98 Hz',
    plain: 'the whole mirror moves toward you and back, staying flat on',
    s: [1, 1, 1, 1], col: 'var(--cB)', rigid: true },
  { id: 'T1', label: 'T1', hz: '1.65 Hz',
    plain: 'it tips about the sideways axis: the top edge comes toward you, the bottom goes away',
    s: [1, 1, -1, -1], col: 'var(--cC)', rigid: true },
  { id: 'WARP', label: 'warp', hz: 'no frequency of its own',
    plain: 'opposite corners go opposite ways. A solid plate cannot do this.',
    s: [1, -1, -1, 1], col: 'var(--cD)', rigid: false },
]
const pick = ref(0)
const t = ref(0)
const running = ref(true)
let raf = null, last = 0

function loop(now) {
  if (last && running.value) t.value += (now - last) / 1000
  last = now
  raf = requestAnimationFrame(loop)
}
onMounted(() => { raf = requestAnimationFrame(loop) })
onUnmounted(() => { if (raf) cancelAnimationFrame(raf) })

const m = computed(() => MODES[pick.value])
const phase = computed(() => running.value ? Math.sin(t.value * 2.2) : 1)

const CORNER = [
  { name: 'a0', x: -1, y: -1 },
  { name: 'a1', x: 1, y: -1 },
  { name: 'a2', x: -1, y: 1 },
  { name: 'a3', x: 1, y: 1 },
]
const CX = 208, CY = 108, LIFT = 24

// an oblique view of the plate, so a0 stays top left and a3 bottom right,
// exactly as they are drawn on the rig diagram earlier in the deck
function flatX(c) { return CX + c.x * 96 + c.y * 32 }
function flatY(c) { return CY + c.y * 46 - c.x * 15 }
const pts = computed(() => CORNER.map((c, i) => ({
  x: flatX(c), y: flatY(c) - m.value.s[i] * phase.value * LIFT,
})))
const face = computed(() => {
  const p = pts.value
  return `${p[0].x},${p[0].y} ${p[1].x},${p[1].y} ${p[3].x},${p[3].y} ${p[2].x},${p[2].y}`
})
const flat = computed(() => CORNER.map(c => `${flatX(c)},${flatY(c)}`).join(' '))
</script>

<template>
<div class="cols-w" style="gap:1.1rem">

  <div>
    <svg viewBox="0 0 416 228" class="w-full">
      <polygon :points="flat" fill="none" stroke="var(--line-2)" stroke-width="1.2" stroke-dasharray="4 3"/>
      <polygon :points="face" :fill="m.col" fill-opacity="0.13" :stroke="m.col" stroke-width="1.6"/>
      <g v-for="(p, i) in pts" :key="i">
        <line :x1="p.x" :y1="p.y" :x2="flatX(CORNER[i])" :y2="flatY(CORNER[i])"
              :stroke="m.col" stroke-width="1" stroke-opacity=".45"/>
        <circle :cx="p.x" :cy="p.y" r="5" :fill="m.col"/>
        <text :x="p.x" :y="p.y - 12" text-anchor="middle" font-size="10.5" fill="var(--dim)">
          {{ CORNER[i].name }}</text>
        <text :x="p.x" :y="p.y + 20" text-anchor="middle" font-size="11.5"
              :fill="m.col" font-weight="600">{{ m.s[i] > 0 ? '+1' : '-1' }}</text>
      </g>
      <text x="8" y="13" font-size="9" fill="var(--faint)">dashed = at rest.  solid = one instant</text>
    </svg>
  </div>

  <div class="stack-tight" style="gap:.34rem">
    <button v-for="(mm, i) in MODES" :key="mm.id" class="btn"
            :class="{ on: pick === i }" @click="pick = i"
            style="display:flex; gap:.5rem; align-items:center; padding:.3rem .5rem">
      <!-- the sign pattern, drawn on the button, so all four are visible at once -->
      <svg width="26" height="26" viewBox="0 0 26 26" style="flex:none">
        <g v-for="(sv, j) in mm.s" :key="j">
          <rect :x="j % 2 ? 14 : 1" :y="j > 1 ? 14 : 1" width="11" height="11" rx="1"
                :fill="sv > 0 ? mm.col : 'transparent'" :fill-opacity="sv > 0 ? .85 : 1"
                :stroke="mm.col" stroke-width="1"/>
        </g>
      </svg>
      <span style="flex:1">
        <span class="btn-t">{{ mm.label }} <span style="opacity:.6">{{ mm.hz }}</span></span>
        <span class="btn-s">{{ mm.plain }}</span>
      </span>
    </button>

    <div class="panel" :style="{ borderLeft: '2px solid ' + m.col }">
      <span class="k">{{ m.rigid ? 'a real way the mirror moves' : 'not a way anything solid moves' }}</span>
      <p>
        <template v-if="m.rigid">
          Almost everything happening at {{ m.hz }} is this one pattern. These
          really are three separate motions, not a mathematical convenience.
        </template>
        <template v-else>
          Anything appearing in this pattern is not motion at all -- it is the four
          sensors disagreeing about scale. No gain can remove it, because there is
          nothing to push against.
        </template>
      </p>
    </div>

    <button class="btn" @click="running = !running"
            style="align-self:flex-start; padding:.15rem .45rem; font-size:.6rem">
      {{ running ? 'freeze' : 'animate' }}
    </button>
  </div>
</div>
</template>
