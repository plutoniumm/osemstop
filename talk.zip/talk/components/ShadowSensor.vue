<script setup>
import { ref, computed } from 'vue'

// A shadow sensor: an LED on one side of a gap, a photodiode on the other, and
// a small metal flag bolted to the mirror hanging in between.
//
// It is ONE causal chain, read left to right and numbered, so that each stage is
// visibly the cause of the next:
//
//   1  the flag hangs from the mirror and moves with it
//   2  everything to the RIGHT of the flag and ABOVE its bottom edge is shadow,
//      so the light landing on the photodiode is whatever is left below it
//   3  the ADC turns that into a number, 0 to 1023 counts
//
// The whole point of the graph underneath is the two flat ends: there the
// reading stops responding at all, so a sensor sitting there is BLIND, not
// merely noisy. The railed line at 12 counts is where the controller gives up.

const FULL = 1023
const RAIL = 12          // below this the controller calls the channel railed

// u is the flag position measured in beam diameters. u = 0 is half shadow.
const u = ref(-0.200)    // start off centre, so both halves of the beam show

const lit = computed(() => Math.min(1, Math.max(0, 0.5 - u.value)))
const counts = computed(() => Math.round(FULL * lit.value))
const linear = computed(() => lit.value > 0.02 && lit.value < 0.98)

const PRESETS = [
  { u: 0.000, t: 'half shadow', s: 'the best place to sit' },
  { u: -0.200, t: 'off centre', s: 'brighter, still answers' },
  { u: 0.550, t: 'past the edge', s: 'fully shadowed, blind' },
]

// ---- stage 1 to 3: the chain, drawn once, left to right -------------------
const BT = 44, BB = 116, BH = BB - BT    // the beam
const BX0 = 74, BX1 = 448                // the gap between LED and photodiode
const FX0 = 248, FW = 22                 // the flag, seen edge on
// the flag's bottom edge: at u = -0.5 it is clear of the beam, at u = +0.5 it
// covers the beam entirely.
const flagY = computed(() => BT + BH * Math.min(1, Math.max(0, 0.5 + u.value)))

// ---- the response curve ---------------------------------------------------
function cX(uu) { return 52 + (uu + 0.75) / 1.5 * 390 }
function cY(c) { return 118 - c / FULL * 92 }
const curve = computed(() => {
  const pts = []
  for (let i = 0; i <= 120; i++) {
    const uu = -0.75 + i * 1.5 / 120
    const c = Math.min(1, Math.max(0, 0.5 - uu)) * FULL
    pts.push(`${cX(uu)},${cY(c)}`)
  }
  return pts.join(' ')
})
</script>

<template>
<div>

  <!-- ================= the chain, in three linked stages ================= -->
  <svg viewBox="0 0 900 172" class="w-full">

    <!-- the beam: dark everywhere the flag has taken the light away -->
    <rect :x="BX0" :y="BT" :width="BX1-BX0" :height="BH" fill="#1a1a12"/>
    <!-- upstream of the flag nothing is blocked yet -->
    <rect :x="BX0" :y="BT" :width="FX0-BX0" :height="BH" fill="var(--brass)" fill-opacity="0.45"/>
    <!-- downstream, only what passes UNDER the flag's bottom edge survives -->
    <rect :x="FX0" :y="flagY" :width="BX1-FX0" :height="BB-flagY"
          fill="var(--brass)" fill-opacity="0.45"/>

    <!-- LED -->
    <rect x="22" :y="BT+8" width="52" :height="BH-16" rx="3"
          fill="var(--panel-2)" stroke="var(--line-2)"/>
    <text x="48" :y="BT+BH/2+4" text-anchor="middle" font-size="11" fill="var(--dim)">LED</text>

    <!-- photodiode -->
    <rect :x="BX1" :y="BT+8" width="58" :height="BH-16" rx="3"
          fill="var(--panel-2)" stroke="var(--line-2)"/>
    <text :x="BX1+29" :y="BT+BH/2-2" text-anchor="middle" font-size="10" fill="var(--dim)">photo</text>
    <text :x="BX1+29" :y="BT+BH/2+10" text-anchor="middle" font-size="10" fill="var(--dim)">diode</text>

    <!-- the shadow edge, carried across onto the photodiode -->
    <line :x1="FX0" :y1="flagY" :x2="BX1+58" :y2="flagY"
          stroke="var(--brass)" stroke-width="1" stroke-dasharray="4 3" stroke-opacity="0.65"/>

    <!-- which half is which -->
    <text x="360" :y="(BT+flagY)/2 + 3.5" v-if="flagY - BT > 18"
          text-anchor="middle" font-size="10" fill="var(--dim)" letter-spacing="1.5">SHADOW</text>
    <text x="360" :y="(flagY+BB)/2 + 3.5" v-if="BB - flagY > 18"
          text-anchor="middle" font-size="10" fill="var(--bg)" font-weight="700" letter-spacing="1.5">LIGHT</text>

    <!-- the moving part -->
    <g stroke="var(--ink)" stroke-opacity="0.45" fill="var(--ink)" fill-opacity="0.45">
      <line x1="234" y1="30" x2="234" y2="120" stroke-width="1.2"/>
      <polygon points="234,22 229.5,32 238.5,32" stroke="none"/>
      <polygon points="234,128 229.5,118 238.5,118" stroke="none"/>
    </g>
    <rect :x="FX0" y="10" :width="FW" :height="flagY-10"
          fill="var(--line-2)" stroke="var(--ink)" stroke-width="1"/>
    <text x="280" y="20" font-size="10" fill="var(--ink)">the flag, bolted to the mirror</text>

    <!-- photodiode out to the number -->
    <g stroke="var(--line-2)" fill="var(--line-2)">
      <line x1="514" y1="80" x2="544" y2="80" stroke-width="1.4"/>
      <polygon points="552,80 542,75 542,85" stroke="none"/>
    </g>

    <!-- stage 3: what the computer actually gets -->
    <rect x="558" y="28" width="332" height="106" rx="4"
          fill="var(--panel)" stroke="var(--line)"/>
    <text x="574" y="46" font-size="9" fill="var(--faint)" letter-spacing="1.3">WHAT THE COMPUTER READS</text>
    <text x="574" y="94" font-size="36" font-weight="600"
          style="font-variant-numeric:tabular-nums"
          :fill="linear ? 'var(--brass)' : 'var(--bad)'">{{ counts }}</text>
    <text x="880" y="94" text-anchor="end" font-size="12" fill="var(--faint)">counts, out of 1023</text>
    <text x="574" y="118" font-size="10.5" :fill="linear ? 'var(--good)' : 'var(--bad)'">
      {{ linear ? 'move the mirror and this number moves' : 'move the mirror and this number does not move' }}</text>

    <!-- the three stages, named under the thing that does them -->
    <g font-size="9.5" text-anchor="middle" fill="var(--dim)">
      <circle cx="259" cy="146" r="8" fill="var(--panel)" stroke="var(--line-2)"/>
      <text x="259" y="149.5" font-size="9" fill="var(--dim)">1</text>
      <text x="259" y="166">the flag moves with the mirror</text>

      <circle cx="477" cy="146" r="8" fill="var(--panel)" stroke="var(--line-2)"/>
      <text x="477" y="149.5" font-size="9" fill="var(--dim)">2</text>
      <text x="477" y="166">so more or less light lands here</text>

      <circle cx="712" cy="146" r="8" fill="var(--panel)" stroke="var(--line-2)"/>
      <text x="712" y="149.5" font-size="9" fill="var(--dim)">3</text>
      <text x="712" y="166">which becomes a number</text>
    </g>
  </svg>

  <!-- ============ the same chain, swept over every flag position ========= -->
  <div class="cols-w mt2">
    <svg viewBox="0 0 460 150" class="w-full">
      <!-- the two places where the curve is flat: moving the mirror does nothing -->
      <rect :x="cX(-0.75)" y="26" :width="cX(-0.5)-cX(-0.75)" :height="cY(0)-26"
            fill="var(--bad)" fill-opacity=".16"/>
      <rect :x="cX(0.5)" y="26" :width="cX(0.75)-cX(0.5)" :height="cY(0)-26"
            fill="var(--bad)" fill-opacity=".16"/>
      <line x1="52" :y1="cY(RAIL)" x2="442" :y2="cY(RAIL)" stroke="var(--bad)"
            stroke-width="1" stroke-dasharray="3 3" stroke-opacity=".7"/>
      <line x1="52" :y1="cY(0)" x2="442" :y2="cY(0)" stroke="var(--line)"/>
      <line x1="52" y1="26" x2="52" :y2="cY(0)" stroke="var(--line)"/>
      <polyline :points="curve" fill="none" stroke="var(--cA)" stroke-width="2"/>

      <!-- where the flag is right now -->
      <line :x1="cX(u)" y1="26" :x2="cX(u)" :y2="cY(0)" stroke="var(--brass)" stroke-dasharray="3 3"/>
      <circle :cx="cX(u)" :cy="cY(counts)" r="5.5" fill="var(--brass)"/>

      <text x="46" :y="cY(FULL)+4" text-anchor="end" font-size="9" fill="var(--faint)">1023</text>
      <text x="46" :y="cY(FULL/2)+4" text-anchor="end" font-size="9" fill="var(--faint)">512</text>
      <text x="46" :y="cY(0)+4" text-anchor="end" font-size="9" fill="var(--faint)">0</text>
      <text x="52" y="18" font-size="9.5" fill="var(--dim)">what the computer reads, in counts</text>
      <text :x="(cX(-0.75)+cX(-0.5))/2" y="133" text-anchor="middle" font-size="8" fill="var(--bad)">no info</text>
      <text :x="(cX(0.5)+cX(0.75))/2" y="133" text-anchor="middle" font-size="8" fill="var(--bad)">no info</text>
      <text x="247" y="146" text-anchor="middle" font-size="9.5" fill="var(--faint)">flag position, in beam diameters</text>
      <text x="58" :y="cY(RAIL)-5" font-size="8" fill="var(--bad)">railed, below 12 counts</text>
    </svg>

    <div class="stack-tight" style="gap:.35rem">
      <div class="readout">
        <span class="rl">flag position</span>
        <span class="rv">{{ u.toFixed(3) }}</span>
      </div>
      <input type="range" min="-0.62" max="0.62" step="0.002" v-model.number="u">
      <div style="display:flex; gap:.5rem">
        <button v-for="p in PRESETS" :key="p.t" class="btn" style="flex:1"
                :class="{ on: Math.abs(u - p.u) < 1e-9 }" @click="u = p.u">
          <span class="btn-t">{{ p.t }}</span><span class="btn-s">{{ p.s }}</span>
        </button>
      </div>
    </div>
  </div>
</div>
</template>
