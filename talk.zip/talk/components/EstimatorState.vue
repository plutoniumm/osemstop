<script setup>
// What the estimator on this instrument actually holds.
//
// Two points the equations do not make obvious. First, velocity is a
// COORDINATE of the state, so the loop reads it off rather than differencing
// two samples -- which is the whole reason the estimator is there. Second, the
// measurement model is a table with one row per sensor, so a sensor that fails
// is a deleted row rather than a down-weighted one, and the estimate survives
// because more sensors than modes were kept.
const MODES = [0, 1, 2]
const SENSORS = [0, 1, 2, 3, 4, 5, 6, 7]
const DEAD = 5
const RH = 19, R0 = 30
const ry = i => R0 + i * RH
</script>

<template>
<div>
<svg viewBox="0 0 728 190" class="w-full" role="img"
     aria-label="The state holds a position and a rate per mode plus one drift per sensor; the measurement table has one row per sensor, and a failed sensor removes its row.">

  <!-- ================================ STATE ============================ -->
  <text x="26" y="18" font-size="9" fill="var(--c-model)" font-weight="600" letter-spacing=".06em">THE STATE</text>

  <g v-for="m in MODES" :key="m">
    <rect :x="26"  :y="R0 + m * 34" width="74" height="28" rx="2"
          stroke="var(--c-model)" fill="var(--panel)"/>
    <rect :x="104" :y="R0 + m * 34" width="74" height="28" rx="2"
          stroke="var(--c-model)" fill="rgba(224,166,58,.10)"/>
    <text x="63"  :y="R0 + m * 34 + 18" font-size="9" fill="var(--dim)" text-anchor="middle">position</text>
    <text x="141" :y="R0 + m * 34 + 18" font-size="9" fill="var(--c-model)" text-anchor="middle">rate</text>
    <text x="16"  :y="R0 + m * 34 + 18" font-size="8" fill="var(--faint)" text-anchor="middle">{{ m + 1 }}</text>
  </g>
  <rect x="26" y="132" width="152" height="28" rx="2" stroke="var(--c-model)"
        fill="var(--panel)" stroke-dasharray="3 2"/>
  <text x="102" y="150" font-size="9" fill="var(--dim)" text-anchor="middle">one slow drift per sensor</text>

  <text x="26" y="180" font-size="8.5" fill="var(--c-model)">three rigid-body modes, all below 2 Hz</text>

  <!-- ============================ MEASUREMENT ========================== -->
  <text x="248" y="18" font-size="9" fill="var(--c-meas)" font-weight="600" letter-spacing=".06em">H, THE MEASUREMENT TABLE</text>

  <g v-for="r in SENSORS" :key="'r' + r">
    <g v-for="c in 14" :key="c">
      <rect :x="248 + (c - 1) * 15" :y="ry(r)" width="13" height="17" rx="1"
            :fill="r === DEAD ? 'var(--panel)' : 'rgba(229,135,122,.16)'"
            :stroke="r === DEAD ? 'var(--line)' : 'var(--c-meas)'"
            :opacity="r === DEAD ? .45 : 1"/>
    </g>
    <text x="240" :y="ry(r) + 13" font-size="8" text-anchor="end"
          :fill="r === DEAD ? 'var(--faint)' : 'var(--dim)'">{{ r }}</text>
  </g>
  <line x1="242" :y1="ry(DEAD) + 8.5" x2="556" :y2="ry(DEAD) + 8.5"
        stroke="var(--bad)" stroke-width="1.4"/>


  <!-- ============================== READINGS =========================== -->
  <g fill="none" marker-end="url(#es-a)">
    <path d="M462 104 H 500" stroke="var(--c-meas)"/>
  </g>
  <text x="514" y="18" font-size="9" fill="var(--c-meas)" font-weight="600" letter-spacing=".06em">READINGS</text>
  <g v-for="r in SENSORS" :key="'y' + r">
    <rect x="514" :y="ry(r)" width="40" height="17" rx="1"
          :fill="r === DEAD ? 'var(--panel)' : 'rgba(229,135,122,.16)'"
          :stroke="r === DEAD ? 'var(--line)' : 'var(--c-meas)'"
          :opacity="r === DEAD ? .45 : 1"/>
  </g>

  <text x="562" :y="ry(DEAD) + 13" font-size="8.5" fill="var(--bad)">deleted, not down-weighted</text>

  <defs>
    <marker id="es-a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-meas)" stroke="none"/></marker>
  </defs>
</svg>

<div class="cols-3 mt3" style="gap:var(--s5)">
  <p class="cap"><b class="t-model">Velocity is a coordinate</b>, not a difference between two
  samples. The shaded cells are what the control law consumes.</p>
  <p class="cap"><b class="t-meas">One row per sensor.</b> A sensor that fails removes its row
  from the table and its entry from the reading vector.</p>
  <p class="cap"><b>More sensors than modes</b>, so the remaining rows still determine every
  mode and the estimate survives the loss.</p>
</div>
</div>
</template>
