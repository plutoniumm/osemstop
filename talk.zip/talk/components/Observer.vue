<script setup>
// You need the state. Nothing hands you the state. So build a copy of the
// plant, run it beside the real one on the same input, and steer the copy with
// the one thing you CAN compare: what it says you should be seeing, against
// what you are actually seeing.
//
// The error between the two obeys a dynamics of its own, and the correction
// gain is exactly what sets its poles. So "make the estimate converge" is the
// same mathematical problem as "make the plant behave", with the matrices
// transposed. That is duality, and it is why one piece of algebra does both.
import Tex from './Tex.vue'
</script>

<template>
<svg viewBox="0 0 728 252" class="w-full" role="img"
     aria-label="A model is run in parallel with the plant on the same input; the difference between the predicted and measured reading, times a gain, corrects the model.">

  <!-- the same input drives both, so any difference is the plant's, not the input's -->
  <g stroke="var(--c-act)" fill="none" marker-end="url(#ob-a)">
    <path d="M16 112 H 40"/>
  </g>
  <g stroke="var(--c-act)" fill="none">
    <path d="M40 112 V 47 M40 112 V 177"/>
  </g>
  <g stroke="var(--c-act)" fill="none" marker-end="url(#ob-a)">
    <path d="M40 47 H 146"/>
    <path d="M40 177 H 146"/>
  </g>
  <circle cx="40" cy="112" r="2.5" fill="var(--c-act)"/>
  <text x="48" y="106" font-size="9" fill="var(--c-act)">input</text>

  <!-- ============================== THE WORLD ========================== -->
  <text x="150" y="16" font-size="10" fill="var(--c-plant)" font-weight="600">THE PLANT</text>
  <rect x="150" y="26" width="136" height="42" rx="3" stroke="var(--c-plant)" fill="var(--panel)"/>
  <text x="218" y="45" font-size="10.5" fill="var(--ink)" text-anchor="middle">plant</text>
  <text x="218" y="58" font-size="8.5" fill="var(--bad)" text-anchor="middle">state not accessible</text>

  <g stroke="var(--c-meas)" fill="none">
    <path d="M286 47 H 400 V 96"/>
  </g>
  <text x="296" y="41" font-size="9" fill="var(--c-meas)">measured reading</text>

  <!-- ============================== THE COPY =========================== -->
  <text x="150" y="146" font-size="10" fill="var(--c-model)" font-weight="600">A MODEL RUN IN PARALLEL</text>
  <rect x="150" y="156" width="136" height="42" rx="3" stroke="var(--c-model)" fill="var(--panel)"/>
  <text x="218" y="175" font-size="10.5" fill="var(--ink)" text-anchor="middle">model of the plant</text>
  <text x="218" y="188" font-size="8.5" fill="var(--c-model)" text-anchor="middle">state fully accessible</text>

  <g stroke="var(--c-model)" fill="none">
    <path d="M286 177 H 400 V 128"/>
  </g>
  <text x="296" y="171" font-size="9" fill="var(--c-model)">predicted reading</text>

  <!-- ============================ THE COMPARISON ======================= -->
  <circle cx="400" cy="112" r="13" fill="var(--panel)" stroke="var(--beat)"/>
  <text x="400" y="116" font-size="11" fill="var(--beat)" text-anchor="middle">&#8722;</text>

  <g stroke="var(--beat)" fill="none" stroke-width="1.3" marker-end="url(#ob-b)">
    <path d="M413 112 H 456"/>
  </g>

  <rect x="460" y="92" width="120" height="42" rx="3" stroke="var(--c-act)" fill="var(--panel)"/>
  <text x="520" y="111" font-size="10.5" fill="var(--ink)" text-anchor="middle">correction</text>
  <text x="520" y="124" font-size="8.5" fill="var(--faint)" text-anchor="middle">gain &#215; residual</text>

  <!-- and back into the copy, which is the only loop in the picture -->
  <g stroke="var(--c-act)" fill="none" stroke-width="1.3" marker-end="url(#ob-c)">
    <path d="M580 113 H 640 V 232 H 218 V 202"/>
  </g>
  <text x="300" y="222" font-size="8.5" fill="var(--c-act)">drives the residual to zero</text>

  <!-- what the whole apparatus exists to produce -->
  <g stroke="var(--c-model)" fill="none" stroke-width="1.3" marker-end="url(#ob-g)">
    <path d="M180 198 V 244"/>
  </g>
  <text x="190" y="242" font-size="9" fill="var(--c-model)">state estimate, to the controller</text>

  <defs>
    <marker id="ob-a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-act)" stroke="none"/></marker>
    <marker id="ob-b" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--beat)" stroke="none"/></marker>
    <marker id="ob-c" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-act)" stroke="none"/></marker>
    <marker id="ob-g" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-model)" stroke="none"/></marker>
  </defs>
</svg>
</template>
