<script setup>
// Four single-input single-output loops closed on one mechanical body.
//
// Each loop is exactly the law of section 1: read a sensor, feed its rate back
// through a gain, drive the actuator beside it. The loops are independent by
// construction -- no channel's controller sees any other channel's reading.
//
// What they are NOT independent in is the plant. Every actuator pushes the
// whole body, so every actuator moves every sensor, and the coupling that the
// four controllers assume away is the only thing the body actually has.
const ROWS = [
  { i: 0, cy: 34 }, { i: 1, cy: 76 }, { i: 2, cy: 118 }, { i: 3, cy: 160 },
]
</script>

<template>
<svg viewBox="0 0 728 230" class="w-full" role="img"
     aria-label="Four independent single-loop controllers, each reading one sensor and driving one actuator, all closed on the same rigid body.">

  <!-- ============================== THE BODY =========================== -->
  <rect x="18" y="16" width="118" height="164" rx="3"
        stroke="var(--c-plant)" fill="var(--panel)"/>
  <text x="77" y="88" font-size="10.5" fill="var(--ink)" text-anchor="middle">one body</text>
  <text x="77" y="103" font-size="8.5" fill="var(--faint)" text-anchor="middle">three modes</text>

  <!-- ============================== THE LOOPS ========================== -->
  <g v-for="r in ROWS" :key="r.i">
    <rect x="178" :y="r.cy - 15" width="86" height="30" rx="3"
          stroke="var(--c-meas)" fill="var(--panel)"/>
    <rect x="300" :y="r.cy - 15" width="70" height="30" rx="3"
          stroke="var(--c-act)" fill="var(--panel)"/>
    <rect x="406" :y="r.cy - 15" width="86" height="30" rx="3"
          stroke="var(--c-act)" fill="var(--panel)"/>

    <text x="221" :y="r.cy + 4" font-size="9.5" fill="var(--ink)" text-anchor="middle">sensor {{ r.i }}</text>
    <text x="335" :y="r.cy + 4" font-size="9.5" fill="var(--ink)" text-anchor="middle" font-family="var(--mono)">&#8722;K</text>
    <text x="449" :y="r.cy + 4" font-size="9.5" fill="var(--ink)" text-anchor="middle">actuator {{ r.i }}</text>

    <g fill="none" marker-end="url(#fl-m)">
      <path :d="`M136 ${r.cy} H 174`" stroke="var(--c-meas)"/>
    </g>
    <g fill="none">
      <path :d="`M264 ${r.cy} H 296`" stroke="var(--c-meas)" marker-end="url(#fl-m)"/>
      <path :d="`M370 ${r.cy} H 402`" stroke="var(--c-act)" marker-end="url(#fl-a)"/>
    </g>
    <path :d="`M492 ${r.cy} H 588`" stroke="var(--c-act)" fill="none"/>
    <circle cx="588" :cy="r.cy" r="2.5" fill="var(--c-act)"/>
  </g>

  <!-- the four commands rejoin at the body, because the body is one object -->
  <path d="M588 34 V 160 M588 160 V 198 H 77 V 184" stroke="var(--c-act)"
        stroke-width="1.4" fill="none" marker-end="url(#fl-a)"/>
  <text x="150" y="218" font-size="8.5" fill="var(--faint)">
    every actuator moves every sensor: the coupling each loop assumes away</text>

  <defs>
    <marker id="fl-m" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-meas)" stroke="none"/></marker>
    <marker id="fl-a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-act)" stroke="none"/></marker>
  </defs>
</svg>
</template>
