<script setup>
import { ref, computed } from 'vue'

// Change one thing: which quantity you feed back. Then watch which way the
// poles move. Velocity feedback moves them left (it damps). Position feedback
// moves them up (it stiffens, and damps nothing).

const MODES = [
  { id: 'A', f: 0.71519, col: 'var(--cA)' },
  { id: 'B', f: 0.99231, col: 'var(--cB)' },
  { id: 'C', f: 1.65307, col: 'var(--cC)' },
]
const G_FREE = 0.0072                       // measured free decay rate, 1/s
const SLOPE = (0.1093 - G_FREE) / 0.035     // calibrated on the one measured point

const law = ref('vel')
const kp = ref(0.035)

const W = 480, H = 264, OX = 404, CY = H / 2, SY = 10.1, SX = 1420
const px = (re, im) => [OX + re * SX, CY - im * SY]

const poles = computed(() => MODES.map(m => {
  const w0 = 2 * Math.PI * m.f
  let g, w
  if (law.value === 'vel') {
    g = G_FREE + SLOPE * kp.value
    w = Math.sqrt(Math.max(1e-9, w0 * w0 - g * g))   // ringing frequency, barely moves
  } else {
    g = G_FREE                                        // stiffness dissipates nothing
    w = w0 * Math.sqrt(1 + 0.6 * (kp.value / 0.075))  // direction is exact, size is a sketch
  }
  return {
    ...m, g, w, w0,
    zeta: g / w,
    tenth: Math.log(10) / g,
    free: px(-G_FREE, w0), freeC: px(-G_FREE, -w0),
    now: px(-g, w), nowC: px(-g, -w),
  }
}))

const MARKS = [
  { k: 0.000, t: 'gain off' },
  { k: 0.035, t: 'what ships' },
  { k: 0.075, t: 'never exceeded' },
]
const moved = computed(() => law.value === 'vel'
  ? 'left, and only left'
  : 'up, and only up')
</script>

<template>
<div class="cols-w">
  <div>
    <div style="display:flex; gap:.5rem; margin-bottom:.5rem">
      <button class="btn" style="flex:1" :class="{ on: law === 'vel' }" @click="law = 'vel'">
        <span class="btn-t">feed back velocity</span>
        <span class="btn-s">push against the motion. This is what the rig does.</span>
      </button>
      <button class="btn" style="flex:1" :class="{ on: law === 'pos' }" @click="law = 'pos'">
        <span class="btn-t">feed back position</span>
        <span class="btn-s">push it back toward the middle instead.</span>
      </button>
    </div>

    <svg :viewBox="`0 0 ${W} ${H}`" class="w-full">
      <!-- the two axes, named in words as well as symbols -->
      <line x1="14" :y1="CY" :x2="W-8" :y2="CY" stroke="var(--line)"/>
      <line :x1="OX" y1="12" :x2="OX" :y2="H-12" stroke="var(--line)"/>
      <text :x="OX-8" y="22" text-anchor="end" font-size="9.5" fill="var(--faint)">up and down: how fast it swings</text>
      <text :x="OX-9" :y="CY+15" text-anchor="end" font-size="9.5" fill="var(--faint)">0</text>
      <text x="16" :y="CY+16" font-size="9.5" fill="var(--faint)">how fast the swinging dies away</text>

      <g v-for="p in poles" :key="p.id">
        <line :x1="p.free[0]" :y1="p.free[1]" :x2="p.now[0]" :y2="p.now[1]"
              :stroke="p.col" stroke-width="1" stroke-dasharray="3 3" stroke-opacity=".5"/>
        <line :x1="p.freeC[0]" :y1="p.freeC[1]" :x2="p.nowC[0]" :y2="p.nowC[1]"
              :stroke="p.col" stroke-width="1" stroke-dasharray="3 3" stroke-opacity=".5"/>
        <!-- where the mode sits with no feedback at all -->
        <g :stroke="p.col" stroke-width="1.2" stroke-opacity=".3">
          <line :x1="p.free[0]-4" :y1="p.free[1]-4" :x2="p.free[0]+4" :y2="p.free[1]+4"/>
          <line :x1="p.free[0]-4" :y1="p.free[1]+4" :x2="p.free[0]+4" :y2="p.free[1]-4"/>
          <line :x1="p.freeC[0]-4" :y1="p.freeC[1]-4" :x2="p.freeC[0]+4" :y2="p.freeC[1]+4"/>
          <line :x1="p.freeC[0]-4" :y1="p.freeC[1]+4" :x2="p.freeC[0]+4" :y2="p.freeC[1]-4"/>
        </g>
        <!-- where it sits now -->
        <g :stroke="p.col" stroke-width="2.1">
          <line :x1="p.now[0]-5.5" :y1="p.now[1]-5.5" :x2="p.now[0]+5.5" :y2="p.now[1]+5.5"/>
          <line :x1="p.now[0]-5.5" :y1="p.now[1]+5.5" :x2="p.now[0]+5.5" :y2="p.now[1]-5.5"/>
          <line :x1="p.nowC[0]-5.5" :y1="p.nowC[1]-5.5" :x2="p.nowC[0]+5.5" :y2="p.nowC[1]+5.5"/>
          <line :x1="p.nowC[0]-5.5" :y1="p.nowC[1]+5.5" :x2="p.nowC[0]+5.5" :y2="p.nowC[1]-5.5"/>
        </g>
        <text :x="p.now[0]-11" :y="p.now[1]+4" text-anchor="end" font-size="10.5"
              :fill="p.col" font-weight="600">{{ p.id }}</text>
      </g>

      <text x="16" y="20" font-size="9" fill="var(--faint)">faint = no feedback</text>
    </svg>
  </div>

  <div class="stack-tight">
    <div class="panel">
      <div class="readout">
        <span class="rl">gain</span><span class="rv">{{ kp.toFixed(3) }}</span>
      </div>
      <input type="range" min="0" max="0.075" step="0.001" v-model.number="kp">
      <div style="display:flex; gap:.35rem">
        <button v-for="m in MARKS" :key="m.k" class="btn" style="flex:1; padding:.3rem .35rem"
                :class="{ on: Math.abs(kp - m.k) < 1e-9 }" @click="kp = m.k">
          <span class="btn-s" style="font-size:8.5px">{{ m.t }}</span>
        </button>
      </div>
    </div>

    <div class="panel brass">
      <span class="k">turning the gain up moves every cross</span>
      <div class="stat" style="font-size:1.1rem; color:var(--brass)">{{ moved }}</div>
    </div>

    <table>
      <thead><tr><th>mode</th><th>swings to die</th><th>10 % in</th></tr></thead>
      <tbody>
        <tr v-for="p in poles" :key="p.id">
          <td :style="{ color: p.col }">{{ p.id }}</td>
          <td class="num">{{ (p.w / (2 * p.g)).toFixed(0) }}</td>
          <td class="num">{{ p.tenth < 1000 ? p.tenth.toFixed(0) + ' s' : 'over 15 min' }}</td>
        </tr>
      </tbody>
    </table>

    <div class="cap">
      The rig has never run position feedback, so the size of that retuning is a
      sketch. The direction is exact.
    </div>
  </div>
</div>
</template>
