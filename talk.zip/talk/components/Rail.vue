<script setup>
// The spine of the deck, on every content slide.
//
// It answers two questions without the reader having to hunt: which of the five
// sections am I in, and which of the three beats -- the general mathematics,
// what it implies, or how it appears on the instrument this work is about.
//
// Nothing here is decoration. Every element encodes something true.
import { computed } from 'vue'

const props = defineProps({
  part:   { type: [String, Number], default: '' },
  name:   { type: String, required: true },
  beat:   { type: String, default: '' },    // math | theory | lesson
  status: { type: String, default: '' },    // ran | blocked | never | general
})

const BEATS = ['math', 'theory', 'applied']

const STATUS = {
  ran:     { t: 'measured on the rig', c: 'ok' },
  blocked: { t: 'ran, then blocked',   c: 'no' },
  never:   { t: 'never run',           c: 'next' },
  general: { t: 'general result',      c: 'gen' },
}
const st = computed(() => STATUS[props.status] || null)
const kind = computed(() => (BEATS.includes(props.beat) ? props.beat : props.beat || 'none'))
</script>

<template>
<div class="rail" :class="'rail-' + kind">
  <span class="rail-part"><b v-if="part !== ''">{{ part }}</b>{{ name }}</span>

  <span v-if="BEATS.includes(beat)" class="rail-beats">
    <template v-for="(b, i) in BEATS" :key="b">
      <!-- the separator is its own element, not a ::before inside the beat
           that follows it, so the lit beat can carry a coloured ground
           without the chevron sitting inside it -->
      <span v-if="i" class="rail-sep" aria-hidden="true">&rsaquo;</span>
      <span class="rail-beat" :class="{ on: b === beat }"><i>{{ i + 1 }}</i>{{ b }}</span>
    </template>
  </span>
  <span v-else-if="beat" class="rail-beats">
    <span class="rail-beat on solo">{{ beat }}</span>
  </span>

  <span class="rail-fill"></span>

  <span v-if="st" class="pill" :class="'pill-' + st.c">{{ st.t }}</span>
</div>
</template>
