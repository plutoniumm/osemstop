<script setup>
// The result that stops people believing feedback is free.
//
// S is the fraction of a disturbance that survives the loop. Below the line the
// loop is helping; above it, the loop is making the disturbance WORSE than if
// it were switched off. Bode proved the two areas are equal, for any stable
// loop of this shape and any controller whatever. Not "usually" equal --
// equal, as an identity.
//
// So a bandwidth is not a thing you buy. It is a thing you MOVE. Push the
// water down where you care and it rises somewhere else, and the only choice
// you have is where to put the bulge.
import { ref, computed } from 'vue'

const k = ref(1.2)
const TAU = 2.5
const WMAX = 10

const X0 = 64, X1 = 712, Y0 = 18, Y1 = 170
const LN_HI = 1.05, LN_LO = -2.7
const wx = w => X0 + (w / WMAX) * (X1 - X0)
const ly = v => Y1 - ((Math.max(LN_LO, Math.min(LN_HI, v)) - LN_LO) / (LN_HI - LN_LO)) * (Y1 - Y0)
const ZERO = computed(() => ly(0))

// L = k / (s (1 + tau s)) evaluated on the imaginary axis
function lnS (w, kk) {
  const dre = -TAU * w * w, dim = w                    // s(1+tau s) at s = jw
  const nre = dre, nim = dim
  const num = Math.hypot(nre, nim)
  const den = Math.hypot(dre + kk, dim)
  return Math.log(Math.max(1e-12, num / den))
}

// omega = 0 is a genuine logarithmic singularity: S vanishes there, because the
// loop has an integrator. The area under it is finite, so the first sliver is
// added analytically and the grid starts one step in.
const N = 320
const H = WMAX / N
const samples = computed(() => Array.from({ length: N }, (_, i) => {
  const w = (i + 1) * H
  return { w, v: lnS(w, k.value) }
}))
const firstSliver = computed(() => H * (Math.log(H / k.value) - 1))

const curve = computed(() =>
  'M' + samples.value.map(s => wx(s.w).toFixed(1) + ',' + ly(s.v).toFixed(1)).join(' L'))

// shade each side of the line separately, so the two areas can be seen
function band (sign) {
  const pts = samples.value.map(s => ({ x: wx(s.w), y: ly(sign > 0 ? Math.max(0, s.v) : Math.min(0, s.v)) }))
  return 'M' + pts.map(p => p.x.toFixed(1) + ',' + p.y.toFixed(1)).join(' L') +
    ' L' + wx(WMAX).toFixed(1) + ',' + ZERO.value.toFixed(1) +
    ' L' + X0.toFixed(1) + ',' + ZERO.value.toFixed(1) + ' Z'
}
const below = computed(() => band(-1))
const above = computed(() => band(1))

// the two areas, by the trapezium rule, in the units the theorem is stated in
const areas = computed(() => {
  let neg = -firstSliver.value, pos = 0
  for (let i = 0; i < N - 1; i++) {
    const m = (samples.value[i].v + samples.value[i + 1].v) / 2 * H
    if (m < 0) neg += -m; else pos += m
  }
  return { neg, pos }
})

const peak = computed(() => Math.exp(Math.max(...samples.value.map(s => s.v))))
</script>

<template>
<div>
<svg viewBox="0 0 728 206" class="w-full" role="img"
     aria-label="The sensitivity function: the area of disturbance suppression below the line equals the area of amplification above it.">

  <path :d="below" fill="var(--good)" opacity=".16"/>
  <path :d="above" fill="var(--bad)" opacity=".20"/>

  <g stroke="var(--line)">
    <line :x1="X0" :y1="ZERO" :x2="X1" :y2="ZERO"/>
    <line :x1="X0" :y1="Y0" :x2="X0" :y2="Y1"/>
  </g>

  <path :d="curve" fill="none" stroke="var(--cA)" stroke-width="1.7"/>

  <text :x="X0 - 6" :y="ZERO + 3" font-size="8" fill="var(--faint)" text-anchor="end">no change</text>
  <text :x="X0 - 6" :y="Y1" font-size="8" fill="var(--good)" text-anchor="end">suppressed</text>
  <text :x="X0 - 6" :y="Y0 + 8" font-size="8" fill="var(--bad)" text-anchor="end">amplified</text>

  <text :x="X0 + 12" :y="ZERO + 26" font-size="9" fill="var(--good)" font-weight="600">suppression</text>
  <text :x="wx(3.5)" :y="ZERO - 26" font-size="9" fill="var(--bad)" font-weight="600">amplification, at other frequencies</text>

  <text :x="X1" :y="Y1 + 14" font-size="8" fill="var(--faint)" text-anchor="end">frequency</text>
  <text :x="X0" :y="Y1 + 14" font-size="8" fill="var(--faint)">slow</text>
  <text :x="X0 + 44" :y="Y1 + 26" font-size="8" fill="var(--faint)">Equality holds over all
    frequency; a few per cent of the amplified area lies beyond the right edge.</text>
</svg>

<div class="ctlrow" style="grid-template-columns:1.4fr .8fr .8fr">
  <div>
    <div class="readout"><span class="rl">loop gain</span>
      <span class="rv">{{ k.toFixed(1) }}</span></div>
    <input type="range" min="0.3" max="3.0" step="0.05" v-model.number="k"
           aria-label="loop gain" class="mt2"/>
  </div>
  <div class="stat"><span class="rl">suppressed</span>
    <span class="rv good">{{ areas.neg.toFixed(2) }}</span></div>
  <div class="stat"><span class="rl">amplified</span>
    <span class="rv bad">{{ areas.pos.toFixed(2) }}</span></div>
</div>
</div>
</template>

