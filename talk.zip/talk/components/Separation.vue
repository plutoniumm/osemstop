<script setup>
// LQG is two designs in one box, and the theorem is about the dashed line.
//
// The estimator is built from Q and R without reference to the controller; the
// regulator is built from its own Q and R assuming the state arrives exactly.
// Neither knows the other exists. The separation theorem says the pair is still
// the optimal output-feedback controller -- and says nothing whatever about
// what margin the pair has.
</script>

<template>
<svg viewBox="0 0 728 156" class="w-full" role="img"
     aria-label="The plant feeds an estimator, which feeds a regulator, which drives the plant. A dashed box around the estimator and regulator marks the two pieces that were designed independently.">

  <!-- the pair that was designed separately -->
  <rect x="232" y="10" width="378" height="72" rx="4" fill="none"
        stroke="var(--line-2)" stroke-dasharray="4 3"/>
  <text x="421" y="97" font-size="8.5" fill="var(--faint)" text-anchor="middle">
    designed separately, and neither refers to the other</text>

  <rect x="60"  y="26" width="120" height="40" rx="3" stroke="var(--c-plant)" fill="var(--panel)"/>
  <rect x="252" y="26" width="140" height="40" rx="3" stroke="var(--c-model)" fill="var(--panel)"/>
  <rect x="450" y="26" width="140" height="40" rx="3" stroke="var(--c-act)" fill="var(--panel)"/>

  <g font-size="10.5" fill="var(--ink)" text-anchor="middle">
    <text x="120" y="45">plant</text>
    <text x="322" y="45">estimator</text>
    <text x="520" y="45">regulator</text>
  </g>
  <g font-size="8.5" fill="var(--faint)" text-anchor="middle">
    <text x="322" y="58">gain from Q and R</text>
    <text x="520" y="58">gain from Q and R</text>
  </g>

  <g fill="none">
    <path d="M180 46 H 248" stroke="var(--c-meas)" marker-end="url(#sp-m)"/>
    <path d="M392 46 H 446" stroke="var(--c-model)" marker-end="url(#sp-d)"/>
    <path d="M590 46 H 650 V 122 H 120 V 70" stroke="var(--c-act)" marker-end="url(#sp-a)"/>
  </g>
  <text x="214" y="40" font-size="9" fill="var(--c-meas)" text-anchor="middle">y</text>
  <text x="419" y="40" font-size="9" fill="var(--c-model)" text-anchor="middle">x&#770;</text>
  <text x="140" y="118" font-size="9" fill="var(--c-act)">u</text>

  <text x="644" y="140" font-size="8.5" fill="var(--faint)" text-anchor="end">
    The theorem covers optimality across the dashed line. It does not cover robustness.</text>

  <defs>
    <marker id="sp-m" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-meas)" stroke="none"/></marker>
    <marker id="sp-d" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-model)" stroke="none"/></marker>
    <marker id="sp-a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-act)" stroke="none"/></marker>
  </defs>
</svg>
</template>
