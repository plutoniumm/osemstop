<script setup>
// The central claim of the whole field, drawn as one picture.
//
// Feedback is not "a way to correct errors". It is a way to become INSENSITIVE
// to what you got wrong. Both rows below are asked to hold an output at a
// target. The top row computes the input it thinks will do that. The bottom row
// measures what actually happened and reacts to the difference.
//
// Then the plant is quietly made different from the model. The top row's error
// tracks the model error exactly; the bottom row's error is divided by (1+L).
// That factor is the reason the subject exists.
import { ref, computed } from 'vue'
import Tex from './Tex.vue'

const err = ref(30)                       // model error, per cent
const L = 20                              // NOMINAL loop gain of the closed row

const d = computed(() => err.value / 100) // delta

// Both rows are asked to hold the output at r. The plant is P0(1+delta); the
// controller was designed for P0.
//
//   OPEN    u = r / P0, so y = P0(1+d) . r/P0 = r(1+d)
//           e/r = |delta|                      -- it inherits the error whole
//
//   CLOSED  u = C(r - y), y = Pu, so y = L(1+d)/(1 + L(1+d)) . r
//           e/r = 1 / (1 + L(1+d))             -- divided by the return difference
const openErr = computed(() => Math.abs(d.value) * 100)
const closedErr = computed(() => Math.abs(100 / (1 + L * (1 + d.value))))

// Where the two cross: delta = 1/(1 + L(1+delta)), i.e. L.delta^2 + (L+1).delta - 1 = 0.
const cross = (-(L + 1) + Math.sqrt((L + 1) * (L + 1) + 4 * L)) / (2 * L)
const openWins = computed(() => Math.abs(d.value) < cross)

const BAR = 168
const bw = e => Math.min(BAR, (e / 55) * BAR)
</script>

<template>
<div class="bl-wrap">
<svg viewBox="0 0 470 214" class="w-full" role="img"
     aria-label="An open-loop path computes its input from a model and inherits the model's error; a closed loop measures the output and divides that error by one plus the loop gain.">

  <!-- ============================= OPEN LOOP ============================ -->
  <text x="4" y="14" font-size="10" fill="var(--dim)" font-weight="600">OPEN LOOP</text>

  <g stroke="var(--line-2)" fill="var(--panel)">
    <rect x="78"  y="26" width="112" height="40" rx="3" stroke="var(--c-act)"/>
    <rect x="256" y="26" width="112" height="40" rx="3" stroke="var(--c-plant)"/>
  </g>
  <g font-size="10.5" fill="var(--ink)" text-anchor="middle">
    <text x="134" y="44">controller</text>
    <text x="312" y="44">plant</text>
  </g>
  <g font-size="8.5" fill="var(--faint)" text-anchor="middle">
    <text x="134" y="57">its idea of the plant</text>
    <text x="312" y="57">the actual thing</text>
  </g>

  <g stroke="var(--line-2)" fill="none" marker-end="url(#bl-ar)">
    <path d="M38 46 H 74"/>
    <path d="M190 46 H 252"/>
    <path d="M368 46 H 424"/>
  </g>
  <g font-size="9" fill="var(--dim)">
    <text x="2" y="43">target</text>
    <text x="396" y="41">output</text>
  </g>

  <!-- there is no arrow back. That is the entire difference. -->
  <text x="204" y="80" font-size="8.5" fill="var(--faint)">no measurement of the result</text>

  <!-- ============================ CLOSED LOOP =========================== -->
  <text x="4" y="112" font-size="10" fill="var(--dim)" font-weight="600">CLOSED LOOP</text>

  <circle cx="60" cy="144" r="11" fill="var(--panel)" stroke="var(--line-2)"/>
  <text x="60" y="148" font-size="11" fill="var(--ink)" text-anchor="middle">&#8722;</text>

  <g stroke="var(--line-2)" fill="var(--panel)">
    <rect x="106" y="124" width="112" height="40" rx="3" stroke="var(--c-act)"/>
    <rect x="278" y="124" width="112" height="40" rx="3" stroke="var(--c-plant)"/>
  </g>
  <g font-size="10.5" fill="var(--ink)" text-anchor="middle">
    <text x="162" y="142">controller</text>
    <text x="334" y="142">plant</text>
  </g>
  <g font-size="8.5" fill="var(--faint)" text-anchor="middle">
    <text x="162" y="155">acts on the error</text>
    <text x="334" y="155">the actual thing</text>
  </g>

  <g stroke="var(--line-2)" fill="none" marker-end="url(#bl-ar)">
    <path d="M14 144 H 45"/>
    <path d="M75 144 H 102"/>
    <path d="M218 144 H 274"/>
    <path d="M390 144 H 424"/>
  </g>
  <g font-size="9" fill="var(--dim)">
    <text x="2" y="137">target</text>
    <text x="396" y="139">output</text>
  </g>
  <text x="88" y="136" font-size="9" fill="var(--beat)" text-anchor="middle">error</text>

  <!-- the one arrow that makes it a loop -->
  <g stroke="var(--c-meas)" fill="none" stroke-width="1.4" marker-end="url(#bl-ag)">
    <path d="M406 144 V 190 H 60 V 159"/>
  </g>
  <text x="120" y="186" font-size="8.5" fill="var(--c-meas)">measured output</text>

  <!-- a disturbance arrives between the two, in both rows -->
  <g stroke="var(--c-dist)" stroke-dasharray="2 2" fill="none" marker-end="url(#bl-af)">
    <path d="M248 106 V 136"/>
  </g>
  <text x="254" y="112" font-size="8.5" fill="var(--c-dist)">disturbance</text>

  <defs>
    <marker id="bl-ar" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--line-2)" stroke="none"/></marker>
    <marker id="bl-ag" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-meas)" stroke="none"/></marker>
    <marker id="bl-af" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
      <path d="M0 1 L7 4 L0 7 z" fill="var(--c-dist)" stroke="none"/></marker>
  </defs>

</svg>

<div class="bl-ctl">
  <div class="readout">
    <span class="rl">model error</span>
    <span class="rv">{{ err > 0 ? '+' : '' }}{{ err }}%</span>
  </div>
  <input type="range" min="-50" max="50" step="1" v-model.number="err" class="mt2"
         aria-label="model error, per cent" />
  <p class="cap mt3">
    Nominal loop gain <Tex e="L = 20" />.
    <b v-if="openWins">Below about 5&#37; the open loop is the more accurate of the two</b><b
    v-else>The closed-loop error stays under <Tex e="1/(1+L)" /> however wrong the model
    is</b>: the closed loop pays a fixed <Tex e="1/(1+L)" /> for finite gain, and the open
    loop pays <Tex e="\delta" /> without limit.</p>
</div>

<div class="bl-out">
  <div class="panel" style="border-left:2px solid var(--line-2)">
    <span class="k">open loop</span>
    <Tex block e="\frac{e}{r} = \ub{\delta}{the model error itself}" />
    <div class="bl-val">{{ openErr.toFixed(1) }}%</div>
  </div>

  <div class="panel" style="border-left:2px solid var(--line-2)">
    <span class="k">closed loop</span>
    <Tex block e="\frac{e}{r} = \frac{1}{1 + \ub{L(1+\delta)}{the actual loop gain}}" />
    <div class="bl-val">{{ closedErr.toFixed(1) }}%</div>
  </div>
</div>

</div>
</template>

<style scoped>
.bl-wrap{ display:grid; grid-template-columns:1.05fr 1fr;
  grid-template-rows:auto 1fr; gap:var(--s5) var(--s6); align-items:start; }
.bl-wrap > svg{ width:100%; height:auto; }
.bl-ctl{ grid-column:1; }
.bl-out{ grid-column:2; grid-row:1 / span 2;
  display:grid; grid-template-columns:1fr 1fr; gap:var(--s4); align-content:start; }
.bl-val{ font-family:var(--mono); font-size:var(--fs-num-lg); font-weight:600;
  color:var(--beat); font-variant-numeric:tabular-nums; line-height:1; }
</style>
