<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue'

// Exactly the same control law, exactly the same gain. One entry of the
// coil table has the wrong sign. Nothing you can run at your desk notices.
const sign = ref(+1)
const cv = ref(null)

const G = 0.1093, F = 0.71519, SPAN = 30, VMAX = 3.4, VMIN = -1.6

function draw() {
  const c = cv.value; if (!c) return
  const dpr = window.devicePixelRatio || 1, w = c.clientWidth, h = c.clientHeight
  if (c.width !== w * dpr || c.height !== h * dpr) { c.width = w * dpr; c.height = h * dpr }
  const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, w, h)

  const PL = 38, PR = 96, PT = 12, PB = 22, gw = w - PL - PR, gh = h - PT - PB
  const X = s => PL + s / SPAN * gw
  const Y = v => PT + (VMAX - Math.max(VMIN, Math.min(VMAX, v))) / (VMAX - VMIN) * gh

  x.strokeStyle = '#22303e'; x.lineWidth = 1
  x.font = '10px "IBM Plex Mono", ui-monospace, monospace'
  for (const v of [-1, 0, 1, 2, 3]) {
    const yy = Math.round(Y(v)) + 0.5
    x.beginPath(); x.moveTo(PL, yy); x.lineTo(w - PR, yy); x.stroke()
  }
  x.fillStyle = '#66747f'; x.textAlign = 'right'; x.textBaseline = 'middle'
  for (const v of [-1, 0, 1, 2, 3]) x.fillText(v === 0 ? '0' : v + 'x', PL - 5, Y(v))
  x.textAlign = 'left'; x.textBaseline = 'top'
  x.fillText('size of the swing, as a multiple of where it started', PL + 4, PT + 2)

  // both envelopes, always, so the contrast is on the page without clicking
  const env = (sg, col, alpha, dash) => {
    x.strokeStyle = col; x.globalAlpha = alpha; x.lineWidth = 1.2
    x.setLineDash(dash); x.beginPath()
    for (let s = 0; s <= SPAN; s += 0.2) {
      const v = Math.exp(-sg * G * s)
      s ? x.lineTo(X(s), Y(v)) : x.moveTo(X(s), Y(v))
    }
    x.stroke(); x.setLineDash([]); x.globalAlpha = 1
  }
  env(+1, '#5fbf8c', sign.value > 0 ? 0.55 : 0.3, sign.value > 0 ? [] : [4, 4])
  env(-1, '#e8756a', sign.value < 0 ? 0.55 : 0.3, sign.value < 0 ? [] : [4, 4])

  // the live trace for whichever case is selected
  const col = sign.value > 0 ? '#5fbf8c' : '#e8756a'
  const tmax = SPAN
  x.strokeStyle = col; x.lineWidth = 1.9; x.beginPath()
  for (let s = 0; s <= tmax; s += 0.04) {
    const v = Math.exp(-sign.value * G * s) * Math.cos(2 * Math.PI * F * s)
    s ? x.lineTo(X(s), Y(v)) : x.moveTo(X(s), Y(v))
  }
  x.stroke()

  // labels on the right, outside the plot
  x.textAlign = 'left'; x.textBaseline = 'middle'
  x.fillStyle = '#5fbf8c'; x.fillText('signs right:', w - PR + 6, Y(0.15))
  x.fillText('it damps', w - PR + 6, Y(0.15) + 12)
  x.fillStyle = '#e8756a'; x.fillText('one wrong:', w - PR + 6, Y(2.9))
  x.fillText('it pumps', w - PR + 6, Y(2.9) + 12)

  x.fillStyle = '#66747f'; x.textAlign = 'center'; x.textBaseline = 'top'
  for (let s = 0; s <= SPAN; s += 10) x.fillText(s + 's', X(s), h - PB + 5)
}

onMounted(() => { draw(); requestAnimationFrame(draw); window.addEventListener('resize', draw) })
onUnmounted(() => { window.removeEventListener('resize', draw) })
watch(sign, () => requestAnimationFrame(draw))
</script>

<template>
<div>
  <div style="display:flex; gap:.5rem; padding-bottom:.5rem">
    <button class="btn" @click="sign = +1"
            :style="sign > 0 ? 'flex:1; border-color:var(--good); color:var(--good); background:rgba(95,191,140,.08)' : 'flex:1'">
      <span class="btn-t">every sign in the coil table correct</span>
      <span class="btn-s">the push opposes the motion</span>
    </button>
    <button class="btn" @click="sign = -1"
            :style="sign < 0 ? 'flex:1; border-color:var(--bad); color:var(--bad); background:rgba(232,117,106,.08)' : 'flex:1'">
      <span class="btn-t">one entry has the wrong sign</span>
      <span class="btn-s">the push adds to the motion instead</span>
    </button>
  </div>

  <canvas ref="cv" class="w-full" style="height:146px"></canvas>

  <div class="cols-3 mt3">
    <div class="panel good"><span class="k">the offline self-test</span><div class="good mono">PASSED</div></div>
    <div class="panel good"><span class="k">the check that the tables fit together</span><div class="good mono">PASSED</div></div>
    <div class="panel good"><span class="k">the check on sensor and coil pairing</span><div class="good mono">PASSED</div></div>
  </div>
</div>
</template>
