// Screenshot every slide (or a named subset) at exact canvas size, so a figure
// can be looked at rather than measured.  node .build/shot.mjs 6,9,11 [outdir]
import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'

// Ports are derived from the pid so a subagent and the main session can run
// these at the same time without fighting over a socket.
const PORT_BASE = 4200 + (process.pid % 900) * 2
const W = 980, H = 552, PORT = PORT_BASE, CDP_PORT = PORT_BASE + 1
const SHELL = path.join(os.homedir(),
  'Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell')
const want = (process.argv[2] || '').split(',').filter(Boolean).map(Number)
const OUT = process.argv[3] || '/tmp/shots'
const sleep = ms => new Promise(r => setTimeout(r, ms))

class CDP {
  constructor (ws) { this.ws = ws; this.id = 0; this.pending = new Map()
    ws.addEventListener('message', e => { const m = JSON.parse(e.data)
      if (m.id && this.pending.has(m.id)) { const { resolve, reject } = this.pending.get(m.id)
        this.pending.delete(m.id); m.error ? reject(new Error(m.error.message)) : resolve(m.result) } }) }
  static async connect (url) { const ws = new WebSocket(url)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    return new CDP(ws) }
  send (method, params = {}, sessionId) { const id = ++this.id
    this.ws.send(JSON.stringify({ id, method, params, sessionId }))
    return new Promise((res, rej) => this.pending.set(id, { resolve: res, reject: rej })) }
}

fs.mkdirSync(OUT, { recursive: true })
const server = spawn(process.execPath, ['.build/serve.mjs', 'dist', String(PORT)], { stdio: 'ignore' })
const chrome = spawn(SHELL, [`--remote-debugging-port=${CDP_PORT}`, '--headless=new', '--disable-gpu',
  '--hide-scrollbars', '--no-sandbox', '--disable-dev-shm-usage', `--window-size=${W},${H}`, 'about:blank'],
  { stdio: 'ignore' })
const kill = () => { try { server.kill() } catch {}; try { chrome.kill() } catch {} }
process.on('exit', kill)

let wsUrl = null
for (let i = 0; i < 60 && !wsUrl; i++) { await sleep(250)
  try { wsUrl = (await (await fetch(`http://127.0.0.1:${CDP_PORT}/json/version`)).json()).webSocketDebuggerUrl } catch {} }
const cdp = await CDP.connect(wsUrl)
const { targetId } = await cdp.send('Target.createTarget', { url: 'about:blank' })
const { sessionId: S } = await cdp.send('Target.attachToTarget', { targetId, flatten: true })
await cdp.send('Page.enable', {}, S); await cdp.send('Runtime.enable', {}, S)
await cdp.send('Emulation.setDeviceMetricsOverride', { width: W, height: H, deviceScaleFactor: 2, mobile: false }, S)

const md = fs.readFileSync('slides.md', 'utf8').split('\n')
let total = 1, inFm = false
for (let i = 0; i < md.length; i++) { if (md[i].trim() !== '---') continue
  if (i === 0) { inFm = true; continue }
  if (inFm) { inFm = false; continue }
  total++; if (/^[a-zA-Z_][\w-]*\s*:/.test((md[i + 1] || '').trim())) inFm = true }

for (const n of (want.length ? want : Array.from({ length: total }, (_, i) => i + 1))) {
  await cdp.send('Page.navigate', { url: `http://127.0.0.1:${PORT}/${n}` }, S)
  await sleep(1400)
  const { data } = await cdp.send('Page.captureScreenshot', { format: 'png' }, S)
  fs.writeFileSync(path.join(OUT, `s${String(n).padStart(2, '0')}.png`), Buffer.from(data, 'base64'))
  process.stdout.write(`${n} `)
}
console.log('\n-> ' + OUT)
kill(); process.exit(0)
