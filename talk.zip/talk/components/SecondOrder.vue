<script setup>
// One number, zeta, and what it does to the response. No complex plane: the
// deck does not need one, and the step response says the same thing in the
// units the reader already has.
import { ref, computed } from 'vue'

const zeta = ref(0.25)
const TMAX = 24
const z = computed(() => zeta.value)
const wd = computed(() => Math.sqrt(Math.max(0, 1 - z.value * z.value)))

// unit step response of 1/(s^2 + 2 zeta s + 1), time normalised by omega-n
function step (t, zz) {
  if (zz < 0.999) {
    const w = Math.sqrt(1 - zz * zz)
    return 1 - Math.exp(-zz * t) * (Math.cos(w * t) + (zz / w) * Math.sin(w * t))
  }
  if (zz < 1.001) return 1 - (1 + t) * Math.exp(-t)
  const r = Math.sqrt(zz * zz - 1)
  const s1 = -zz + r, s2 = -zz - r
  return 1 - (s2 * Math.exp(s1 * t) - s1 * Math.exp(s2 * t)) / (s2 - s1)
}

const X0 = 60, X1 = 706, Y0 = 22, Y1 = 168
const tx = t => X0 + (t / TMAX) * (X1 - X0)
const ty = v => Y1 - (v / 1.95) * (Y1 - Y0)

const curve = computed(() => {
  const p = []
  for (let i = 0; i <= 460; i++) {
    const t = (i / 460) * TMAX
    p.push(tx(t).toFixed(1) + ',' + ty(step(t, z.value)).toFixed(1))
  }
  return 'M' + p.join(' L')
})

const envelope = computed(() => {
  if (z.value >= 0.999) return ''
  const up = [], dn = []
  for (let i = 0; i <= 130; i++) {
    const t = (i / 130) * TMAX
    const e = Math.exp(-z.value * t) / wd.value
    up.push(tx(t).toFixed(1) + ',' + ty(Math.min(1.95, 1 + e)).toFixed(1))
    dn.push(tx(t).toFixed(1) + ',' + ty(Math.max(0, 1 - e)).toFixed(1))
  }
  return 'M' + up.join(' L') + ' M' + dn.join(' L')
})

const overshoot = computed(() =>
  z.value >= 0.999 ? 0 : 100 * Math.exp(-Math.PI * z.value / wd.value))
const settle = computed(() => 4 / z.value)
const settleOn = computed(() => settle.value <= TMAX)

const verdict = computed(() => {
  if (z.value < 0.06) return { t: 'lightly damped', c: 'var(--bad)', s: 'many cycles before it settles' }
  if (z.value < 0.999) return { t: 'underdamped', c: 'var(--c-plant)', s: 'overshoots, then decays' }
  if (z.value < 1.001) return { t: 'critically damped', c: 'var(--good)', s: 'fastest without overshoot' }
  return { t: 'overdamped', c: 'var(--c-dist)', s: 'no overshoot, and slower for it' }
})
</script>

<template>
<div>
<svg viewBox="0 0 728 188" class="w-full" role="img"
     aria-label="Unit step response of a second-order system, with its decay envelope and settling time, for the chosen damping ratio.">

  <g stroke="var(--line)">
    <line :x1="X0" :y1="ty(1)" :x2="X1" :y2="ty(1)" stroke-dasharray="3 3"/>
    <line :x1="X0" :y1="Y1" :x2="X1" :y2="Y1"/>
    <line :x1="X0" :y1="Y0" :x2="X0" :y2="Y1"/>
  </g>
  <text :x="X1" :y="ty(1) - 6" font-size="8" fill="var(--faint)" text-anchor="end">commanded value</text>

  <path v-if="envelope" :d="envelope" fill="none" stroke="var(--beat)"
        stroke-width="1" stroke-dasharray="2 3" opacity=".5"/>
  <path :d="curve" fill="none" stroke="var(--c-plant)" stroke-width="1.9"/>

  <template v-if="settleOn">
    <line :x1="tx(settle)" :y1="Y0" :x2="tx(settle)" :y2="Y1" stroke="var(--good)" stroke-dasharray="2 2"/>
    <text :x="tx(settle) + 5" :y="Y0 + 9" font-size="8" fill="var(--good)">settled</text>
  </template>

  <text :x="X0" :y="Y1 + 14" font-size="8" fill="var(--faint)">
    time, in units of one over the natural frequency</text>
  <text :x="X1" :y="Y1 + 14" font-size="8.5" :fill="verdict.c" font-weight="600" text-anchor="end">{{ verdict.t }}<tspan fill="var(--faint)" font-weight="400"> -- {{ verdict.s }}</tspan></text>
</svg>

<div class="ctlrow" style="grid-template-columns:1.6fr 1fr 1fr; margin-top:var(--s2)">
  <div>
    <div class="readout"><span class="rl">damping ratio</span>
      <span class="rv">{{ z.toFixed(2) }}</span></div>
    <input type="range" min="0.02" max="1.60" step="0.01" v-model.number="zeta"
           aria-label="damping ratio zeta" class="mt2"/>
  </div>
  <div class="stat"><span class="rl">overshoot</span>
    <span class="rv">{{ overshoot < 0.05 ? 'none' : overshoot.toFixed(0) + '%' }}</span></div>
  <div class="stat"><span class="rl">quality factor</span>
    <span class="rv">{{ z >= 1 ? 'none' : (1 / (2 * z)).toFixed(1) }}</span></div>
</div>
</div>
</template>
