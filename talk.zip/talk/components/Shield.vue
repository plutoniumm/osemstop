<script setup>
// How a learned layer would attach to a loop that already works.
//
// The point of the picture is the ORDER. The passive law is not a fallback that
// gets switched to. It is underneath, permanently, and the learned layer can
// only add a bounded correction on top of it. Nothing the learned layer does can
// remove the dissipation guarantee, because that guarantee needs no model.
</script>

<template>
<svg viewBox="0 0 728 268" class="w-full">
  <!-- ================= read-only path, deployable first ================= -->
  <text x="8" y="14" font-size="10" fill="var(--cC)" font-weight="600">STAGE 1 &middot; READ ONLY</text>
  <text x="150" y="14" font-size="9" fill="var(--faint)">a wrong model here cannot command an actuator</text>

  <g stroke="var(--line-2)" fill="var(--panel)">
    <rect x="8"   y="24" width="132" height="38" rx="3"/>
    <rect x="176" y="24" width="132" height="38" rx="3"/>
    <rect x="344" y="24" width="132" height="38" rx="3"/>
  </g>
  <g font-size="9.5" fill="var(--ink)" text-anchor="middle">
    <text x="74"  y="41">Kalman innovation</text>
    <text x="242" y="41">learned classifier</text>
    <text x="410" y="41">event log</text>
  </g>
  <g font-size="8" fill="var(--faint)" text-anchor="middle">
    <text x="74"  y="54">already computed every step</text>
    <text x="242" y="54">what KIND of surprise</text>
  </g>
  <g stroke="var(--cC)" stroke-width="1.4" fill="none" marker-end="url(#ar-c)">
    <line x1="140" y1="43" x2="170" y2="43"/>
    <line x1="308" y1="43" x2="338" y2="43"/>
  </g>

  <line x1="8" y1="78" x2="720" y2="78" stroke="var(--line)"/>

  <!-- ================= stage 2: bounded correction ===================== -->
  <text x="8" y="98" font-size="10" fill="var(--cD)" font-weight="600">STAGE 2 &middot; BOUNDED CORRECTION</text>
  <text x="228" y="98" font-size="9" fill="var(--faint)">only after an interleaved A/B shows it damps</text>

  <!-- the permanent floor -->
  <rect x="8" y="196" width="600" height="42" rx="3" fill="var(--panel-2)" stroke="var(--good)" stroke-width="1.6"/>
  <text x="20" y="214" font-size="10.5" fill="var(--good)" font-weight="600">PASSIVE LAW, ALWAYS UNDERNEATH</text>
  <text x="20" y="229" font-size="8.5" fill="var(--dim)">u = -Kp x velocity. Dissipative at any positive gain, with no model at all.</text>

  <!-- the learned layer sitting on top -->
  <rect x="8" y="112" width="286" height="66" rx="3" fill="var(--panel)" stroke="var(--cD)"/>
  <text x="20" y="130" font-size="10" fill="var(--cD)" font-weight="600">LEARNED DYNAMICS MODEL</text>
  <text x="20" y="145" font-size="8.5" fill="var(--dim)">a small ensemble, trained on logged runs.</text>
  <text x="20" y="157" font-size="8.5" fill="var(--dim)">Predicts the RESIDUAL the linear model misses,</text>
  <text x="20" y="169" font-size="8.5" fill="var(--dim)">as a mean and a variance.</text>

  <rect x="312" y="112" width="296" height="66" rx="3" fill="var(--panel)" stroke="var(--brass)"/>
  <text x="324" y="130" font-size="10" fill="var(--brass)" font-weight="600">MPC, AND A HARD BOUND ON ITS AUTHORITY</text>
  <text x="324" y="145" font-size="8.5" fill="var(--dim)">Sample candidate action sequences, roll each</text>
  <text x="324" y="157" font-size="8.5" fill="var(--dim)">through every member, penalise ensemble DISAGREEMENT,</text>
  <text x="324" y="169" font-size="8.5" fill="var(--dim)">clip the correction to a fraction of the budget.</text>

  <g stroke="var(--cD)" stroke-width="1.4" fill="none" marker-end="url(#ar-d)">
    <line x1="294" y1="145" x2="308" y2="145"/>
  </g>
  <path d="M460 178 L460 192" stroke="var(--brass)" stroke-width="1.6" fill="none" marker-end="url(#ar-b)"/>
  <text x="470" y="190" font-size="8.5" fill="var(--brass)">added on top, not instead of</text>

  <!-- the ramp that decides how much authority stage 2 gets -->
  <rect x="624" y="112" width="96" height="126" rx="3" fill="var(--panel)" stroke="var(--line-2)"/>
  <text x="672" y="132" font-size="9.5" fill="var(--ink)" text-anchor="middle">budget ramp</text>
  <text x="672" y="148" font-size="8" fill="var(--faint)" text-anchor="middle">built,</text>
  <text x="672" y="159" font-size="8" fill="var(--faint)" text-anchor="middle">never energised</text>
  <text x="672" y="180" font-size="8" fill="var(--dim)" text-anchor="middle">splits ONE</text>
  <text x="672" y="191" font-size="8" fill="var(--dim)" text-anchor="middle">actuator budget</text>
  <text x="672" y="202" font-size="8" fill="var(--dim)" text-anchor="middle">between the two,</text>
  <text x="672" y="213" font-size="8" fill="var(--dim)" text-anchor="middle">on a MEASURED</text>
  <text x="672" y="224" font-size="8" fill="var(--dim)" text-anchor="middle">condition</text>

  <text x="8" y="256" font-size="9" fill="var(--faint)">
    Outside the data the correction is gated to zero, and the passive law is unchanged.</text>

  <defs>
    <marker id="ar-c" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--cC)"/></marker>
    <marker id="ar-d" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--cD)"/></marker>
    <marker id="ar-b" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
      <path d="M0,0 L6,3 L0,6" fill="var(--brass)"/></marker>
  </defs>
</svg>
</template>
