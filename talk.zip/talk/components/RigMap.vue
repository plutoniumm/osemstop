<script setup>
import { ref, computed } from 'vue'

// The rig, seen face on: you are standing in front of the mirror looking at it.
// Four sensors watch the back plane and read motion straight toward you.
// Two watch from the sides, two from above. Click a group to swap the panel.
//
// The teaching point is a count. Each group reads ONE axis at a few places, and
// the number of places is what decides how many motions of the mirror you can
// tell apart. The panel is a table so that count can be read off rather than
// narrated: how many sensors, along which axis, and what that does and does not
// resolve.
const GROUPS = {
  back: {
    name: 'the four on the back plane',
    ids: ['a0', 'a1', 'a2', 'a3'],
    col: 'var(--cA)',
    fact: 'Three rigid motions -- piston and two tilts -- plus one combination no rigid plate can produce.',
  },
  ears: {
    name: 'the two at the sides',
    ids: ['a4', 'a5'],
    col: 'var(--cC)',
    fact: 'Both sit along the axis they read, so a difference between them is a stretch, not a motion.',
  },
  top: {
    name: 'the two on top',
    ids: ['a6', 'a7'],
    col: 'var(--cD)',
    fact: 'Together, a lift. Apart, a roll.',
  },
}

const sel = ref('back')
const g = computed(() => GROUPS[sel.value])

// plate in the middle of the frame. The markers and the labels carry the size,
// not the white space, so the figure survives being read off a handout.
const L = 148, R = 372, T = 98, B = 254
const SENSORS = [
  { id: 'a0', x: L, y: T, grp: 'back' },
  { id: 'a1', x: R, y: T, grp: 'back' },
  { id: 'a2', x: L, y: B, grp: 'back' },
  { id: 'a3', x: R, y: B, grp: 'back' },
  { id: 'a4', x: 96,  y: 176, grp: 'ears' },
  { id: 'a5', x: 424, y: 176, grp: 'ears' },
  { id: 'a6', x: 206, y: 60, grp: 'top' },
  { id: 'a7', x: 314, y: 60, grp: 'top' },
]
const colOf = grp => GROUPS[grp].col
const dimOf = grp => (grp === sel.value ? 1 : 0.3)
</script>

<template>
<div class="cols-w">

  <svg viewBox="0 0 520 336" class="w-full">
    <text x="24" y="16" font-size="10" fill="var(--faint)">
      8 sensors. Beside each one, a coil that can push the mirror the same way.</text>

    <!-- the mirror itself -->
    <rect :x="L" :y="T" :width="R-L" :height="B-T" rx="3"
          fill="var(--panel-2)" stroke="var(--line-2)" stroke-width="1.8"/>
    <text :x="(L+R)/2" y="170" text-anchor="middle" font-size="14" fill="var(--dim)">
      the mirror</text>
    <text :x="(L+R)/2" y="190" text-anchor="middle" font-size="11" fill="var(--faint)">
      hanging on wires</text>
    <text :x="(L+R)/2" y="207" text-anchor="middle" font-size="10" fill="var(--faint)">
      seen face on</text>

    <g v-for="s in SENSORS" :key="s.id" :opacity="dimOf(s.grp)">
      <!-- sensing direction -->
      <g :stroke="colOf(s.grp)" stroke-width="1.8" fill="none">
        <template v-if="s.grp === 'back'">
          <circle :cx="s.x" :cy="s.y" r="13"/>
          <circle :cx="s.x" :cy="s.y" r="3.6" :fill="colOf(s.grp)" stroke="none"/>
        </template>
        <template v-else-if="s.grp === 'ears'">
          <circle :cx="s.x" :cy="s.y" r="13"/>
          <line :x1="s.x-30" :y1="s.y" :x2="s.x-16" :y2="s.y"/>
          <line :x1="s.x+16" :y1="s.y" :x2="s.x+30" :y2="s.y"/>
          <polygon :points="`${s.x-33},${s.y} ${s.x-24},${s.y-4.5} ${s.x-24},${s.y+4.5}`"
                   :fill="colOf(s.grp)" stroke="none"/>
          <polygon :points="`${s.x+33},${s.y} ${s.x+24},${s.y-4.5} ${s.x+24},${s.y+4.5}`"
                   :fill="colOf(s.grp)" stroke="none"/>
        </template>
        <template v-else>
          <circle :cx="s.x" :cy="s.y" r="13"/>
          <line :x1="s.x" :y1="s.y-30" :x2="s.x" :y2="s.y-16"/>
          <line :x1="s.x" :y1="s.y+16" :x2="s.x" :y2="s.y+30"/>
          <polygon :points="`${s.x},${s.y-33} ${s.x-4.5},${s.y-24} ${s.x+4.5},${s.y-24}`"
                   :fill="colOf(s.grp)" stroke="none"/>
          <polygon :points="`${s.x},${s.y+33} ${s.x-4.5},${s.y+24} ${s.x+4.5},${s.y+24}`"
                   :fill="colOf(s.grp)" stroke="none"/>
        </template>
      </g>
      <text :x="s.x" :y="s.y + 4" text-anchor="middle" font-size="11"
            :fill="colOf(s.grp)" font-weight="600"
            v-if="s.grp !== 'back'">{{ s.id }}</text>
      <text v-else :x="s.x + (s.x === L ? -20 : 20)" :y="s.y + (s.y === T ? -17 : 24)"
            :text-anchor="s.x === L ? 'end' : 'start'" font-size="11"
            :fill="colOf(s.grp)" font-weight="600">{{ s.id }}</text>
    </g>
  </svg>

  <div class="stack-tight">
    <button v-for="(gg, k) in GROUPS" :key="k" class="btn" :class="{ on: sel === k }"
            @click="sel = k">
      <span class="btn-t">{{ gg.ids.join(' , ') }}</span>
      <span class="btn-s">{{ gg.name }}</span>
    </button>

    <p class="cap mt2" :style="{ borderLeft: '2px solid ' + g.col, paddingLeft: '.7rem' }">
      {{ g.fact }}</p>
  </div>
</div>
</template>
